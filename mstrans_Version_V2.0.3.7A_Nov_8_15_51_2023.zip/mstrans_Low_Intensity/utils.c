#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifndef ENABLE_PICO
#include <stdint.h>
#endif
#include "utils.h"

/*
getHex
This function returns the hex value of the input ASCII  
*/
uint8_t getHex(uint8_t ch)
{
    uint8_t rc = 0xff;

    if (ch >= '0' && ch <= '9')
        rc = ch - '0';
    else if (ch >= 'A' && ch <= 'F')
        rc = 10 + (ch - 'A');
    else if (ch >= 'a' && ch <= 'f')
        rc = 10 + (ch - 'a'); 

    return rc;
}

void mtpl_memset(void *p, uint8_t ch, uint16_t len)
{
    for (int i = 0; i < len; i++)
        (((uint8_t *)p)[i]) = ch;
}

void mtpl_memcpy(uint8_t *pDest, uint8_t *pSrc, uint16_t len)
{
    for (int i = 0; i < len; i++)
        *pDest++ = *pSrc++;
}

uint8_t mtpl_memcmp(uint8_t *pS1, uint8_t *pS2, uint16_t len)
{
    uint8_t rc = 1;

    while (len)
    {
        if (*pS1 != *pS2)
            return rc;
        pS1++;
        pS2++;
        len--;
    }
    if (!len)
        rc = 0;

    return rc;
}

uint16_t mtpl_strlen(uint8_t *pBuf)
{
    uint16_t rc = 0;

    while (*pBuf)
    {
        rc++;
        pBuf++;
    }

    return rc;
}

int mtpl_atoi(uint8_t *pBuf)
{
    int rc = 0;
    int len = mtpl_strlen(pBuf);
    int index = 0;

    while (len > 0)
    {
        if ((pBuf[len - 1] >= '0') && (pBuf[len - 1] <= '9')) 
        {
            switch(index)
            {
                case 0:
                    rc += (pBuf[len - 1] - '0');
                    break;

                case 1:
                    rc += (pBuf[len - 1] - '0') * 10;
                    break;

                case 2:
                    rc += (pBuf[len - 1] - '0') * 100;
                    break;

                case 3:
                    rc += (pBuf[len - 1] - '0') * 1000;
                    break;
            }
        }
        else
            return -1;

        index++;
        len--;
    }

    return rc;
}

void copyDisplayInfo()
{
    displayInfo.mode = messageInfo.mode;
    displayInfo.flashStartTime = 0;
    displayInfo.modeIndex = messageInfo.modeIndex;
    //displayInfo.Top_Priority_Message_Status = messageInfo.Top_Priority_Message_Status;

    for (uint8_t i = 0; i < MAX_MODES; i++)
    {
        displayInfo.modeData[i].enableScrolling = messageInfo.modeData[i].enableScrolling;
        displayInfo.modeData[i].repeatCount = messageInfo.modeData[i].repeatCount;
        displayInfo.modeData[i].row = messageInfo.modeData[i].row;
        displayInfo.modeData[i].col = messageInfo.modeData[i].col;
        displayInfo.modeData[i].width = messageInfo.modeData[i].width;
        displayInfo.modeData[i].height = messageInfo.modeData[i].height;
        displayInfo.modeData[i].shiftLeft = messageInfo.modeData[i].shiftLeft;
        displayInfo.modeData[i].shiftRight = messageInfo.modeData[i].shiftRight;
        displayInfo.modeData[i].flashPeriod = messageInfo.modeData[i].flashPeriod;
        displayInfo.modeData[i].flashOnTime = messageInfo.modeData[i].flashOnTime;
        displayInfo.modeData[i].flashOffTime = messageInfo.modeData[i].flashOffTime;
        
        // printf("\n in function utils.c\n");
        // printf("\n displayInfo.modeData[%d].shiftLeft = %d",i,displayInfo.modeData[i].shiftLeft);
        // printf("\n messageInfo.modeData[%d].shiftRight = %d",i,messageInfo.modeData[i].shiftRight);
    }
}
