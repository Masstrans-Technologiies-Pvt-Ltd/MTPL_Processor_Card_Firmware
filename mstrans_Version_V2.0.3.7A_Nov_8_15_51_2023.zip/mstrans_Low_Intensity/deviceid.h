//
// This file holds function prototypes for device id detection
//
#ifndef __DEVICE_ID__
#define __DEVICE_ID__

int updateDeviceId();

#endif // __DEVICE_ID__ 