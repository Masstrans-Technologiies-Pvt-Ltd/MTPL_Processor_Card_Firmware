#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#else
#include <stdint.h>
#endif
#include "uart.h"
#include "rcerr.h"
#include "utils.h"
#include "main.h"
#include "deviceid.h"
#include "init.h"
#ifdef ENABLE_PICO
#include "hardware/uart.h"
#endif

#ifndef ENABLE_PICO
#include "errno.h"

FILE *fp = NULL;
uint8_t *pUartBuf = NULL;
int uartBufSize = 0;
int uartReadIndex = 0;
#endif

const char *showDisplayInfoStr = "{\\mode0\\fit2{  MASSTRANS PIS TESTING  }}";

static UART_FRAME hanover_frame = {0};
///////////////////////////////////////////////////////////////////////////////////////////////////////
static UART_FRAME_1 flashingflags = {0};
//////////////////////////////////////////////////////////////////////////////////////////////////////

UART_FRAME *pUart = &hanover_frame;
/// @brief //////////////////////////////////////////////////////////////////////////////////////////
UART_FRAME_1 *flash =&flashingflags;
////////////////////////////////////////////////////////////////////////////////////////////////////
extern uint8_t hvrprot_Test_Mode_Message_Flag;
extern uint8_t hvrprot_Test_Mode_Scroll_Completed_Flag;
extern uint8_t New_Message_Received_Data_Structure_Updated ;
#ifdef ENABLE_PICO
uint8_t device_id_flag = 0;
#endif


#ifndef ENABLE_PICO
uint8_t init_uart(char *fname)
{
    uint8_t rc = 0;

    if ((fp = fopen(fname, "rb")) != NULL)
    {
        // Seek to end to get file size
        fseek(fp, 0L, SEEK_END);

        uartBufSize = ftell(fp);
        pUartBuf = (uint8_t *)malloc(uartBufSize);
        if (!pUartBuf)
        {
            printf("Error %d allocating %d bytes for uart buffer\n", 
                    errno, uartBufSize);
            return 4;
        }
        // Go back to beginning
        fseek(fp, 0L, SEEK_SET);

        if (uartBufSize > 0)
        {
            if(fread(pUartBuf, 1, uartBufSize, fp) != uartBufSize)
            {
                printf("Error %d reading file %s\n", errno, fname);
                rc = 3;
            }
        }
        else
        {
            printf("Error %d getting size of file %s\n", errno, fname);
            rc = 2;
        }
        fclose(fp);
        fp = NULL;
    }
    else
        rc = 1;

    return rc;
}
#endif

uint8_t recv_byte(uint8_t *pCh)
{
    uint8_t rc = RC_NO_DATA;

#ifndef ENABLE_PICO
    if (uartReadIndex < uartBufSize)
    {
        *pCh = pUartBuf[uartReadIndex++];
        rc = RC_SUCCESS;
    }
#else
    if (uart_is_readable_within_us (uart0, UART_WAIT_TIME_IN_USEC))
    {
        uart_read_blocking (uart0, pCh, sizeof(*pCh));
        if(hvrprot_Test_Mode_Message_Flag && hvrprot_Test_Mode_Scroll_Completed_Flag)
        {
            printf("\nClearing test mode\n");
            hvrprot_Test_Mode_Message_Flag = 0;                              //
            hvrprot_Test_Mode_Scroll_Completed_Flag = 0;                 //
            New_Message_Received_Data_Structure_Updated = 1;
            messageInfo.messageChanged = 0;
            pUart->showDisplayInfo = 0;
        }
        rc = RC_SUCCESS;
    }
    else if(hvrprot_Test_Mode_Message_Flag && hvrprot_Test_Mode_Scroll_Completed_Flag)
    {
        //printf("\n in else part for test mode");
        rc = RC_SUCCESS;
    }
#endif

    return rc;
}

uint8_t send_frame(uint8_t *pBuf, uint16_t bufLen)
{
    uint8_t rc = RC_SUCCESS;
#ifdef ENABLE_PICO
    uint16_t index = 0;

    while (index < bufLen)
    {
        if (uart_is_writable(uart0))
        {
            uart_putc_raw(uart0, pBuf[index++]);
        }
        else
            sleep_ms(1);
    }
#endif

    return rc;
}

void clear_hanover_frame()
{
    //printf("%s\n", __func__);
    mtpl_memset(pUart, 0, sizeof(*pUart));

    return;
}

uint8_t validate_command()
{
    
    uint8_t rc = RC_SUCCESS;
    //printf("\n control came to validate command function");
    /*int vari=0;
    printf("\n and the command controllor received is assumed as %d\t",pUart->cmd);
    for(vari=0;vari<=pUart->framing_buffer_index;vari++)
    {
    printf("\n THe %d character of the framming buffer is %c",vari,pUart->framing_buffer[vari]);
    // ToDo, verify command is within range

    }*/
    return rc;
}

uint8_t validate_checksum()
{
    uint8_t rc = RC_SUCCESS;
    int i=0;
    uint16_t checksumfinalvalueleft1=0,checksumfinalvalueright2=0;
    uint8_t Validate_checksum = 0,temp_cmd =0;
    int checksum = 0;

    // printf("\n received command is %d",pUart->cmd);
    temp_cmd = pUart->cmd;
    if(pUart->cmd >= 10)
    {
        switch(pUart->cmd)
        {
            case 10:
            pUart->cmd = 'A'- 48;
            break;
            case 11:
            pUart->cmd = 'B'- 48;
            break;
            case 12:
            pUart->cmd = 'C'- 48;
            break;
            case 13:
            pUart->cmd = 'D'- 48;
            break;
            case 14:
            pUart->cmd = 'E'- 48;
            break;
            case 15:
            pUart->cmd = 'F'- 48;
            break;
            default:
            pUart->cmd = 30;
        }
    }
    // printf("\n recieved device id is %d",pUart->destId);
    // printf("\nDevice Id in Hex is = 0x%02X and Device Id in char is = %c\n",pUart->destId,((pUart->destId)+48));
    // printf("\nCommand Received in Hex is =0X%02X\n",pUart->cmd);
    // checksum += pUart->destId+48;
    // printf("\nchecksum after adding destID is %d whose hex is %02X is %d",pUart->destId,pUart->destId,checksum);   
    checksum += pUart->cmd+48;
    // printf("\nchecksum after adding cmd is %d adding 48 %d whose hex is %02X adding 48 %02Xis %d",pUart->cmd,pUart->cmd+48,pUart->cmd,pUart->cmd+48,checksum);
    checksum += pUart->destId+48;
    // printf("\nchecksum after adding destID is %d adding 48 %dwhose hex is %02X adding 48 %02X is %d",pUart->destId,pUart->destId+48,pUart->destId,pUart->destId+48,checksum);   
    i=0; 
    //printf("Buffer length = %d\n",  pUart->framing_buffer_index);
    while(pUart->framing_buffer[i])
    //for(i=0;i<=50;i++)
    {
        checksum += pUart->framing_buffer[i];
        // printf("\ncheck sum after adding %c whose hex is %02X and dec %d is %d",pUart->framing_buffer[i],pUart->framing_buffer[i],pUart->framing_buffer[i],checksum);
        i=i+1;
        
    }
            //printf("Updated Buffer length = %d\n",  i);
            checksum += 3;
            // printf("\ncheksum after adding EOF 0x03 is %d",checksum);
            checksum = checksum % 256;
            // printf("\nRemainder after checksum / 256 is %d",checksum);
            Validate_checksum = (uint8_t)(0 - checksum);
            // printf("\nFinal Value of checksum after (0 - checksum) is %d",Validate_checksum);
            //printf("\n The Checksum after calculating 0-checksum from above in decimal is = %d",Validate_checksum);
            //printf("\n The Checksum after calculating 0-checksum from above in Hex is = 0x%02X",Validate_checksum);
            //printf("\nValue of checksum before dividing first value and second value is 0X%02X\n\n", Validate_checksum);
            checksumfinalvalueleft1=Validate_checksum&240;//bitwise OR operato
            checksumfinalvalueleft1=checksumfinalvalueleft1 >> 4;
            if(checksumfinalvalueleft1<10)
                                        {
                                            checksumfinalvalueleft1=(int)checksumfinalvalueleft1+48;
                                        }
                                        else if(checksumfinalvalueleft1>=10)
                                        {
                                            checksumfinalvalueleft1=(int)checksumfinalvalueleft1+55;
                                        }
            checksumfinalvalueright2=Validate_checksum&15;
                                        if(checksumfinalvalueright2<10)
                                        {
                                            checksumfinalvalueright2=(int)checksumfinalvalueright2+48;
                                        }
                                        else if(checksumfinalvalueright2>=10)
                                        {
                                            checksumfinalvalueright2=(int)checksumfinalvalueright2+55;
                                        }

                // printf("\n The Received value of Checksum is %d%d",pUart->csumBuf[0],pUart->csumBuf[1]);
                // printf("\n The calculated value of checksum in dec is %d \t in hex is %02X \nand the Received value of checksum is in dec is %d \t in hex is %02X",Validate_checksum,Validate_checksum,pUart->csum,pUart->csum);
                if(Validate_checksum==pUart->csum)
                {
                    // printf("\n\n Checksum Matched\n\n");
                    rc = RC_SUCCESS;
                }
                else if(Validate_checksum!=pUart->csum)
                {
                    // printf("\n\n Checksum Not Matched\n\n");
                    rc = RC_INVALID_CHECKSUM;
                }

    // ToDo, verify checksum
    pUart->cmd = temp_cmd;

    return rc;
}

uint8_t validate_deviceid()
{
    uint8_t rc = RC_SUCCESS;
#ifdef ENABLE_PICO
    uint8_t deviceId = updateDeviceId();
    if (deviceId != systemInfo.deviceId)
    {
        printf("Device id changed from %d to %d\n", systemInfo.deviceId, deviceId);
        systemInfo.deviceId = deviceId;
    }
    printf("Current device id = %d\n", (int)systemInfo.deviceId);

    if (pUart->destId != systemInfo.deviceId)
        rc = RC_MISMATCH_DESTINATION;
    
#endif

    return rc;
}

/*
validate_hanover_frame:
This function validates a previously received hanover frame for
1. Valid Checksum
2. Valid Destination ID
3. Valid Command
Returns RC_VALID_FRAME on SUCCESS
        RC_MISMATCH_DESTINATION if destination does not match this
          boards ID
        RC_INVALID_COMMAND if command is not supported
        RC_INVALID_CHECKSUM if checksum is not valid
*/
uint8_t validate_hanover_frame()
{
    uint8_t rc = RC_GENERAL_FAILURE;

    if ((rc = validate_checksum()) == RC_SUCCESS)
    {
        // Dump ERIC information packets
        if (pUart->framing_buffer_index < MIN_VALID_FRAME_SIZE)
        {
            rc = RC_RUNT_FRAME;
        }
        else
        {
            if ((rc = validate_deviceid()) == RC_SUCCESS)
            {
                rc = validate_command();
            }
            else
                rc = RC_MISMATCH_DESTINATION;
        }
    }

    return rc;
}

/*
build_hanover_frame:
This function assembles the received byte into a buffer and returns 0 
*/
uint8_t build_hanover_frame(uint8_t ch)
{
    uint8_t rc = RC_SUCCESS;

#ifdef UART_DEBUG
            gpio_put(15,1); // enable RS485 Transmission
            sleep_us(50);
            uart_putc(uart0,ch);
            sleep_us(2500);
            gpio_put(15,0); // disable RS485 Transmission
            if(ch == 0x02)
            {
                gpio_put(15,1); // enable RS485 Transmission
                sleep_us(50);
                uart_putc(uart0,'Z');
                sleep_us(2500);
                gpio_put(15,0); // disable RS485 Transmission
            }
            if(ch == 0x03)
            {
                gpio_put(15,1); // enable RS485 Transmission
                sleep_us(50);
                uart_putc(uart0,'A');
                sleep_us(2500);
                gpio_put(15,0); // disable RS485 Transmission
            }
#endif
    if(hvrprot_Test_Mode_Message_Flag && hvrprot_Test_Mode_Scroll_Completed_Flag)
    {
        rc = RC_UPDATE_TEST_MESSAGE;
        return rc;
    }

    switch (ch)
    {
        case HANOVER_PROT_MASTER_SOF:
                
            if (pUart->state == UART_FRAMING_INIT)
            {
#ifdef UART_DEBUG
                gpio_put(15,1); // enable RS485 Transmission
                sleep_us(50);
                uart_putc(uart0,'Q');
                sleep_us(2500);
                gpio_put(15,0); // disable RS485 Transmission
#endif
                pUart->state = UART_SOF_RECEIVED;
                //printf("Received SOF, new state %d\n", (int)pUart->state);
            }
            else
                rc = RC_FRAMING_ERROR;

            break;

        case HANOVER_PROT_MASTER_EOF:
            pUart->state = UART_CHECKSUM_MSB;
            //printf("Received EOF, new state %d\n", (int)pUart->state);
            break;

        case '\n':
            // Skip linefeeds
            break;

        default:
            //printf("Uart state = %d, ch = %c\n", pUart->state, ch);
            // Check for ASCII
            switch (pUart->state)
            {
                case UART_SOF_RECEIVED:
                    pUart->cmd = getHex(ch);
                    if (pUart->cmd == 0xff)
                        rc = RC_FRAMING_ERROR;
                    else
                        pUart->state = UART_CMD_RECEIVED;
                    //printf("Received CMD, return code %d\n", rc);
                    break;

                case UART_CMD_RECEIVED:
                    pUart->destId = getHex(ch);
                    if (pUart->destId == 0xff)
                        rc = RC_FRAMING_ERROR;
                    else
                        pUart->state = UART_DATA;

                    //printf("Received DevId %d, return code %d\n", (int)pUart->destId, rc);
                    break;

                case UART_CHECKSUM_MSB:
                    pUart->csumBuf[0] = getHex(ch);
                    if (pUart->csumBuf[0] == 0xff)
                        rc = RC_FRAMING_ERROR;
                    else
                        pUart->state = UART_CHECKSUM_LSB;

                    //printf("Wait for checksum LSB, rc = %d\n", rc);
                    break;

                case UART_CHECKSUM_LSB:
                    //printf("Received checksum LSB\n");
                    pUart->csumBuf[1] = getHex(ch);
                    if (pUart->csumBuf[1] == 0xff)
                    {
                        rc = RC_FRAMING_ERROR;
                        printf("\n checksum missmatch Error \n");
                    }
                    else
                    {
                        pUart->csum = ((pUart->csumBuf[0] << 4) & 0xf0) |
                            (pUart->csumBuf[1] & 0x0f);
                        pUart->state = UART_FRAMING_INIT;
                        rc = RC_FRAMING_DONE;

                        if (!memcmp(pUart->framing_buffer, showDisplayInfoStr, //first location where the code identifies test message has arrived
                            strlen(showDisplayInfoStr)))
                        {
                            printf("show display mode enabled\n");
                            pUart->showDisplayInfo = 1;
                        }

                    }
                    //printf("Framing complete, return code %d\n", rc);

                    break;

                default:
                case UART_DATA:
                    if (ch >= ' ' && ch <= '}')
                    {
                        if (pUart->framing_buffer_index < sizeof(pUart->framing_buffer))
                            pUart->framing_buffer[pUart->framing_buffer_index++] = ch;
                        else
                            rc = RC_FRAME_TOO_LARGE;
                    }
                    else
                    {
                        rc = RC_FRAMING_ERROR;
                        printf("UART data %c [0x%02x], framing error\n", ch, ch);
                    }
                    break;
            }

            break;
    }
    return rc;
}

#ifdef ENABLE_PID_DTC
void send_byte(uint8_t ch)
{
    printf("%02x ", ch);
    uart_write_blocking(uart0, &ch, 1);
}
#endif