//
// main.h: Common data structures  
//

#ifdef ENABLE_WATCHDOG
#define WATCHDOG_TIMEOUT    5000 // millisecs of missed watchdog update after which it will fire
void display_watchdog_update();
void uart_watchdog_update();
int Chip_Chipone_Configuration_To_Max_Intensity(uint8_t board_type);
void manula_spi_write_register1(uint16_t *pBuf, int len);
void sent_register_write_Enable_Command(void);
void init_spi_manually(void);
void manual_spi_Write_Data(uint8_t *Dataptr, int len);
void manual_spi_write_register1(uint16_t config, int num_chips, int num_boards);
//uint16_t DISPLAY_WIDTH_IN_COLUMNS = 0;//DISPLAY_WIDTH_IN_COLUMNS
#endif

#define FIRMWARE_VERSION    "2.0.3.7A"

#define Identification_Iteration    3

typedef struct 
{
    uint8_t testMode;
    uint8_t deviceId;
    uint8_t Board_Type;
} SYSTEM_INFO;

extern SYSTEM_INFO systemInfo;
