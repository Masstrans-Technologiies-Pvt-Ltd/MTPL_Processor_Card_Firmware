#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "hvrprot.h"

#ifndef __UTILS_H__
#define __UTILS_H__

uint8_t getHex(uint8_t ch);
void mtpl_memset(void *p, uint8_t ch, uint16_t len);
uint16_t mtpl_strlen(uint8_t *pBuf);
uint8_t mtpl_memcmp(uint8_t *pS1, uint8_t *pS2, uint16_t len);
void mtpl_memcpy(uint8_t *pDest, uint8_t *pSrc, uint16_t len);
int mtpl_atoi(uint8_t *pBuf);

void copyDisplayInfo();

typedef struct {
    uint8_t enableScrolling;
    uint8_t repeatCount;
    uint16_t row, col;
    uint16_t width;
    uint16_t height;
    uint8_t shiftLeft;
    uint8_t shiftRight;
    uint8_t flashPeriod;
    uint16_t flashOnTime;
    uint16_t flashOffTime;
} DISPLAY_INFO;

typedef struct {
    uint8_t mode;
    uint8_t flashStartTime;
    int modeIndex;
    uint8_t Top_Priority_Message_Status;
    DISPLAY_INFO modeData[MAX_MODES];
} DISPLAY_MODE_INFO;

extern DISPLAY_MODE_INFO displayInfo;
#endif