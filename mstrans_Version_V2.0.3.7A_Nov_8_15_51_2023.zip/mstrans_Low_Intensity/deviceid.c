//
// This file implements functions for device id detection
//
#include <stdio.h>
#include <string.h>

#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "hardware/pwm.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#endif

#include "deviceid.h"
#include "init.h"

int updateDeviceId()
{
    int deviceId = 0;
#ifdef ENABLE_PICO
    uint8_t ASW0=1,ASW1=1,ASW2=1,ASW3=1;

    ASW0=gpio_get(ASW0v);
    ASW1=gpio_get(ASW1v);
    ASW2=gpio_get(ASW2v);
    ASW3=gpio_get(ASW3v);

    if((ASW0==1)&&(ASW1==1)&&(ASW1==1)&&(ASW3==1))
    {
        deviceId = 0;
    }
    if((ASW0==0)&&(ASW1==1)&&(ASW2==1)&&(ASW3==1))
    {
        deviceId = 1;
    }
    if((ASW0==1)&&(ASW1==0)&&(ASW2==1)&&(ASW3==1))
    {
        deviceId = 2;
    }
    if((ASW0==0)&&(ASW1==0)&&(ASW2==1)&&(ASW3==1))
    {
        deviceId = 3;
    }
    if((ASW0==1)&&(ASW1==1)&&(ASW2==0)&&(ASW3==1))
    {
        deviceId = 4;
    }
    if((ASW0==0)&&(ASW1==1)&&(ASW2==0)&&(ASW3==1))
    {
        deviceId = 5;
    }
    if((ASW0==1)&&(ASW1==0)&&(ASW2==0)&&(ASW3==1))
    {
        deviceId = 6;
    }
    if((ASW0==0)&&(ASW1==0)&&(ASW2==0)&&(ASW3==1))
    {
        deviceId = 7;
    }
    if((ASW0==1)&&(ASW1==1)&&(ASW2==1)&&(ASW3==0))
    {
        deviceId = 8;
    }
    if((ASW0==0)&&(ASW1==0)&&(ASW2==0)&&(ASW3==0))
    {
        deviceId = 9;
    }
#else
    deviceId = 0;
#endif
    return deviceId+1;
}
