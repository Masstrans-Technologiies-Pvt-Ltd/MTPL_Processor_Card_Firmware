#ifndef __SCROLLMSG_H__
#define __SCROLLMSG_H__

#define MAX_DISPLAY_LEN 32 /* Number of columns = 32*8 */
#define MAX_MESSAGE_LEN (1024 + MAX_DISPLAY_LEN) /* Number of columns = 1056*8 */
#define MAX_ROWS        16
#define SCROLL_LEFT     1
#define SCROLL_RIGHT    2

#define LEFT_SHIFT_CARRY_BIT   0x80
#define RIGHT_SHIFT_CARRY_BIT  0x01


// 16 rows are divided into 2 blocks of 8 rows, each of which may be scrolled independently
#define MAX_SCROLL_BLOCKS         2 
#define TOP_SCROLL_BLOCK          0
#define BOTTOM_SCROLL_BLOCK       1
////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////JULY 15 2023 16:38  //////////////////////////////////////////////////////////////////
////////////////MODE INDEX for MODE 3 information ////////////////////////////////////////////////////
#define STATIC_DATA_BLOCK_FOR_MODE_3        0
#define TOP_SCROLL_BLOCK_FOR_MODE_3         1
#define BOTTOM_SCROLL_BLOCK_FOR_MODE_3       2
//////////////////////////////////////////////////////////////////////////////////////////////////////
#define SCROLL_START_POSITION_FOR_140X16    17
#define SCROLL_START_POSITION_FOR_128X16    15
#define SCROLL_START_POSITION_FOR_96X16     15
//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
#define SCROLL_START_POSITION     17 // Represents the Scrolling Starting Position location from where the scroll begins.
typedef struct
{
    int numRows;
    int scrollDir;
    
    uint8_t scrollMsgBuf[MAX_ROWS][MAX_MESSAGE_LEN];
    int scrollMsgLen[MAX_SCROLL_BLOCKS];
    uint8_t *pStart;
    int currIndex[MAX_SCROLL_BLOCKS];
    uint16_t dispLen;
    uint16_t scrollOffset;
    uint16_t offset;
} SCROLL_INFO;

void shiftLeft(uint8_t *pBuf, int len);
void shiftRight(uint8_t *pBuf, int len);
void scrollMessageBufInit(uint8_t *pMsgBuf, int topMsgLenInCols, int bottomMsgLenInCols, 
    int numRows, uint8_t scrollDir, int dispLenInCols, int colOffset);
void scrollMessageBuf(uint8_t scrollBlock, uint16_t colOffset);
void copyScrolledBuffer(uint8_t *pDest);
uint8_t scrollDone(uint8_t modeIndex);

#endif