#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#ifndef ENABLE_PICO
#include <stdint.h>
#else
#include "pico/stdlib.h"
#endif

#include "scrollmsg.h"
#include "utils.h"
#include "main.h"

int scroll_count = 0;

SCROLL_INFO scrollInfo = {0};
extern DISPLAY_MODE_INFO displayInfo;
extern SYSTEM_INFO systemInfo;

void shiftRight(uint8_t *pBuf, int len)
{
    uint8_t *ptr;
    uint8_t carry = 0, tempCarry = 0;

    if (pBuf && len)
    {
        carry = pBuf[len - 1] & RIGHT_SHIFT_CARRY_BIT ? 0x80 : 0x00;

        ptr = &pBuf[0];
        for (int i = 0; i <= len - 1; i++, ptr++)
        {
            tempCarry = (*ptr & RIGHT_SHIFT_CARRY_BIT) ? 0x80 : 0x00;
            *ptr = ((*ptr >> 1) | carry);
            carry = tempCarry;
        }
    }

    return;
}

void shiftLeft(uint8_t *pBuf, int len)
{
    uint8_t *ptr;
    uint8_t carry = 0, tempCarry = 0;

    if (pBuf && len)
    {
        carry = pBuf[0] & LEFT_SHIFT_CARRY_BIT ? 0x01 : 0x00;

        ptr = &pBuf[len - 1];
        for (int i = len - 1; i >= 0; i--, ptr--)
        {
            tempCarry = (*ptr & LEFT_SHIFT_CARRY_BIT) ? 0x01 : 0x00;
            *ptr = ((*ptr << 1) | carry);
            carry = tempCarry;
        }
    }

    return;
}

/********************************************************
Function: scrollMessageBufInit
Purpose: Initializes the scroll message buffer, should be called once when the message
to be scrolled changes
Inputs:
*********************************************************/
void scrollMessageBufInit(uint8_t *pMsgBuf, int topMsgLenInCols, int bottomMsgLenInCols,
                          int numRows, uint8_t scrollDir, int dispLenInCols, int colOffset)
{
    SCROLL_INFO *pSi = &scrollInfo;
    int Scroll_Start_Position = 16;
   switch(systemInfo.Board_Type)
   {
    case 0:
    printf("\n No Board Identified\n");
    break;
    case 1:
    // printf("\n Board Type = 140X16 Identified\n");
    Scroll_Start_Position = SCROLL_START_POSITION_FOR_140X16;
    break;
    case 2:
    // printf("\n Board Type = 128X16 Identified\n");
    Scroll_Start_Position = SCROLL_START_POSITION_FOR_128X16;
    break;
    case 3:
    // printf("\n Board Type = 96X16 Identified\n");
    Scroll_Start_Position = SCROLL_START_POSITION_FOR_96X16;
    break;
    default:
    printf("\n No Board Identified\n");
    break;
   }

    if ((topMsgLenInCols % 8) || (bottomMsgLenInCols % 8) || (dispLenInCols % 8))
    {
        printf("Invalid msg len %d, %d, %d\n", topMsgLenInCols, bottomMsgLenInCols, dispLenInCols);
        // TODO, Handle message, start column and display length being not a multiple of 8
        return;
    }
    // printf("\n current mode is %d",displayInfo.mode);

    // Add the display buffer to the end of the message buffer to
    // handle scrolling (append buffer to right for left scroll and
    // to the left for right scroll)
    if ((((topMsgLenInCols / 8) + (dispLenInCols / 8)) < sizeof(pSi->scrollMsgBuf)) &&
        (((bottomMsgLenInCols / 8) + (dispLenInCols / 8)) < sizeof(pSi->scrollMsgBuf)))
    {
        /* Start */
        pSi->numRows = numRows;
        pSi->dispLen = dispLenInCols / 8;
        pSi->scrollMsgLen[TOP_SCROLL_BLOCK] = topMsgLenInCols / 8 + dispLenInCols / 8 - colOffset / 8;
        pSi->scrollMsgLen[BOTTOM_SCROLL_BLOCK] = bottomMsgLenInCols / 8 + dispLenInCols / 8 - colOffset / 8;
        pSi->currIndex[TOP_SCROLL_BLOCK] = 0;
        pSi->currIndex[BOTTOM_SCROLL_BLOCK] = 0;
        pSi->scrollDir = scrollDir;
        pSi->offset = colOffset / 8;
        pSi->scrollOffset = dispLenInCols / 8 - colOffset / 8;
        
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //printf("\n scrolling status is %d",displayInfo.modeData->enableScrolling);
            //printf("\n scrolling status for TOP_SCROLL_BLOCK is %d",displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling);
            //printf("\n scrolling status for BOTTOM_SCROLL_BLOCK is %d",displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling);
            switch (displayInfo.mode)
            {
                case 0:
                //printf("\n Mode '0' Identified");
                if(displayInfo.modeData->enableScrolling)
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, topMsgLenInCols / 8-pSi->offset);
                            }
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if((displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling)||((displayInfo.mode == 0)&&(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)))
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, bottomMsgLenInCols / 8-pSi->offset);
                            }
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // when scrolling is not enabled /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(displayInfo.modeData->enableScrolling == 0)
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                break;
                case 1:
                //printf("\n Mode '1' Identified");
                if(displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling)
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if(displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, topMsgLenInCols / 8-pSi->offset);
                            }
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if((displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling)||((displayInfo.mode == 0)&&(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)))
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, bottomMsgLenInCols / 8-pSi->offset);
                            }
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // when scrolling is not enabled /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                else if(displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling == 0)
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                break;
                case 2:
                    //printf("\n Mode '2' Identified");
                if(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling||displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling)
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf, topMsgLenInCols / 8);
                            }
                            else if(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling == 0)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                            }
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if((displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling))
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, bottomMsgLenInCols / 8-pSi->offset);
                            }
                            else if(displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling == 0)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                            }
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                else if((displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling == 0)&&(displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling == 0))
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                break;
                case 3:
                //printf("\n Mode '3' Identified");
                //printf("\n scrolling status for TOP_SCROLL_BLOCK for Mode 3 is %d",displayInfo.modeData[TOP_SCROLL_BLOCK_FOR_MODE_3].enableScrolling);
                //printf("\n scrolling status for BOTTOM_SCROLL_BLOCK for Mode 3 is %d",displayInfo.modeData[BOTTOM_SCROLL_BLOCK_FOR_MODE_3].enableScrolling);
                if((displayInfo.modeData[TOP_SCROLL_BLOCK_FOR_MODE_3].enableScrolling)||(displayInfo.modeData[BOTTOM_SCROLL_BLOCK_FOR_MODE_3].enableScrolling))
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if(displayInfo.modeData[TOP_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 1)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, topMsgLenInCols / 8-pSi->offset);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                            }
                            else if(displayInfo.modeData[TOP_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 0)
                            {
                                memcpy(&pSi->scrollMsgBuf[i][0],pMsgBuf,topMsgLenInCols / 8);
                            }
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            if(displayInfo.modeData[BOTTOM_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 1)
                            {
                            memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, bottomMsgLenInCols / 8-pSi->offset);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                            }
                            else if(displayInfo.modeData[BOTTOM_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 0)
                            {
                                memcpy(&pSi->scrollMsgBuf[i][0],pMsgBuf,bottomMsgLenInCols / 8);
                            }
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                else if((displayInfo.modeData[TOP_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 0)&&(displayInfo.modeData[BOTTOM_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 0))
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                break;
                default:
                //printf("\n Default");
                //else if(displayInfo.modeData->enableScrolling == 0)
                {
                    for (int i = 0; i < pSi->numRows; i++)
                    {
                        // Scroll blocks are equally divided
                        if (i < (pSi->numRows / 2))
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                            pMsgBuf += topMsgLenInCols / 8;
                        }
                        else
                        {
                            memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                            memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                            pMsgBuf += bottomMsgLenInCols / 8;
                        }
                    }
                }
                break;
            }
            /*if((displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)||(displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling))
            {
                printf("\n entered into current task");
                for (int i = 0; i < pSi->numRows; i++)
                {
                    // Scroll blocks are equally divided
                    if (i < (pSi->numRows / 2))
                    {
                        memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                        if(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)
                        {
                        memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, topMsgLenInCols / 8-pSi->offset);
                        }
                        memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                        pMsgBuf += topMsgLenInCols / 8;
                    }
                    else
                    {
                        memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                        if((displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling)||((displayInfo.mode == 0)&&(displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling)))
                        {
                        memcpy(&pSi->scrollMsgBuf[i][Scroll_Start_Position], pMsgBuf+pSi->offset, bottomMsgLenInCols / 8-pSi->offset);
                        }
                        memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, pSi->offset);
                        pMsgBuf += bottomMsgLenInCols / 8;
                    }
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            // when scrolling is not enabled /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            else if(displayInfo.modeData->enableScrolling == 0)
            {
                for (int i = 0; i < pSi->numRows; i++)
                {
                    // Scroll blocks are equally divided
                    if (i < (pSi->numRows / 2))
                    {
                        memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                        memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, topMsgLenInCols / 8);
                        pMsgBuf += topMsgLenInCols / 8;
                    }
                    else
                    {
                        memset(&pSi->scrollMsgBuf[i][0], 0, MAX_MESSAGE_LEN);
                        memcpy(&pSi->scrollMsgBuf[i][0], pMsgBuf, bottomMsgLenInCols / 8);
                        pMsgBuf += bottomMsgLenInCols / 8;
                    }
                }
            }*/
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
    return;
}

/*

*/
void scrollMessageBuf(uint8_t scrollBlock, uint16_t col)
{
    SCROLL_INFO *pSi = &scrollInfo;
    uint8_t scrollBlockIndex = 0;
    uint8_t startRi = 0, endRi = 0;
    uint8_t scrollCountIncr[MAX_SCROLL_BLOCKS] = {0};

    switch (scrollBlock)
    {
    case TOP_SCROLL_BLOCK:
        startRi = 0;
        endRi = pSi->numRows / 2;
        break;

    case BOTTOM_SCROLL_BLOCK:
        startRi = pSi->numRows / 2;
        endRi = pSi->numRows;
        break;

    default:
        startRi = 0;
        endRi = pSi->numRows;
        break;
    }

    for (int ri = startRi; ri < endRi; ri++)
    {
        scrollBlockIndex = ri < (pSi->numRows / 2) ? TOP_SCROLL_BLOCK : BOTTOM_SCROLL_BLOCK;

        /* Shift the current message buffer in the configured direction */
        if (pSi->scrollDir == SCROLL_LEFT)
        {
            if (!scrollCountIncr[scrollBlockIndex])
            {
                if (++pSi->currIndex[scrollBlockIndex] > (pSi->scrollMsgLen[scrollBlockIndex] * 8))
                {
                    pSi->currIndex[scrollBlockIndex] = 0;
                }
                scrollCountIncr[scrollBlockIndex]++;
            }
            shiftLeft(&pSi->scrollMsgBuf[ri][col / 8], pSi->scrollMsgLen[scrollBlockIndex]);
        }
        else
        {
            if (!scrollCountIncr[scrollBlockIndex])
            {
                if (++pSi->currIndex[scrollBlockIndex] > (pSi->scrollMsgLen[scrollBlockIndex] * 8))
                {
                    pSi->currIndex[scrollBlockIndex] = 0;
                }
                scrollCountIncr[scrollBlockIndex]++;
            }
            shiftRight(&pSi->scrollMsgBuf[ri][col / 8], pSi->scrollMsgLen[scrollBlockIndex]);
        }

        /* Scrolled message is available in pSi->scrollMsgBuf */
    }
}

void copyScrolledBuffer(uint8_t *pDest)
{
    SCROLL_INFO *pSi = &scrollInfo;
#if 0
    uint8_t mode = displayInfo.mode;
    int copyVal = 0;
#endif

    // Copy row at a time
    for (int ri = 0; ri < MAX_ROWS; ri++)
    {

        {
            memcpy(pDest, &pSi->scrollMsgBuf[ri][0], pSi->dispLen);
            pDest += pSi->dispLen;
        }
    }
}

uint8_t scrollDone(uint8_t modeIndex)
{
    SCROLL_INFO *pSi = &scrollInfo;

    // Mode 0 never scrolls
    // if (!modeIndex)
    // return 0;

    // Todo, use mode to determine if top or bottom scroll is done
    if (pSi->currIndex[modeIndex] == (pSi->scrollMsgLen[modeIndex] * 8))
    {
        // printf("ci %d, mw %d\n", (int)pSi->currIndex[modeIndex], (int)pSi->scrollMsgLen[modeIndex]);
        return 1;
    }
    else
        return 0;
}