/* hvrprot.c: Implements functions that interpret Hanover wire and message protocol
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/uart.h"
#else
#include <stdint.h>
#include <errno.h>
#endif
#include "hvrprot.h"
#include "uart.h"
#include "utils.h"
#include "rcerr.h"
#include "display.h"
#include "displaycharlib.h"
#include "main.h"
#include "lastmsg.h"
#include "flashchip.h"
#ifdef ENABLE_PID_DTC
#include "pid_dtc.h"
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////functions ///////////////////////////////////////////////////////////////////////////////////
uint8_t getCharWidth(uint32_t char_Value);
int getTextWidth(uint8_t * data_array);
int getBoardSize(void);
int Check_Data_Size_and_Reframe_If_Needed(int Total_Data_Length,uint8_t modeIndex);
//////////////////////////////////////////////////////////////////////////////////////////////////////

#define CENTER_TEXT 

uint8_t modeProcessingStart = 0;
uint8_t payloadProcessingStart = 0;
uint16_t vertBufferLen = 0;
uint16_t horizBufferLen = 0;
uint8_t enableTopScrolling = 0;
uint8_t enableBottomScrolling = 0;
uint8_t vertBuffer[MAX_VERTICAL_BYTE_BUFFER][2] = {0};
uint8_t horizBuffer[MAX_ROWS][MAX_HORIZONTAL_BYTE_BUFFER] = {0};
uint topBufferLen = 0;
uint bottomBufferLen = 0;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t hvrprot_Test_Mode_Message_Flag = 0,hvrprot_Test_Mode_Scroll_Completed_Flag = 0,hvrprot_Test_Mode_Message_Triggered_Flag = 0;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
extern bool Powerflag;
extern int PwmBrightValue,PwmDimValue;
///////////////////////////////////////////////////////////////////////////////////
//////////////// Display Width in Columns ////////////////////////////////////////
uint8_t DISPLAY_WIDTH_IN_COLUMNS2hvrc = 144;

#ifdef ENABLE_PICO
#endif
/////////////////////////////////////////////////////////////////////////////////

MESSAGE_INFO messageInfo = {0};
#ifdef ENABLE_PICO
#endif

uint8_t tokencmp (uint8_t *pToken, uint8_t *pSrc, uint8_t len)
{
    uint8_t rc = 1;

    for (uint8_t i = 0; i < len; i++)
    {
        // Check the src for token terminator
        switch(pSrc[i])
        {
            case '{':
            case ' ':
            case '\\':
            case '}':
                return rc;
                break;

            default:
                if (pToken[i] != pSrc[i])
                    return rc;
                break;
        }
    }

    rc = 0;

    return rc;
}

/*
parseToken
This function parses tokens and populates the message data structure 
*/
uint8_t parseToken(uint8_t *pBuf, int len, uint8_t *pIndexAdvance)
{
    uint8_t rc = RC_SUCCESS;
    static TOKEN_INFO tokens[] = {
        {"mode", 1},
        {"fit", 1},
        {"rep", 1},
        {"isp", 1},
        {"picw", 1},
        {"pich", 1},
        {"pic", 0}, // Needs to be after picw and pich
        {"afs", 1},
        {"hs", 1},
        {"mss", 1},
        {"link", 1},
        {"sl", 0},
        {"sr", 0},
        {"fs", 0},
        {"rw", 1},
        {"fl",1},
        {"tpm",0},
        {0,0}
    };
    uint8_t tokenLen = 0;
    uint8_t tokenValue = 0;
    uint16_t value = 0;
    uint8_t tempBuf[MAX_TOKEN_VALUE_LEN];

    // The terminating character of a token can be "}" or " " or "\" or "}"
    for (uint8_t i = 0; i < (sizeof(tokens) / sizeof(TOKEN_INFO)); i++)
    {
        if (!tokens[i].name)
        {
            tokenValue = 0;
            // Did not recognize the token, skip it 
            while (tokenValue < len)
            {
                if ((pBuf[tokenValue] == '\\') || (pBuf[tokenValue] == ' ') ||
                    (pBuf[tokenValue] == '}') || (pBuf[tokenValue] == '{'))
                {
                    break;
                }
                tokenValue++;
            }
            *pIndexAdvance += tokenValue;
            goto exit;
        }

        tokenLen = mtpl_strlen((uint8_t *)tokens[i].name);
        if (!tokencmp ((uint8_t *)tokens[i].name, pBuf, tokenLen))
        {
            *pIndexAdvance = tokenLen;
            if (tokens[i].extensionPresent)
            {
                // We have 1 or 4 numbers following the token, use ' ' or '\' as the terminator
                pBuf += tokenLen;
                tokenValue = 0;
                len -= tokenLen;

                if (len > 0)
                {
                    mtpl_memcpy(tempBuf, pBuf, MAX_TOKEN_VALUE_LEN);
                    tokenValue = 0;
                    while (tokenValue < MAX_TOKEN_VALUE_LEN)
                    {
                        if ((tempBuf[tokenValue] == '\\') || (tempBuf[tokenValue] == ' ') ||
                            (tempBuf[tokenValue] == '}') || (tempBuf[tokenValue] == '{'))
                        {
                            tempBuf[tokenValue] = 0; // NULL terminate
                            // printf("Parsing token value %s, mode %d, modeidx %d\r\n", tempBuf, messageInfo.mode, messageInfo.modeIndex);
                            value = mtpl_atoi(tempBuf);
                            if (value < 0)
                            {
                                printf("\n RC_INVALID_TOKEN_VALUE");
                                rc = RC_INVALID_TOKEN_VALUE;
                                return rc;
                            }
                            else
                            {
                                // printf("Checking token %s, value %d\r\n", tokens[i].name, value);
                                if (!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)PICW_TOKEN, mtpl_strlen((uint8_t *)PICW_TOKEN)))
                                {
                                    messageInfo.modeData[messageInfo.modeIndex].payloadType = BINARY_PAYLOAD;
                                    // If this is the second mode index, use the values from the 
                                    // first mode as the starting row and col
                                    switch (messageInfo.mode)
                                    {
                                        case 1: // Mode 1: 2 Columns
                                            if (messageInfo.modeIndex)
                                                messageInfo.modeData[messageInfo.modeIndex].col = 
                                                    messageInfo.modeData[0].width;
                                            else
                                                messageInfo.modeData[messageInfo.modeIndex].col = 0;
                                            break;

                                        case 2: // Mode 2: 2 lines, Top and Bottom lines from 0, 0
                                            messageInfo.modeData[messageInfo.modeIndex].col = 0;
                                            break;

                                        case 3: // Mode 3: Route No: Top and Bottom lines after Route
                                            if (messageInfo.modeIndex)
                                                messageInfo.modeData[messageInfo.modeIndex].col = 
                                                    messageInfo.modeData[0].width;
                                            else
                                                messageInfo.modeData[messageInfo.modeIndex].col = 0;
                                            break;

                                        default:
                                            break;
                                    }

                                    // Width needs to be multiple of 8, adjust up if needed
                                    if (value % 8)
                                        value = ((value / 8) + 1) * 8;
                                    messageInfo.modeData[messageInfo.modeIndex].width = value;
                                    //printf("Adjusted width %d, modeidx %d\n", value, messageInfo.modeIndex);
                                }
                                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)PICH_TOKEN, mtpl_strlen((uint8_t *)PICH_TOKEN)))
                                {
                                    messageInfo.modeData[messageInfo.modeIndex].payloadType = BINARY_PAYLOAD;
                                    // If this is not the first mode index, use the values from the 
                                    // first mode as the starting row and col
                                    switch (messageInfo.mode)
                                    {
                                        case 1: // Mode 1: Route No and Message line, row is 0 for both
                                            messageInfo.modeData[messageInfo.modeIndex].row = 0;
                                            break;

                                        case 2: // Mode 2, Top and Bottom lines, second line has row no same as height of Top line
                                            if (messageInfo.modeIndex)
                                                messageInfo.modeData[messageInfo.modeIndex].row = 
                                                     messageInfo.modeData[0].height; 
                                            else
                                                messageInfo.modeData[messageInfo.modeIndex].row = 0;
                                            break;

                                        case 3: // Mode 3, Route No, Top and Bottom lines
                                            if (messageInfo.modeIndex == 2)
                                                messageInfo.modeData[messageInfo.modeIndex].row = 
                                                     messageInfo.modeData[1].height; 
                                            else
                                                messageInfo.modeData[messageInfo.modeIndex].row = 0;

                                            break;

                                        default:
                                            break;
                                    }
                                    if (value > MAX_ROWS)
                                        value = MAX_ROWS;
                                    // Needs to be multiple of 8, adjust up if necessary
                                    if (value % 8)
                                        value = ((value / 8) + 1) * 8;
                                    messageInfo.modeData[messageInfo.modeIndex].height = value;
                                }
                                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)REP_TOKEN, mtpl_strlen((uint8_t *)REP_TOKEN)))
                                {
                                    //printf("\n the value of repeat before input is %d\n", value);
                                    //value = value+1;
                                    messageInfo.modeData[messageInfo.modeIndex].repeatCount = value;
                                    // printf("\n messageInfo data structure is %d",messageInfo.modeData[messageInfo.modeIndex].payloadLen);
                                    //printf("\n the value of repeat after input is %d\n", value);
                                }
                                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)FLASH_TOKEN, mtpl_strlen((uint8_t *)FLASH_TOKEN)))
                                {
                                    if (value > 100)
                                    {
                                        messageInfo.modeData[messageInfo.modeIndex].flashOnTime = (value/100) * 100;
                                        messageInfo.modeData[messageInfo.modeIndex].flashOffTime = (1000 - messageInfo.modeData[messageInfo.modeIndex].flashOnTime);
                                        messageInfo.modeData[messageInfo.modeIndex].flashPeriod = (value % 100); // Flash for specified period in seconds
                                    }
                                    else
                                    {
                                        messageInfo.modeData[messageInfo.modeIndex].flashOnTime = DEFAULT_FLASH_ON_TIMEOUT;
                                        messageInfo.modeData[messageInfo.modeIndex].flashOffTime = (1000 - DEFAULT_FLASH_ON_TIMEOUT);
                                        messageInfo.modeData[messageInfo.modeIndex].flashPeriod = DEFAULT_FLASH_PERIOD; // Flash once 
                                    }
                                }
                                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)ROUTE_WIDTH_TOKEN, mtpl_strlen((uint8_t *)ROUTE_WIDTH_TOKEN)))
                                {
                                    //if (value % 8)
                                        //value = ((value / 8) + 1) * 8;
                                    // Route width is already set  
                                    // messageInfo.modeData[0].width = value;
                                }

                                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)FIT_TOKEN, mtpl_strlen((uint8_t *)FIT_TOKEN)))
                                {
                                    messageInfo.modeData[0].fitMode = value;
                                }
                                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            }
                            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            *pIndexAdvance += tokenValue;
                            goto exit;
                            break;
                        }
                        tokenValue++;
                    }
                    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    // printf("\n THe received buffer is \n");
                    // i=0;
                    // while(tempBuf[i])
                    // {
                    //     printf("%c",tempBuf[i]);
                    //     i++;
                    // }
                }
                else
                {
                    // Flash token may not have an extension
                    if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)FLASH_TOKEN, mtpl_strlen((uint8_t *)FLASH_TOKEN)))
                    {
                        messageInfo.modeData[messageInfo.modeIndex].flashOnTime = DEFAULT_FLASH_ON_TIMEOUT;
                        messageInfo.modeData[messageInfo.modeIndex].flashOffTime = (1000 - DEFAULT_FLASH_ON_TIMEOUT);
                        messageInfo.modeData[messageInfo.modeIndex].flashPeriod = DEFAULT_FLASH_PERIOD; // Flash once

                    }
                }
            }
            else
            {
                if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)SHIFT_RIGHT_TOKEN, mtpl_strlen((uint8_t *)SHIFT_RIGHT_TOKEN)))
                {
                    messageInfo.modeData[messageInfo.modeIndex].shiftRight = 1;
                    messageInfo.modeData[messageInfo.modeIndex].shiftLeft = 0;
                    messageInfo.modeData[messageInfo.modeIndex].enableScrolling = 1;
                    printf("ShiftRight Token Received");
                    //printf("\nmessageInfo.modeData[messageInfo.modeIndex].shiftRight = %d ",messageInfo.modeData[messageInfo.modeIndex].shiftRight);
                    //printf("\nmessageInfo.modeData[messageInfo.modeIndex].shiftLeft = %d ",messageInfo.modeData[messageInfo.modeIndex].shiftLeft);
                }
                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)SHIFT_LEFT_TOKEN, mtpl_strlen((uint8_t *)SHIFT_LEFT_TOKEN)))
                {
                    messageInfo.modeData[messageInfo.modeIndex].shiftLeft = 1;
                    messageInfo.modeData[messageInfo.modeIndex].shiftRight = 0;
                    messageInfo.modeData[messageInfo.modeIndex].enableScrolling = 1;
                    //printf("Enable Scrolling on mode %d, idx %d\n", messageInfo.mode, (int)1);
                    printf("ShiftLeft Token Received");
                    //printf("\nmessageInfo.modeData[messageInfo.modeIndex].shiftRight = %d ",messageInfo.modeData[messageInfo.modeIndex].shiftRight);
                    //printf("\nmessageInfo.modeData[messageInfo.modeIndex].shiftLeft = %d ",messageInfo.modeData[messageInfo.modeIndex].shiftLeft);
                }
                else if(!mtpl_memcmp((uint8_t *)tokens[i].name, (uint8_t *)TOP_PRIORITY_MESSAGE, mtpl_strlen((uint8_t *)TOP_PRIORITY_MESSAGE)))
                {
                    
                    messageInfo.Top_Priority_Message_Status = 1;
                    printf("\n TOP_PRIORITY_MESSAGE Received\n");
                    
                }

                goto exit;
                break;
            }
        }
    }

exit:
    return rc;
}

/* This function determines the protocol version of input message 
   If the input message is in BasicX format, returns 1 in the input parameter
*/
/*void identify_protocol_version(uint8_t *pBasicXProtocol)
{
    if (pBasicXProtocol)
    {
        *pBasicXProtocol = 0;

        // If there are '{' in beginning and '}' characters in the end
        // identify it as SuperX else mark it as BasicX
        if((pUart->framing_buffer[0] != '{') && 
            (maxLen > 1 (pUart->framing_buffer[0] != '{'))


    }
}
*/
uint8_t analyze_hanover_message()
{
    uint8_t rc = RC_GENERAL_FAILURE;
    uint8_t indexAdvance = 0;
    int maxLen = pUart->framing_buffer_index;
    uint8_t modeParsed = 0;
    uint8_t val = 0;
    uint16_t payloadIndex = 0;
    uint8_t basicXProtocol = 0;

    //////////////////////// check for panel size //////////////////////////////////////////////////////////////////
    if(systemInfo.Board_Type == 1)
        DISPLAY_WIDTH_IN_COLUMNS2hvrc = (35*4)+4;
    else if(systemInfo.Board_Type == 2)
        DISPLAY_WIDTH_IN_COLUMNS2hvrc = (32*4);
    else if(systemInfo.Board_Type == 3)
        DISPLAY_WIDTH_IN_COLUMNS2hvrc = (32*3);
    
    messageInfo.modeIndex = 0;
    modeProcessingStart = 0;
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////  sample code for extracting data for new message format //////////////////////////////////////////////

    // printf("\nThe length of the message is %d\n",maxLen);
    // int local_count = 0;
    // while(pUart->framing_buffer[local_count])
    // {
    //     printf("%c",(char)pUart->framing_buffer[local_count]);
    //     local_count++;
    // }
    // if((pUart->framing_buffer[maxLen-1]=='}')&&(pUart->framing_buffer[maxLen-2]=='}'))
    // {
    //     printf("\n Not New-Format and message can be processable");
    // }
    // else if(pUart->framing_buffer[maxLen-1]=='}')
    // {       
    //     printf("\n The message is of New-Format");
    //     local_count = 0;
    //     int local_temp_count1 = 0,local_temp_count2 = 0,i_temp_count = 1,arr_count =0;
    //     char temp_arr[10] = {'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'};
    //      while(pUart->framing_buffer[local_count])
    // {
    //     if(pUart->framing_buffer[local_count]=='\\')
    //     local_temp_count1 = local_count;
    //     arr_count = 0;
    //     while(pUart->framing_buffer[local_temp_count1+i_temp_count]!='\\')
    //     {
    //         temp_arr[arr_count]=pUart->framing_buffer[local_temp_count1+i_temp_count];
    //         i_temp_count++;
    //         printf("%c",temp_arr[arr_count]);
    //         arr_count++;
    //     }
    //     sleep_ms(100);
    //     printf("\n");
    //     // printf("%c" is at)
    //     // i++;
    //     //printf("%c",(char)pUart->framing_buffer[local_count]);
    //     local_count++;
    // }

    // }
    // printf("\nThe last  charactar is %c\n",pUart->framing_buffer[maxLen-1]);
    
    ///////////////////////////////////////////////////////////////////////////////////////////////
    for (int i = 0; i < maxLen; i++)
    {
        switch (pUart->framing_buffer[i])
        {

            //////////////////////////////////////////////////////////////////////////////////////////////////////////
            //// Code for Identifying New Message Format ////////////////////////////////////////////////////////////
            case ' ':
            if(i!=maxLen-1) // This line ensures i would not exceed maxLen of the data
            {
            if(pUart->framing_buffer[i+1]=='{')
            {
                printf("\n Message of New format message with mss1 {XXX} Identified Contition Identified");
                printf("\n Contition Identified");
            }
            }
            break;
            /// @brief //////////////////////////////////////////////////////////////////////////////////////////////////
            /// @return /
            case '{':
                if (!modeProcessingStart)
                {
                    modeProcessingStart = 1;
                    messageInfo.modeData[messageInfo.modeIndex].payloadType = TEXT_PAYLOAD;

                }
               
                else if (!payloadProcessingStart)
                {
                    // 2 Consecutive '{' characters implies start of binary payload
                    messageInfo.modeData[messageInfo.modeIndex].payloadType = BINARY_PAYLOAD;
                } 

                break;

            case '}':
                if (modeProcessingStart)
                {
                    if (payloadProcessingStart)
                        messageInfo.modeIndex++;

                    modeProcessingStart = 0;
                    payloadProcessingStart = 0;
                }
                

                break;

            case '\\':
                i++;
                if (i >= maxLen)
                {
                    rc = RC_MISSING_TOKEN;
                    goto quit;
                }
                payloadProcessingStart = 1;
                if (!modeParsed)
                {
                    if (!tokencmp ((uint8_t *)MODE_TOKEN, &pUart->framing_buffer[i], mtpl_strlen((uint8_t *)MODE_TOKEN)))
                    {
                        i += mtpl_strlen((uint8_t *)MODE_TOKEN);

                        // Mode has just the one byte for value
                        if ((pUart->framing_buffer[i] >= '0') && (pUart->framing_buffer[i] <= '9'))
                        {
                            messageInfo.mode = pUart->framing_buffer[i] - '0';
                            modeParsed = 1;
                        }
                        else
                        {
                            rc = RC_INVALID_MODE_VALUE;
                            return rc;
                        } 
                    }
                    else
                    {
                        // If mode processing has not started, ie '{' was not the first character in the payload, this is 
                        // BasicX protocol
                        if (!basicXProtocol && !modeProcessingStart)
                        {
                            basicXProtocol = 1;
                            messageInfo.mode = 0;
                            messageInfo.modeIndex = 0;
                            messageInfo.modeData[messageInfo.modeIndex].payloadType = TEXT_PAYLOAD;
                        }
                        if (basicXProtocol)
                        {
                            switch (pUart->framing_buffer[i])
                            {
                                case BASICX_STATIC_PHRASE:
                                    messageInfo.modeData[messageInfo.modeIndex].payloadType = TEXT_PAYLOAD;
                                    break;

                                case BASICX_FLASH:
                                    messageInfo.modeData[messageInfo.modeIndex].flashOnTime = DEFAULT_FLASH_ON_TIMEOUT;
                                    messageInfo.modeData[messageInfo.modeIndex].flashOffTime = 1000 - DEFAULT_FLASH_ON_TIMEOUT; 
                                    break;

                                case BASICX_PAUSE_2SEC:
                                    messageInfo.modeData[messageInfo.modeIndex].flashPeriod += 2;
                                    break;

                                case BASICX_SCROLL_LEFT:
                                    messageInfo.modeData[messageInfo.modeIndex].shiftLeft = 1;
                                    messageInfo.modeData[messageInfo.modeIndex].enableScrolling = 1;
                                    break;

                                case BASICX_SCROLL_RIGHT:
                                    messageInfo.modeData[messageInfo.modeIndex].enableScrolling = 1;
                                    break;

                            }
                        }
                    }
                }
                else
                {
                    indexAdvance = 0;
                    rc = parseToken(&pUart->framing_buffer[i], (maxLen - i), &indexAdvance);
                    if (RC_SUCCESS == rc)
                    {
                        if (indexAdvance)
                            indexAdvance--; // for loop will advance it by one 
                        i += indexAdvance;
                    }
                    else
                        return rc;
                }
                break;

            default:
                payloadProcessingStart = 1;
                // Assemble display payload (ASCII or Bitmap)
                if (modeParsed)
                {
                    payloadIndex = 0;
                    while ((i < maxLen) && pUart->framing_buffer[i] != '}' && 
                        (payloadIndex < sizeof(messageInfo.modeData[messageInfo.modeIndex].data)))
                    {
                        if (messageInfo.modeData[messageInfo.modeIndex].payloadType == BINARY_PAYLOAD)
                        {
                            if (pUart->framing_buffer[i] == ' ')
                            {
                                i++;
                                continue;
                            }
                            if ((pUart->framing_buffer[i] >= '0') && (pUart->framing_buffer[i] <= '9'))
                            {    
                                val = ((pUart->framing_buffer[i] - '0') << 4) & 0xF0;
                            }
                            else if ((pUart->framing_buffer[i] >= 'A') && (pUart->framing_buffer[i] <= 'F'))
                            {
                                val = (((pUart->framing_buffer[i] - 'A') + 10) << 4) & 0xF0;
                            }
                            else if ((pUart->framing_buffer[i] >= 'a') && (pUart->framing_buffer[i] <= 'f'))
                            {
                                val = (((pUart->framing_buffer[i] - 'a') + 10) << 4) & 0xF0;
                            }
                            else
                            {
                                rc = RC_INVALID_BINARY_PAYLOAD;
                                return rc;
                            }

                            // Process the next nibble
                            i++;
                            if ((i < maxLen) && pUart->framing_buffer[i] != '}')
                            {
                                if ((pUart->framing_buffer[i] >= '0') && (pUart->framing_buffer[i] <= '9'))
                                {    
                                    val |= ((pUart->framing_buffer[i] - '0')) & 0x0F;
                                }
                                else if ((pUart->framing_buffer[i] >= 'A') && (pUart->framing_buffer[i] <= 'F'))
                                {
                                    val |= ((pUart->framing_buffer[i] - 'A') + 10) & 0x0F;
                                }
                                else if ((pUart->framing_buffer[i] >= 'a') && (pUart->framing_buffer[i] <= 'f'))
                                {
                                    val |= ((pUart->framing_buffer[i] - 'a') + 10) & 0x0F;
                                }
                                else
                                {
                                    rc = RC_INVALID_BINARY_PAYLOAD;
                                    return rc;
                                }

                                messageInfo.modeData[messageInfo.modeIndex].data[payloadIndex++] = val;
                            }
                            else
                            {
                                rc = RC_SHORT_BINARY_PAYLOAD; 
                                return rc;
                            }
                        } // Binary payload 
                        else // Text payload
                        {
                            messageInfo.modeData[messageInfo.modeIndex].data[payloadIndex++] = 
                                pUart->framing_buffer[i];
                        }
                        i++;
                    }

                    if (payloadIndex >= sizeof(messageInfo.modeData[messageInfo.modeIndex].data))
                    {
                        rc = RC_MESSAGE_TOO_LARGE;
                        return rc;
                    }
                    else
                    {
                        messageInfo.modeData[messageInfo.modeIndex].payloadLen = payloadIndex;

                        if ((i < maxLen) && pUart->framing_buffer[i] == '}') 
                        {
                            if (modeProcessingStart)
                            {
                                if (payloadProcessingStart)
                                    messageInfo.modeIndex++;

                                modeProcessingStart = 0;
                                payloadProcessingStart = 0;
                            }
                        }
                    }
                }
                else if (basicXProtocol)
                {
                    uint8_t escapeSeq = 0;
                    payloadIndex = 0;
                    while ((i < maxLen) && 
                        (payloadIndex < sizeof(messageInfo.modeData[messageInfo.modeIndex].data)))
                    {
                        if (!escapeSeq && (pUart->framing_buffer[i] == '\\'))
                        {
                            escapeSeq = 1;
                            i++;
                            continue;
                        }

                        if (escapeSeq)
                        {
                            switch (pUart->framing_buffer[i])
                            {
                                case BASICX_STATIC_PHRASE:
                                    messageInfo.modeData[messageInfo.modeIndex].payloadType = TEXT_PAYLOAD;
                                    break;

                                case BASICX_FLASH:
                                    messageInfo.modeData[messageInfo.modeIndex].flashOnTime = DEFAULT_FLASH_ON_TIMEOUT;
                                    messageInfo.modeData[messageInfo.modeIndex].flashOffTime = 1000 - DEFAULT_FLASH_ON_TIMEOUT; 
                                    break;

                                case BASICX_PAUSE_2SEC:
                                    messageInfo.modeData[messageInfo.modeIndex].flashPeriod += 2;
                                    break;

                                case BASICX_SCROLL_LEFT:
                                    messageInfo.modeData[messageInfo.modeIndex].shiftLeft = 1;
                                    messageInfo.modeData[messageInfo.modeIndex].enableScrolling = 1;
                                    break;

                                case BASICX_SCROLL_RIGHT:
                                    messageInfo.modeData[messageInfo.modeIndex].enableScrolling = 1;
                                    break;

                            }
                            escapeSeq = 0;
                        }
                        else
                        {
                            if (messageInfo.modeData[messageInfo.modeIndex].payloadType == TEXT_PAYLOAD)
                                messageInfo.modeData[messageInfo.modeIndex].data[payloadIndex++] = pUart->framing_buffer[i];
                    
                        }

                        i++;
                    }

                    // Increment modeIndex if the payload was processed correctly
                    if ((payloadIndex < sizeof(messageInfo.modeData[messageInfo.modeIndex].data)))
                    {
                        messageInfo.mode = 0;
                        messageInfo.modeData[messageInfo.modeIndex].row = 0;
                        messageInfo.modeData[messageInfo.modeIndex].col = 0;
                        messageInfo.modeData[messageInfo.modeIndex].width = (payloadIndex * 8);
                        messageInfo.modeData[messageInfo.modeIndex].height = 16;
                        messageInfo.modeData[messageInfo.modeIndex].payloadLen = payloadIndex;
                        messageInfo.modeIndex++;
                        rc = RC_SUCCESS;
                    }
                }
                break;
        }
    }
    
    


quit:
    return rc;
}

/*
   Returns the font value from the font table at the specified row
*/
uint8_t getFontValue(uint8_t ch, uint8_t fontRow, uint8_t fontTable8x8)
{
    uint8_t fontValue = 0;

    if (fontTable8x8)
    {
        if (ch >= 'A' && ch <= 'Z')
        {
            fontValue = CapitalFontTable8x8[ch - 'A'].font[fontRow];
        }
        else if (ch >= 'a' && ch <= 'z')
        {
            fontValue = SmallFontTable8x8[ch - 'a'].font[fontRow];
        }
        else if (ch >= '0' && ch <= '9')
        {
            fontValue = NumberFontTable8x8[ch - '0'].font[fontRow];
        }
        else if (ch >= '!' && ch <= '/')
        {
            fontValue = SpecialChar8x8set1[ch - '!'].font[fontRow];
        }

        else if (ch >= ':' && ch <= '@')
        {
            fontValue = SpecialChar8x8set2[ch - ':'].font[fontRow];
        }

        else if (ch >= '[' && ch <= '`')
        {
            fontValue = SpecialChar8x8set3[ch - '['].font[fontRow];
        }
        
        else if (ch >= '{' && ch <= '~')
        {
            fontValue = SpecialChar8x8set4[ch - '{'].font[fontRow];
        }
    }
    else
    {
        if (ch >= 'A' && ch <= 'Z')
        {
            fontValue = CapitalFontTable8x16[ch - 'A'].font[fontRow];
        }
        else if (ch >= 'a' && ch <= 'z')
        {
            fontValue = SmallFontTable8x16[ch - 'a'].font[fontRow];
        }
        else if (ch >= '0' && ch <= '9')
        {
            fontValue = NumberFontTable8x16[ch - '0'].font[fontRow];
        }
       
        else if (ch >= '!' && ch <= '/')
        {
            fontValue = SpecialChar8x16set1[ch - '!'].font[fontRow];
        }

        else if (ch >= ':' && ch <= '@')
        {
            fontValue = SpecialChar8x16set2[ch - ':'].font[fontRow];
        }

        else if (ch >= '[' && ch <= '`')
        {
            fontValue = SpecialChar8x16set3[ch - '['].font[fontRow];
        }
        
        else if (ch >= '{' && ch <= '~')
        {
            fontValue = SpecialChar8x16set4[ch - '{'].font[fontRow];
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////
    }

    return fontValue;
}

uint8_t transform_to_vert_buffer()
{
    uint8_t rc = RC_SUCCESS;
    uint16_t copyIndex = 0;
    uint16_t routeIndex = 0;
    uint16_t colLen = 0;
    uint16_t vertColIndex = 0;
    uint8_t lowByte, highByte;
    uint8_t tmpValue;
    int col = 0, Remaining_Empty_Space = 0;
    uint8_t fontRow = 0;
    uint8_t fontTable8x8 = 0;
    uint8_t charsize = 7;
    uint8_t Board_Size =0;
    int Text_Payload_Data_Length = 0;
    int Total_Data_Length =0;

    mtpl_memset(&vertBuffer[0][0], 0, sizeof(vertBuffer));
    Board_Size=getBoardSize();

    for (uint8_t modeIndex = 0; modeIndex < messageInfo.modeIndex; modeIndex++)
    {
        //printf("\n The Payload is %d\n", (int)messageInfo.modeData[modeIndex].payloadType);
        if (messageInfo.modeData[modeIndex].payloadType == TEXT_PAYLOAD)
        {
            //printf("\n Identified Pay load is TEXT_PAYLOAD");
            switch (messageInfo.mode)
            {
                case 0: // Mode 0
                    messageInfo.modeData[modeIndex].row = 0;
                    messageInfo.modeData[modeIndex].col = 0;
                    //int Text_Payload_Data_Length = messageInfo.modeData[modeIndex].payloadLen * 8;
                    //printf("\n Received Data is \n");
                    Total_Data_Length = getTextWidth(messageInfo.modeData[modeIndex].data);
                    Text_Payload_Data_Length = Total_Data_Length;
                    Total_Data_Length = Check_Data_Size_and_Reframe_If_Needed(Total_Data_Length,modeIndex);
                    fontTable8x8 = 0;
#ifdef CENTER_TEXT
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Begins////////////////////////////////////////////////////////////////////
                    //int Text_Payload_Data_Length = messageInfo.modeData[modeIndex].payloadLen * 8;
                               
                    if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<Board_Size)) // board is 140x16
                    {
                        
                        Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                       
                    }
                    else if((systemInfo.Board_Type == 2)&&(Text_Payload_Data_Length<Board_Size)) 
                    {
                       
                        Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                        
                    }
                    else if((systemInfo.Board_Type == 3)&&(Text_Payload_Data_Length<Board_Size))
                    {
                        Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    // printf("\n The Length of the Text Payload is %d",Text_Payload_Data_Length);
                    vertColIndex = copyIndex;
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Ends////////////////////////////////////////////////////////////////////
#endif
                   
                    for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
                    {
                        charsize = getCharWidth(messageInfo.modeData[modeIndex].data[len]);
                        // This is mode 0, it uses 8x16 fonts
                        for (col = charsize; col >= 0; col--)
                        {
                            lowByte = 0;
                            highByte = 0;

                            for (fontRow = 0; fontRow < 16; fontRow++)
                            {
                                tmpValue = getFontValue(messageInfo.modeData[modeIndex].data[len], fontRow, fontTable8x8);
                                
                                if (fontRow < 8)
                                {
                                    if ((tmpValue & (1 << col)))
                                        lowByte |= (1 << (fontRow));
                                }
                                else 
                                {
                                    if ((tmpValue & (1 << col)))
                                        highByte |= (1 << (fontRow - 8));
                                }
                            }

                            // Populate VerticalBuffer
                            vertBuffer[vertColIndex][0] = lowByte;
                            vertBuffer[vertColIndex][1] = highByte;

                            vertColIndex++;
                        }
                    }

                    messageInfo.modeData[modeIndex].width = vertColIndex - messageInfo.modeData[modeIndex].col;
                    // Figure out whether this text needs to be scrolled
                    //printf("Dispwidth = %d, DataWidth = %d\r\n", DISPLAY_WIDTH_IN_COLUMNS2hvrc, messageInfo.modeData[modeIndex].width);
                    if (DISPLAY_WIDTH_IN_COLUMNS2hvrc < messageInfo.modeData[modeIndex].width
                        || messageInfo.modeData[modeIndex].repeatCount)
                    {
                        messageInfo.modeData[modeIndex].enableScrolling = 1;
                    }
                    break;

                case 1: // Mode 1
                    messageInfo.modeData[modeIndex].row = 0;
                    if (!modeIndex)
                    {
                        messageInfo.modeData[modeIndex].col = vertColIndex;
                        //printf("\n MODE 1:Mode Index is %d, THE value of modeData[modeIndex].col = %d",modeIndex,vertColIndex);
                    }
                    else
                    {
                         messageInfo.modeData[modeIndex].col =  messageInfo.modeData[0].width;
                         //printf("\n MODE 1:Mode Index is %d, THE value of modeData[modeIndex].col = %d",modeIndex,messageInfo.modeData[modeIndex].col);
                    }

                    fontTable8x8 = 0;
                    //sleep_ms(100);
                        Total_Data_Length = getTextWidth(messageInfo.modeData[modeIndex].data);
                        Text_Payload_Data_Length = Total_Data_Length;
                        Total_Data_Length = Check_Data_Size_and_Reframe_If_Needed(Total_Data_Length,modeIndex);
#ifdef CENTER_TEXT
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Begins////////////////////////////////////////////////////////////////////
                    if(modeIndex)
                    {
                        int Mode1_Route_Width = vertColIndex;
                        //printf("\n Text Payload Data Length = %d",Text_Payload_Data_Length);
                        if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width))) // board is 140x16
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        if(Remaining_Empty_Space>=1)
                        {
                        copyIndex = ((Remaining_Empty_Space/8)*8)+Mode1_Route_Width;
                        //printf("\n in if(Remaining_Empty_Space>=1)");
                        }
                    }
                    else if((systemInfo.Board_Type == 2)&&(Text_Payload_Data_Length<=(Board_Size-Mode1_Route_Width))) 
                    {
                        Remaining_Empty_Space = (Board_Size -Mode1_Route_Width)-Text_Payload_Data_Length;
                        //printf("\n Remaining Empty Space 128X16 = %d",Remaining_Empty_Space);
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        if(Remaining_Empty_Space>=1)
                        {
                        copyIndex = ((Remaining_Empty_Space/8)*8)+Mode1_Route_Width;
                        //printf("\n in if(Remaining_Empty_Space>=1) for board 128X16");
                        }
                    }
                    else if((systemInfo.Board_Type == 3)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width)))
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        if(Remaining_Empty_Space>=1)
                        {
                        copyIndex = ((Remaining_Empty_Space/8)*8)+Mode1_Route_Width;
                        }
                    }
                    //printf("\n The Length of the Text Payload is %d",Text_Payload_Data_Length);
                    vertColIndex = copyIndex;
                    //printf("\n Board Size is = %d, copyIndex = %d",Board_Size,copyIndex);
                    if(Text_Payload_Data_Length>=(Board_Size - Mode1_Route_Width))
                    {
                        vertColIndex = copyIndex = Mode1_Route_Width;

                    }
                    //printf("\n vertColIndex is = %d",vertColIndex);
                    //printf("\n vertColIndex = copyIndex = %d",copyIndex);
                    }
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Ends////////////////////////////////////////////////////////////////////
#endif              
                    for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
                    {
                        charsize = getCharWidth(messageInfo.modeData[modeIndex].data[len]);
                        // This is mode 0, it uses 8x16 fonts
                        for (col = charsize; col >= 0; col--)
                        {
                            lowByte = 0;
                            highByte = 0;

                            for (fontRow = 0; fontRow < 16; fontRow++)
                            {
                                tmpValue = getFontValue(messageInfo.modeData[modeIndex].data[len], fontRow, fontTable8x8);

                                if (fontRow < 8)
                                {
                                    if ((tmpValue & (1 << col)))
                                        lowByte |= (1 << (fontRow));
                                }
                                else 
                                {
                                    if ((tmpValue & (1 << col)))
                                        highByte |= (1 << (fontRow - 8));
                                }
                            }

                            // Populate VerticalBuffer
                            vertBuffer[vertColIndex][0] = lowByte;
                            vertBuffer[vertColIndex][1] = highByte;

                            vertColIndex++;
                        }
                    }
                    //printf("\n vertColIndex = %d",vertColIndex);
                    if (!modeIndex)
                        messageInfo.modeData[modeIndex].width = vertColIndex;
                    else
                        messageInfo.modeData[modeIndex].width = vertColIndex - messageInfo.modeData[0].col;
                    

                    messageInfo.modeData[modeIndex].height = 16;

                    // In mode 1, Route No is never scrolled, Route name may be scrolled
                    if (modeIndex)
                    {
                        // Figure out whether this text needs to be scrolled
                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc < (messageInfo.modeData[modeIndex].width + messageInfo.modeData[0].width)
                            || messageInfo.modeData[modeIndex].repeatCount)
                        {
                            messageInfo.modeData[modeIndex].enableScrolling = 1;
                        }
                    }
                    break;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////// Mode 2 Text Framing Logic begins ///////////////////////////////////////////////////////////////////////////////////////////
                case 2: // Mode 2, 2 lines of 8 rows each
                    // Restart vertColIndex, because Mode 2 has 2 lines each starting from column 0
                    vertColIndex = 0;

                    messageInfo.modeData[modeIndex].row = modeIndex * 8;
                    messageInfo.modeData[modeIndex].col = vertColIndex;

                    Total_Data_Length = getTextWidth(messageInfo.modeData[modeIndex].data);
                    //printf("\n The Total _Data_Length is %d",Total_Data_Length);
                    //Text_Payload_Data_Length = messageInfo.modeData[modeIndex].payloadLen * 8;
                    Text_Payload_Data_Length = Total_Data_Length;
                    //printf("\n calculation for modeIndex %d",modeIndex);
                    Total_Data_Length = Check_Data_Size_and_Reframe_If_Needed(Total_Data_Length,modeIndex);
                    //printf("\n The Total _Data_Length after Check_Data_Size_and_Reframe_If_Needed is %d",Total_Data_Length);
                    fontTable8x8 = 1;

#ifdef CENTER_TEXT
                    //////////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Begins////////////////////////////////////////////////////////////////////
                    // if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<Board_Size)) // board is 140x16
                    // {
                        
                    //     Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                    //     Remaining_Empty_Space = Remaining_Empty_Space/2;
                    //     copyIndex = (Remaining_Empty_Space/8)*8;
                       
                    // }
                    if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<Board_Size)) // board is 140x16
                    {
                        Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    else if((systemInfo.Board_Type == 2)&&(Text_Payload_Data_Length<Board_Size)) 
                    {
                        Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    else if((systemInfo.Board_Type == 3)&&(Text_Payload_Data_Length<Board_Size))
                    {
                        Remaining_Empty_Space = Board_Size-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    //printf("\n The Length of the Text Payload is %d",Text_Payload_Data_Length);
                    vertColIndex = copyIndex;
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Ends////////////////////////////////////////////////////////////////////
#endif
                    
                    // Mode 2 has 2 lines of height 8 pixels each starting from column 0
                    for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
                    {
                        charsize = getCharWidth(messageInfo.modeData[modeIndex].data[len]);
                        // This is mode 0, it uses 8x16 fonts
                        for (col = charsize; col >= 0; col--)
                        {
                            lowByte = 0;
                            highByte = 0;

                            for (fontRow = 0; fontRow < 8; fontRow++)
                            {
                                tmpValue = getFontValue(messageInfo.modeData[modeIndex].data[len], fontRow, fontTable8x8);

                                if (!modeIndex)
                                {
                                    if ((tmpValue & (1 << col)))
                                        lowByte |= (1 << (fontRow));
                                }
                                else 
                                {
                                    if ((tmpValue & (1 << col)))
                                        highByte |= (1 << (fontRow));
                                }
                            }

                            // Populate VerticalBuffer
                            if (!modeIndex)
                                vertBuffer[vertColIndex][0] = lowByte;
                            else
                                vertBuffer[vertColIndex][1] = highByte;

                            vertColIndex++;
                        }
                    }
                    messageInfo.modeData[modeIndex].width = vertColIndex;
                    messageInfo.modeData[modeIndex].height = 8;
                    //printf("\n ModeIndex %d Text Width is %d",modeIndex,(int) messageInfo.modeData[modeIndex].width);
                    if(modeIndex==0)
                    {
                    // Figure out whether this text needs to be scrolled
                    if (DISPLAY_WIDTH_IN_COLUMNS2hvrc < messageInfo.modeData[modeIndex].width
                        || messageInfo.modeData[modeIndex].repeatCount)
                    {
                        messageInfo.modeData[modeIndex].enableScrolling = 1;
                        //printf("\n messageInfo.modeData[modeIndex] : %s",messageInfo.modeData[modeIndex].data);
                        //printf("\n 1st Enabled Scrolling for ModeIndex %d",modeIndex);
                    }
                    }
                    else if(modeIndex==1)
                    {
                        // Figure out whether this text needs to be scrolled
                    if (DISPLAY_WIDTH_IN_COLUMNS2hvrc < messageInfo.modeData[modeIndex].width
                        || messageInfo.modeData[modeIndex].repeatCount)
                    {
                        messageInfo.modeData[modeIndex].enableScrolling = 1;
                        //printf("\n messageInfo.modeData[modeIndex] : %s",messageInfo.modeData[modeIndex].data);
                        //printf("\n 2nd Enabled Scrolling for ModeIndex %d",modeIndex);
                    }
                    }
                    break;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
                case 3: // Mode 3, 16 row Route No followed by 2 rows of Route names of 8 rows each
                    if (!modeIndex)
                        vertColIndex = 0;
                    else
                    {
                        vertColIndex = messageInfo.modeData[0].width;
                    }
                    Total_Data_Length = getTextWidth(messageInfo.modeData[modeIndex].data);
                    //printf("\n ***********************************************************************************");
                    //printf("\n Total_Data_Length for ModeIndex %d is %d", modeIndex,Total_Data_Length);
                    Text_Payload_Data_Length = Total_Data_Length;
                    //printf("\n Total_Data_Length = %d before Reframing", Text_Payload_Data_Length);
                    Total_Data_Length = Check_Data_Size_and_Reframe_If_Needed(Total_Data_Length,modeIndex);
                    //printf("\n Total_Data_Length = %d after Reframing", Total_Data_Length);
                    //printf("\n ***********************************************************************************");
                    if (modeIndex < 2)
                    {
                        /// @brief ///////////////////////////////////////////////////////////////////////////////////
                        ///////////January 31 17:46
                        copyIndex = (messageInfo.availableDisplayWidth / 2); 
                            if (copyIndex % 8)
                            {
                                copyIndex = (copyIndex/8) * 8;
                            }
                        /// @brief ////////////////////////////////////////////////////////////////////////////////////
                        messageInfo.modeData[modeIndex].row = 0;
                        if (!modeIndex)
                            messageInfo.modeData[modeIndex].col = 0;
                        else
                            messageInfo.modeData[modeIndex].col = messageInfo.modeData[0].width;
                    }
                    else if (modeIndex == 2)
                    {
                        messageInfo.modeData[modeIndex].row = 8;
                        messageInfo.modeData[modeIndex].col = messageInfo.modeData[0].width;
                    }

                    if (modeIndex == 0)
                    {
                        fontTable8x8 = 0;
                        vertColIndex = 0;
                        //printf("\n ModeIndex = %d Pocessing",modeIndex);
                        for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
                        {
                            charsize = getCharWidth(messageInfo.modeData[modeIndex].data[len]);
                            //printf("\n **********************************************The character is tmpValue is %c***************************************",messageInfo.modeData[modeIndex].data[len]);
                            // This is mode 0, it uses 8x16 fonts
                            for (col = charsize; col >= 0; col--)
                            {
                                lowByte = 0;
                                highByte = 0;

                                for (fontRow = 0; fontRow < 16; fontRow++)
                                {
                                    tmpValue = getFontValue(messageInfo.modeData[modeIndex].data[len], fontRow, fontTable8x8);
                                    
                                    if (fontRow < 8)
                                    {
                                        if ((tmpValue & (1 << col)))
                                            lowByte |= (1 << (fontRow));
                                    }
                                    else
                                    {
                                        if ((tmpValue & (1 << col)))
                                            highByte |= (1 << (fontRow - 8));
                                    }
                                }

                                // Populate VerticalBuffer
                                vertBuffer[vertColIndex][0] = lowByte;
                                vertBuffer[vertColIndex][1] = highByte;

                                vertColIndex++;
                            }
                        }

                        messageInfo.modeData[modeIndex].width = vertColIndex;
                    }
                    else if (modeIndex == 1)
                    {
                        fontTable8x8 = 1;
#ifdef CENTER_TEXT
                    ///////////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Begins////////////////////////////////////////////////////////////////////
                    // if(modeIndex)
                    // {
                    //     int Mode1_Route_Width = vertColIndex;
                    //     if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width))) // board is 140x16
                    // {
                    //     Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                    //     Remaining_Empty_Space = Remaining_Empty_Space/2;
                    //     if(Remaining_Empty_Space>=8)
                    //     {
                    //     copyIndex = ((Remaining_Empty_Space/8)*8)+Mode1_Route_Width;
                    //     }
                    // }
                    /////////////////////////////////////////////////////////////////////////////////////////////////////
                    if(modeIndex)
                    {
                        int Mode1_Route_Width = vertColIndex;
                        //printf("\n Processing in ModeIndex = %d",modeIndex);
                        //printf("\n THe width of Mode1 Route Number is %d",Mode1_Route_Width);
                    //Text_Payload_Data_Length = messageInfo.modeData[modeIndex].payloadLen * 8;
                    //printf("\n Text_Payload_Data_Length = %d < ((Board_Size = %d - Mode1_Route_Width = %d))",Text_Payload_Data_Length,Board_Size,Mode1_Route_Width);
                    if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width))) // board is 140x16
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        //printf("\n (Remaining_Empty_Space = %d = ((Board_Size = %d - Mode1_Route_Width = %d) - Text_Payload_Data_Length = %d)",Remaining_Empty_Space,Board_Size,Mode1_Route_Width,Text_Payload_Data_Length);
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        //printf("\n (Remaining_Empty_Space = %d = ((Remaining_Empty_Space = %d / 2))",Remaining_Empty_Space,Remaining_Empty_Space);
                        if(Remaining_Empty_Space>=8)
                        {                            
                        copyIndex = ((Remaining_Empty_Space/8)*8);
                        //printf("\n (copyIndex = %d = ((Remaining_Empty_Space = %d / 8)*8)",Remaining_Empty_Space,Remaining_Empty_Space);
                        }
                    }
                    else if((systemInfo.Board_Type == 2)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width))) 
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        //printf("\n (Remaining_Empty_Space = %d = ((Board_Size = %d - Mode1_Route_Width = %d) - Text_Payload_Data_Length = %d)",Remaining_Empty_Space,Board_Size,Mode1_Route_Width,Text_Payload_Data_Length);
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        //printf("\n (Remaining_Empty_Space = %d = ((Remaining_Empty_Space = %d / 2))",Remaining_Empty_Space,Remaining_Empty_Space);
                        if(Remaining_Empty_Space>=8)
                        {
                        copyIndex = ((Remaining_Empty_Space/8)*8);
                        //printf("\n (copyIndex = %d = ((Remaining_Empty_Space = %d / 8)*8)",Remaining_Empty_Space,Remaining_Empty_Space);
                        }
                    }
                    else if((systemInfo.Board_Type == 3)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width)))
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        if(Remaining_Empty_Space>=8)
                        {
                        copyIndex = (Remaining_Empty_Space/8)*8;
                        }
                    }
                    vertColIndex = Mode1_Route_Width+copyIndex;
                    //printf("\n value of VertColIndex at centering business after calculation= %d",vertColIndex);
                    }
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Ends////////////////////////////////////////////////////////////////////
#endif 
                        //vertColIndex = messageInfo.modeData[0].width;

                        for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
                        {
                            charsize = getCharWidth(messageInfo.modeData[modeIndex].data[len]);
                            // This is mode 0, it uses 8x16 fonts
                            for (col = charsize; col >= 0; col--)
                            {
                                lowByte = 0;

                                for (fontRow = 0; fontRow < 8; fontRow++)
                                {
                                    tmpValue = getFontValue(messageInfo.modeData[modeIndex].data[len], fontRow, fontTable8x8);

                                    if ((tmpValue & (1 << col)))
                                        lowByte |= (1 << (fontRow));

                                }

                                // Populate VerticalBuffer
                                vertBuffer[vertColIndex][0] = lowByte;

                                vertColIndex++;
                            }
                        }
                        //printf("\n vertColIndex = %d in ModeIndex 1 outside Centering business", vertColIndex);
                        messageInfo.modeData[modeIndex].width = vertColIndex - messageInfo.modeData[0].width;
                        //printf("\n messageInfo.modeData[modeIndex].width = vertColIndex - messageInfo.modeData[0].width = %d ",messageInfo.modeData[modeIndex].width);
                    }
                    else if (modeIndex == 2)
                    {
                        fontTable8x8 = 1;
#ifdef CENTER_TEXT
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Begins////////////////////////////////////////////////////////////////////
                    if(modeIndex)
                    {
                        int Mode1_Route_Width = vertColIndex;
                        copyIndex = 0;
                    if((systemInfo.Board_Type == 1)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width))) // board is 140x16
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    else if((systemInfo.Board_Type == 2)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width)))
                    {
                        Remaining_Empty_Space = (Board_Size -Mode1_Route_Width)-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    else if((systemInfo.Board_Type == 3)&&(Text_Payload_Data_Length<(Board_Size-Mode1_Route_Width)))
                    {
                        Remaining_Empty_Space = (Board_Size - Mode1_Route_Width)-Text_Payload_Data_Length;
                        Remaining_Empty_Space = Remaining_Empty_Space/2;
                        copyIndex = (Remaining_Empty_Space/8)*8;
                    }
                    vertColIndex = Mode1_Route_Width + copyIndex;
                    //printf("\n value of VertColIndex at centering business after calculation= %d",vertColIndex);
                    }
                    /////////////////////////////////////////////////////////////////////////////////////////////////
                    //////// Centering Business Ends////////////////////////////////////////////////////////////////////
#endif 
                        //vertColIndex = messageInfo.modeData[0].width;

                        for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
                        {
                            charsize = getCharWidth(messageInfo.modeData[modeIndex].data[len]);
                            for (col = charsize; col >= 0; col--)
                            {
                                highByte = 0;

                                for (fontRow = 0; fontRow < 8; fontRow++)
                                {
                                    tmpValue = getFontValue(messageInfo.modeData[modeIndex].data[len], fontRow, fontTable8x8);

                                    if ((tmpValue & (1 << col)))
                                        highByte |= (1 << (fontRow));
                                }

                                // Populate VerticalBuffer
                                vertBuffer[vertColIndex][1] = highByte;

                                vertColIndex++;
                            }
                        }
                        //printf("\n The caluculated value of vertColIndex outside Centering Bussiness is %d",vertColIndex);

                        messageInfo.modeData[modeIndex].width = vertColIndex - messageInfo.modeData[0].width;
                        //printf("\n messageInfo.modeData[modeIndex].width = vertColIndex - messageInfo.modeData[0].width = %d ",messageInfo.modeData[modeIndex].width);
                    }

                    if (modeIndex)
                    {
                        // Figure out whether this text needs to be scrolled
                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc < (messageInfo.modeData[modeIndex].width + messageInfo.modeData[0].width)
                            || messageInfo.modeData[modeIndex].repeatCount)
                        {
                            messageInfo.modeData[modeIndex].enableScrolling = 1;
                            //printf("\n Enabled Scrolling for ModeIndex %d\n",modeIndex);
                            //printf("\n messageInfo.modeData[%d].enableScrolling = %d\n",modeIndex,messageInfo.modeData[modeIndex].enableScrolling);
                        }
                        else
                        {
                            //messageInfo.modeData[modeIndex].enableScrolling = 0;
                            //printf("\n Not Enabled Scrolling for ModeIndex %d\n",modeIndex);
                            //printf("\n messageInfo.modeData[%d].enableScrolling = %d\n",modeIndex,messageInfo.modeData[modeIndex].enableScrolling);
                        }
                    }
                    break;
            }

            // printf("\r\n== Text Payload ==\r\n");// Build the bitmap using font table and the string data in 
            // messageInfo.modeData[modeIndex].data[]
            // for (uint16_t len = 0; len < messageInfo.modeData[modeIndex].payloadLen; len++)
            // {
            //     if (messageInfo.modeData[modeIndex].data[len] >= 'A' && 
            //         messageInfo.modeData[modeIndex].data[len] <= 'Z')
            //     {

            //         // value = CapitalFontTable[messageInfo.modeData[modeIndex].data[len] - 'A']
            //     }
            //     if (messageInfo.modeData[modeIndex].data[len] >= 'a' && 
            //         messageInfo.modeData[modeIndex].data[len] <= 'z')
            //     {
            //         // value = SmallFontTable[messageInfo.modeData[modeIndex].data[len] - 'a']
            //     }
            //     if (messageInfo.modeData[modeIndex].data[len] >= '0' && 
            //         messageInfo.modeData[modeIndex].data[len] <= '9')
            //     {
            //         // value = NumbersFontTable[messageInfo.modeData[modeIndex].data[len] - '0']
            //     }
            // }
        }
        else if (messageInfo.modeData[modeIndex].payloadType == BINARY_PAYLOAD)
        {
            //printf("\n Identified Pay load is BINARY_PAYLOAD");
            switch (messageInfo.mode)
            {
                case 0: // Nothing to do, copy mode0 buffer to destination
                    copyIndex = 0;
                    // Check if the message needs to be scrolled
                    if (DISPLAY_WIDTH_IN_COLUMNS2hvrc < messageInfo.modeData[0].width
                        || messageInfo.modeData[0].repeatCount)
                    {
                        //printf("\n in if DISPLAY_WIDTH_IN_COLUMNS2hvrc = %d",DISPLAY_WIDTH_IN_COLUMNS2hvrc);
                        //printf("\n in if messageInfo.modeData[0].width = %d",messageInfo.modeData[0].width);
                        //printf("\n in if messageInfo.modeData[0].repeatCount = %d",messageInfo.modeData[0].repeatCount);
                        messageInfo.modeData[0].enableScrolling = 1;
                    }
                    else
                    {
                        //
                        // Message needs to be centered in the available area 
                        // 
                        messageInfo.availableDisplayWidth = DISPLAY_WIDTH_IN_COLUMNS2hvrc - messageInfo.modeData[0].width;
                        //printf("\n in else DISPLAY_WIDTH_IN_COLUMNS2hvrc = %d",DISPLAY_WIDTH_IN_COLUMNS2hvrc);
                        //printf("\n in else messageInfo.modeData[0].width = %d",messageInfo.modeData[0].width);
                        //printf("\n in else messageInfo.availableDisplayWidth = %d",messageInfo.availableDisplayWidth);
#ifdef CENTER_TEXT
                        // Move the copy start
                        copyIndex = messageInfo.availableDisplayWidth / 2;
                        if (copyIndex % 8)
                        {
                            copyIndex = (copyIndex/8)*8;
                        }
#endif
                    }
                    //printf("\n copyIndex = %d",copyIndex);
                    mtpl_memcpy(&vertBuffer[copyIndex][0], messageInfo.modeData[0].data, 
                            messageInfo.modeData[0].width*2);

                    messageInfo.modeData[0].width += copyIndex;
                    vertBufferLen = messageInfo.modeData[0].width; 
                    //topBufferLen = vertBufferLen; 
                    //bottomBufferLen = vertBufferLen;
                    //printf("\n vertBufferLen = %d",vertBufferLen);
                    break;

                case 1: // Mode 1: Route no followed by String: Concatenate mode0 and mode1 indexes

                    copyIndex = 0;
                    if (modeIndex)
                    {
                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc > messageInfo.modeData[0].width)
                        {
                            messageInfo.availableDisplayWidth = (DISPLAY_WIDTH_IN_COLUMNS2hvrc - messageInfo.modeData[0].width);
                            if (messageInfo.availableDisplayWidth > messageInfo.modeData[modeIndex].width)
                            {
#ifdef CENTER_TEXT
                                // Center the message
                                copyIndex = (messageInfo.availableDisplayWidth - messageInfo.modeData[modeIndex].width)/2; 
                                if (copyIndex % 8)
                                {
                                    copyIndex = (copyIndex/8) * 8;
                                }
#endif
                            } 
                            else
                                messageInfo.modeData[modeIndex].enableScrolling = 1;

                        }
                        if (messageInfo.modeData[modeIndex].repeatCount)
                            messageInfo.modeData[modeIndex].enableScrolling = 1;
                    }

                    if(!modeIndex)
                    {
                        // Route no
                        mtpl_memcpy(&vertBuffer[modeIndex][0], messageInfo.modeData[modeIndex].data, 
                                messageInfo.modeData[modeIndex].width*2);
                    }
                    else
                    {
                        // Route name
                        mtpl_memcpy(&vertBuffer[messageInfo.modeData[0].width + copyIndex][0], messageInfo.modeData[modeIndex].data,
                                messageInfo.modeData[modeIndex].width*2);
                        messageInfo.modeData[modeIndex].width += copyIndex;
                    }
                    break;

                case 2: // Two lines starting from Col 0: Load mode0 index in top half of vertBuffer[][] array, mode1 index in bottom half
                    if (!modeIndex)
                    {
                        copyIndex = 0;

                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc > messageInfo.modeData[modeIndex].width)
                        {
                            messageInfo.availableDisplayWidth = (DISPLAY_WIDTH_IN_COLUMNS2hvrc - messageInfo.modeData[modeIndex].width);
#ifdef CENTER_TEXT
                            copyIndex = (messageInfo.availableDisplayWidth / 2); 
                            if (copyIndex % 8)
                            {
                                copyIndex = (copyIndex/8) * 8;
                            }
#endif
                        }
                        else
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        if (messageInfo.modeData[modeIndex].repeatCount)
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        for (int i = 0; i < messageInfo.modeData[modeIndex].width; i++)
                            vertBuffer[i+copyIndex][0] = messageInfo.modeData[modeIndex].data[i]; 

                        messageInfo.modeData[modeIndex].width += copyIndex;
                        topBufferLen = messageInfo.modeData[modeIndex].width;
                    }
                    else 
                    {
                        copyIndex = 0;

                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc > messageInfo.modeData[modeIndex].width)
                        {
                            messageInfo.availableDisplayWidth = (DISPLAY_WIDTH_IN_COLUMNS2hvrc - messageInfo.modeData[modeIndex].width);
#ifdef CENTER_TEXT
                            copyIndex = (messageInfo.availableDisplayWidth / 2); 
                            if (copyIndex % 8)
                            {
                                copyIndex = (copyIndex/8) * 8;
                            }
#endif
                        }
                        else
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        if (messageInfo.modeData[modeIndex].repeatCount)
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        for (int i = 0; i < messageInfo.modeData[modeIndex].width; i++)
                            vertBuffer[i+copyIndex][1] = messageInfo.modeData[modeIndex].data[i];

                        messageInfo.modeData[modeIndex].width += copyIndex;
                        bottomBufferLen = messageInfo.modeData[modeIndex].width; 
                    }

                    break;

                case 3: // Mode 3: Route No, Double line after the Route No: Copy mode0 Index first,
                    // mode1 index to top half of the array at index after end of mode0 and mode2 index
                    // to bottom half of the array at index after end of mode 0

                    if (modeIndex == 0)
                    {
                        mtpl_memcpy(&vertBuffer[modeIndex][0], messageInfo.modeData[modeIndex].data, 
                                messageInfo.modeData[modeIndex].width*2);
                        routeIndex = messageInfo.modeData[modeIndex].width;
                        vertBufferLen = routeIndex;
                    }

                    if (modeIndex == 1)
                    {
                        copyIndex = 0;

                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc > (messageInfo.modeData[modeIndex].width + routeIndex))
                        {
                            messageInfo.availableDisplayWidth = (DISPLAY_WIDTH_IN_COLUMNS2hvrc - 
                                    (messageInfo.modeData[modeIndex].width + routeIndex));
#ifdef CENTER_TEXT
                            copyIndex = (messageInfo.availableDisplayWidth / 2); 
                            if (copyIndex % 8)
                            {
                                copyIndex = (copyIndex/8) * 8;
                            }
#endif
                        }
                        else
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        if (messageInfo.modeData[modeIndex].repeatCount)
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        for (int i = 0; i < messageInfo.modeData[modeIndex].width; i++)
                            vertBuffer[i+routeIndex+copyIndex][0] = messageInfo.modeData[modeIndex].data[i];

                        messageInfo.modeData[modeIndex].width += copyIndex;
                        topBufferLen = vertBufferLen + messageInfo.modeData[modeIndex].width;

                    }

                    if (modeIndex == 2)
                    {
                        copyIndex = 0;

                        if (DISPLAY_WIDTH_IN_COLUMNS2hvrc > (messageInfo.modeData[modeIndex].width + routeIndex))
                        {
                            messageInfo.availableDisplayWidth = (DISPLAY_WIDTH_IN_COLUMNS2hvrc - 
                                    (messageInfo.modeData[modeIndex].width + routeIndex));
#ifdef CENTER_TEXT
                            copyIndex = (messageInfo.availableDisplayWidth / 2); 
                            if (copyIndex % 8)
                            {
                                copyIndex = (copyIndex/8) * 8;
                            }
#endif
                        }
                        else
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        if (messageInfo.modeData[modeIndex].repeatCount)
                            messageInfo.modeData[modeIndex].enableScrolling = 1;

                        for (int i = 0; i < messageInfo.modeData[modeIndex].width; i++)
                            vertBuffer[i+routeIndex+copyIndex][1] = messageInfo.modeData[modeIndex].data[i];
                             
                        messageInfo.modeData[modeIndex].width += copyIndex;
                        bottomBufferLen = vertBufferLen + messageInfo.modeData[modeIndex].width; 

                        if (bottomBufferLen > topBufferLen)
                            colLen = bottomBufferLen;
                        else
                            colLen = topBufferLen;

                        bottomBufferLen = colLen;
                        topBufferLen = colLen;
                        vertBufferLen = colLen; 
                    }
                    break;

                default:
                    rc = RC_INVALID_MODE;; 
                    break;
            }
        }
    } // for all mode indexes

    switch (messageInfo.mode)
    {
        case 0: // Mode 0
            vertBufferLen = messageInfo.modeData[0].width;
            topBufferLen = vertBufferLen; 
            bottomBufferLen = vertBufferLen;
            break;

        case 1: // Mode 1
            vertBufferLen = messageInfo.modeData[0].width + messageInfo.modeData[1].width;
            topBufferLen = vertBufferLen; 
            bottomBufferLen = vertBufferLen;
            break;

        case 2: // Mode 2
            topBufferLen = messageInfo.modeData[0].width; 
            bottomBufferLen = messageInfo.modeData[1].width;
        
            // Length will be larger of the 2 indexes
            vertBufferLen = (topBufferLen > bottomBufferLen) ? topBufferLen : bottomBufferLen; 
            if (bottomBufferLen > topBufferLen)
                colLen = bottomBufferLen;
            else
                colLen = topBufferLen;

            bottomBufferLen = vertBufferLen;
            topBufferLen = vertBufferLen;
            break;

        default:
        case 3:
            topBufferLen = messageInfo.modeData[1].width; 
            bottomBufferLen = messageInfo.modeData[2].width;

            vertBufferLen = messageInfo.modeData[0].width;
            vertBufferLen += (topBufferLen > bottomBufferLen) ? topBufferLen : bottomBufferLen; 

            if (bottomBufferLen > topBufferLen)
                colLen = bottomBufferLen;
            else
                colLen = topBufferLen;

            bottomBufferLen = vertBufferLen;
            topBufferLen = vertBufferLen;
            break;
    }
#ifndef ENABLE_PICO
    FILE *fp;

    if ((fp = fopen("disp.vert", "wb")) != NULL)
    {
        if (fwrite(&vertBuffer[0][0], 1, vertBufferLen*2, fp) < 0)
            printf("Error %d writing to %s\n", errno, "disp.vert");

        fclose (fp);
    }
#endif
    return rc;
}

//void mapVerticalPatternToHorizon(unsigned char *pOperatingBuf, unsigned char *pHorizBuf, int numRows,
//        int numCols)
uint8_t transform_to_horiz_buffer()
{
    uint8_t rc = RC_SUCCESS;
    int ri, blk, bc;
    unsigned char val, *ptr;
    int offset;
    unsigned char shiftVal;
    uint8_t *pHorizBuf = NULL;
    uint8_t *pOperatingBuf = &vertBuffer[0][0];
    uint8_t numRows = MAX_ROWS;
    uint16_t numCols = vertBufferLen; 

    
    // Outer loop for all the rows
    for (ri = 0; ri < numRows; ri++)
    {
        shiftVal = (ri % 8);
        offset = (ri < 8) ? 0 : 1;

        pHorizBuf = &horizBuffer[ri][0];
        for (blk = offset; blk < (numCols * LED_ROW_OFFSET); )
        {
            val = 0;
            for (bc = 0; bc < BITS_PER_BYTE; bc++)
            {
                ptr = &pOperatingBuf[blk];

                if (*ptr & (1 << shiftVal))
                {
                    val |= (1 << ((BITS_PER_BYTE - 1) - bc));
                }

                blk += LED_ROW_OFFSET;
            }

            // Save
            *pHorizBuf++ = val;
        }
    }

#ifndef ENABLE_PICO
    FILE *fp;

    if ((fp = fopen("disp.horz", "wb")) != NULL)
    {
        for (ri = 0; ri < numRows; ri++)
        {
            pHorizBuf = &horizBuffer[ri][0];
            if (fwrite(pHorizBuf, 1, numCols/8, fp) < 0)
            {
                printf("Error %d writing to %s\n", errno, "disp.horiz");
                break;
            }
        }

        fclose (fp);
    }
#endif

    return rc;
}

void signal_display_thread()
{
    // Update flash
    update_flash(pUart->framing_buffer, pUart->framing_buffer_index);

    // Signal display thread
    messageInfo.messageChanged = 1;

    return;
}

const char *String_Board_Size = NULL;
char String_Device_ID[2] = {0};
char String_Intensity[3] = {0}; 
float brightness_in_percentage = 23.232;
int brightness_in_percentage_integer = 0;
void update_message_with_display_info()
{
    
    // {\mode0\fit2{  MASSTRANS PIS TESTING  }}
    char percent = '%';

    // printf("\n in update_message_with_display_info hvrprot.c 1823");
    switch(systemInfo.Board_Type)
    {
        case 1:
        String_Board_Size = "140X16";
        break;
        case 2:
        String_Board_Size = "128X16";
        break;
        case 3:
        String_Board_Size = "96X16";
        break;
    }
    if(systemInfo.deviceId<10)
    {
        String_Device_ID[0] = '0';
        String_Device_ID[1] = (systemInfo.deviceId-1)+48;
    }
    else if(systemInfo.deviceId>=10)
    {
        String_Device_ID[0] = '1';
        String_Device_ID[1] = '0';
    }
    
    //printf("\n PwmBrightvalue = %d, PwmDimValue = %d\n",PwmBrightValue,PwmDimValue);
    if(systemInfo.Board_Type == 1)
    {
        brightness_in_percentage =  ((PwmBrightValue*100)/400);
        //printf("\n Brightness in percentage is for board 1 %f %c\n",brightness_in_percentage,percent);
        brightness_in_percentage_integer = (brightness_in_percentage+10);
    }
    if(systemInfo.Board_Type == 2 || systemInfo.Board_Type == 3)
    {
        brightness_in_percentage = ((PwmBrightValue*100)/400);
        // printf("\n Brightness in percentage is for board 2 or 3 %f%c\n",brightness_in_percentage,percent);
        brightness_in_percentage_integer = (brightness_in_percentage+10);
    }
    if(brightness_in_percentage<100)
    {
        String_Intensity[0] = '0';
        String_Intensity[1] = (brightness_in_percentage/10)+48;
        String_Intensity[2] = (brightness_in_percentage_integer%10)+48;
    }
    if(brightness_in_percentage>=100)

    {
        String_Intensity[0] = '1';
        String_Intensity[1] = '0';
        String_Intensity[2] = '0';
    }
    // printf("\n Brightness in percentage is %f %c\n",brightness_in_percentage,percent);
    snprintf((char *)pUart->framing_buffer, sizeof(pUart->framing_buffer), "{\\mode0\\fit2\\rep1{  MASSTRANS Processor V%s ,Board Size %s,# %c%c ,P %c%c%c}}", FIRMWARE_VERSION,String_Board_Size,String_Device_ID[0],String_Device_ID[1],String_Intensity[0],String_Intensity[1],String_Intensity[2]);
    // printf("\n framed string is \n %s \n and its length is :%d",pUart->framing_buffer,sizeof(pUart->framing_buffer));
    // printf("\n display info framed 123");
    pUart->framing_buffer_index = strlen((char *)pUart->framing_buffer);
    pUart->flashingflag = 0;
}

uint8_t process_uart()
{
    uint8_t ch;
    uint8_t rc = RC_SUCCESS;
#ifdef ENABLE_PICO
    static int uartRunning = 0;
#endif
    printf("\nStart process uart\r\n");

    init_flash_chip();
    chipwakeup();
    
    printf("\nWaiting for flash chip\r\n");
    // Read status 
    while (!chipready())
    {
        // Wait for chip to be ready
        ;
    }
    printf("\nFlash chip ready\r\n");
    pUart->framing_buffer_index = sizeof(pUart->framing_buffer);
    pUart->state = UART_FRAMING_DONE;

    if (get_last_message(pUart->framing_buffer, &pUart->framing_buffer_index) == RC_SUCCESS)
    {
        // Analyze frame
        rc = analyze_hanover_message();
        if (RC_SUCCESS == rc)
        {
            rc = transform_to_vert_buffer();
            //printf("transform_to_vert_buffer returns %d\n", rc);
            if (RC_SUCCESS == rc)
            {
                rc = transform_to_horiz_buffer();
                //printf("transform_to_horiz_buffer returns %d\n", rc);
                if (RC_SUCCESS == rc)
                {
                    signal_display_thread();
                    Powerflag=1;
                    printf("Signalling display thread\n");
                }
                else
                    printf("transform_to_horiz_buffer frame error %d\n", rc);
            }
            else
                printf("transform_to_vert_buffer frame error %d\n", rc);
        }
        else
            printf("analyze_hanover_message frame error %d\n", rc);
    }
    else
        printf("\r\nLast message absent !\r\n");

    clear_hanover_frame();

    update_reset_count(0);
    //mtpl_memset(&messageInfo, 0, sizeof(messageInfo));

    while (1)
    {
#ifdef ENABLE_WATCHDOG
        uart_watchdog_update();
        if (++uartRunning > 1000)
        {
            //printf("UART proc running\r\n");
#ifdef ENABLE_PICO
            uartRunning = 0;
#endif
        }
#endif
        // printf("\n rc = %d",rc);
        // switch(rc)
        //     {
        //         case RC_SUCCESS:
        //         printf("\n RC_SUCCESS");
        //         break;
        //         case RC_UPDATE_TEST_MESSAGE:
        //         printf("\n RC_UPDATE_TEST_MESSAGE");
        //         break;
        //         default :
        //         printf("\n default");
        //         break;
        //     }
        if ((rc = recv_byte(&ch)) == RC_SUCCESS)
        {
            //printf("\n inside if condition rc = %d",rc);
            
#ifdef ENABLE_PICO
            if(systemInfo.testMode)
            {
                sleep_ms(100);
                continue;
            }
#endif
            // Populate Hanover protocol frame
            rc = build_hanover_frame(ch);
            switch (rc)
            {
                case RC_SUCCESS:
                    break;

                case RC_FRAMING_DONE:
                    rc = validate_hanover_frame();
//#ifdef ENABLE_PID_DTC
                    // printf("\n received command is 0x%02X",pUart->cmd);
                    if (((pUart->cmd == PID_DTC_GRP_CMD)||(pUart->cmd == PID_DTC_SET_REQUEST))&&(pUart->destId == systemInfo.deviceId))
                    {
                        //should be removed compleatly later included only for testing switch case
                        switch(pUart->cmd)
                        {
                            case PID_DTC_GRP_CMD:
                            printf("\n received Get command");
                            printf("\n rc = %d",rc);
                            sleep_ms(10);
                            break;
                            case PID_DTC_SET_REQUEST:
                            printf("\n received set cmd");
                            printf("\n rc = %d",rc);
                            sleep_ms(10);
                            break;
                            default:
                            printf("\n core");
                            sleep_ms(10);
                            break;
                        }
                        if(pUart->cmd == PID_DTC_GRP_CMD)
                        {
                            if(rc == RC_SUCCESS || rc == RC_RUNT_FRAME) // condition if the input command length is less than 10 as in PID_DTC Get and Set Commands
                            {
                                printf("\nReceived GET Request Caommand\n");
                                printf("Received PID-DTC command 0x%02x\r\n", pUart->framing_buffer[0]);
                                // Process and reply 
                                if( process_pid_dtc_command(pUart->framing_buffer[0]) == RC_SUCCESS)
                                    transmit_pid_dtc_response();
                                clear_hanover_frame();
                                break;
                            }
                        }
                        else if(pUart->cmd == PID_DTC_SET_REQUEST)
                        {
                            printf("\nReceived Set Request Command \n");
                            printf("Received PID-DTC command 0x%02x\r\n", pUart->framing_buffer[0]);
                            if(rc == RC_SUCCESS)
                            {
                                if(process_pid_dtc_set_command(pUart->framing_buffer[0]) == RC_SUCCESS)
                                {
                                    transmit_pid_dtc_response();
                                    clear_hanover_frame();
                                    break;
                                }
                                /*while(pUart->framing_buffer[i])
                                {
                                    printf("%c",pUart->framing_buffer[i]);
                                    i++;
                                    sleep_ms(1);
                                }
                                clear_hanover_frame();
                                break;*/
                            }
                            else
                            {
                                
                                if(process_pid_dtc_error_command(pUart->framing_buffer[0]) == RC_PID_DTC_SET_REQUEST_ERROR)
                                {
                                    printf("\n PID_DTC Checksum Error Response");
                                    int temp_i = 0;
                                    printf("\n");
                                    //while should be removed after debugging included only for debugging purpose
                                    while(pUart->framing_buffer[temp_i])
                                    {
                                        printf("%c",pUart->framing_buffer[temp_i]);
                                        temp_i++;
                                    }
                                    printf("\n command is = %d",pUart->cmd);
                                    printf("\n devicd id = %d",pUart->destId);
                                    printf("\n pid_grp = %c",(char)pUart->framing_buffer[0]);
                                    Transmit_pid_dtc_Error_Response();
                                    clear_hanover_frame();
                                    break;
                                }
                            }
                        }
                    }
//#endif
                    if (RC_SUCCESS == rc)
                    {
                        // Clear message information structureN 
                        if(!messageInfo.messageChanged)
                        {
                            //mtpl_memset(&messageInfo, 0, sizeof(messageInfo));
                            if (pUart->showDisplayInfo)
                            {
                                hvrprot_Test_Mode_Message_Flag = 1;
                                update_message_with_display_info();
                            }
                            // Analyze frame
                            rc = analyze_hanover_message();
                            //printf("Analyze hanover frame returns %d\n", rc);
                            if (RC_SUCCESS == rc)
                            {
                                rc = transform_to_vert_buffer();
                                //printf("transform_to_vert_buffer returns %d\n", rc);
                                if (RC_SUCCESS == rc)
                                {
                                    rc = transform_to_horiz_buffer();
                                    //printf("transform_to_horiz_buffer returns %d\n", rc);
                                    if (RC_SUCCESS == rc)
                                        signal_display_thread();

                                }
                            }
                        }
                        else
                        {
                            printf("\nMessage Dropped\n");
                        }
                    
                    }
                    else 
                    {
                        //printf("\n validate frame error = %d",rc);
                        // printf("\n XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                        // printf("\n destination id from board is %d from uart is %d",(int)systemInfo.deviceId, (int)pUart->destId);
                        // printf("\n Testmode = %d",(int)systemInfo.testMode);
                        // printf("\n BoardType = %d",(int)systemInfo.Board_Type);
                        // printf("\n XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                        
                    }
                    clear_hanover_frame();
                    break;

                case RC_FRAME_TOO_LARGE:
                    // Log error
                    clear_hanover_frame();
                    break;

                case RC_FRAMING_ERROR:
                    // Log error
                    clear_hanover_frame();
                    break;

                case RC_UPDATE_TEST_MESSAGE:
                        // Clear message information structureN 
                        if(!messageInfo.messageChanged)
                        {
                            //mtpl_memset(&messageInfo, 0, sizeof(messageInfo));
                            pUart->showDisplayInfo = 1;
                            if (pUart->showDisplayInfo)
                            {
                                update_message_with_display_info();
                            }

                            // Analyze frame
                            rc = analyze_hanover_message();
                            //printf("Analyze hanover frame returns %d in second iteration\n", rc);
                            if (RC_SUCCESS == rc)
                            {
                                rc = transform_to_vert_buffer();
                                //printf("transform_to_vert_buffer returns %d in second iteration\n", rc);
                                if (RC_SUCCESS == rc)
                                {
                                    rc = transform_to_horiz_buffer();
                                    //printf("transform_to_horiz_buffer returns %d in second iteration\n", rc);
                                    if (RC_SUCCESS == rc)
                                    {
                                        signal_display_thread();
                                    }
                                        //printf("\n end of signalling_display_thread in UPDATE TEST MSG");
                                        clear_hanover_frame();
                                        hvrprot_Test_Mode_Scroll_Completed_Flag = 0;
                                        hvrprot_Test_Mode_Message_Triggered_Flag = 1;

                                }
                            }
                        }
                        // else
                        // {
                        //     printf("\nMessage Dropped in else part of RC_UPDATE_TEST_MESSAGE\n");
                        // }
                    
                    //clear_hanover_frame();
                    
                    break;

                default:
                    // Log error
                    clear_hanover_frame();
                    break;
            }        
        }
    }

    return rc;
}

uint8_t getCharWidth(uint32_t char_Value)
{
    uint8_t charsize;
    if(char_Value == ' '||char_Value == 'i'||char_Value == 'l'||char_Value == '|'||char_Value == '!'||char_Value == 'I')
    {
        charsize = 3;
        // for mode 2 and 3 
        if(char_Value == 'I'&&messageInfo.mode > 1)
        {
            charsize = 3;
        }
        // for mode 0 and 1
        else if(char_Value == 'I' && messageInfo.mode <= 1)
        {
            charsize = 7;
        }
    }
    else
    {
        charsize = 7;
    }
    return charsize;
}
int getTextWidth(uint8_t *data_array)
{
    int data_count = 0,Total_Text_Length=0;
    uint8_t charsize_getTextWidth = 0;
    //printf("\ngettingTextWidth\n");
    while(data_array[data_count])
    {
         //printf("%c",data_array[data_count]);
         if(data_array[data_count] == ' '||data_array[data_count] == 'i'||data_array[data_count] == 'l'||data_array[data_count] == '|'||data_array[data_count] == '!'||data_array[data_count] == 'I')
    {
        charsize_getTextWidth = 4;
        //printf(" +4 =");
        // for mode 2 and 3
        if(data_array[data_count] == 'I' && messageInfo.mode > 1)
        {
            charsize_getTextWidth = 4;
        }
        // for mode 0 and 1
        else if(data_array[data_count] == 'I' && messageInfo.mode <= 1)
        {
            charsize_getTextWidth = 8;
        }
    }
    else
    {
        charsize_getTextWidth = 8;
        //printf(" +8 =");
    }
    Total_Text_Length = Total_Text_Length +charsize_getTextWidth;
    data_count++;
    //printf(" Tolat_Length_of_The_Text is %d\n",Total_Text_Length);
    //printf(" %d\n",Total_Text_Length);
    }
    return Total_Text_Length;
}
int getBoardSize(void)
{
    int Board_Size = 0;
    if(systemInfo.Board_Type==1)
    {
        Board_Size = 140;
    }
    else if(systemInfo.Board_Type==2)
    {
        Board_Size = 128;
    }
    if(systemInfo.Board_Type==3)
    {
        Board_Size = 96;
    }
    //printf("\nBoard_Size is %d",Board_Size);
    return Board_Size;
}
int Check_Data_Size_and_Reframe_If_Needed(int Total_Data_Length,uint8_t modeIndex)
{
    if(Total_Data_Length%8)
                    {
                        //printf("\n Invalied length");
                        messageInfo.modeData[modeIndex].data[messageInfo.modeData[modeIndex].payloadLen] = ' ';
                        messageInfo.modeData[modeIndex].payloadLen ++;
                        // printf("\n appending space  now the new length is %d",messageInfo.modeData[modeIndex].payloadLen);
                        Total_Data_Length = Total_Data_Length + 4;
                    }
                    
                    return Total_Data_Length;
}