#include<stdio.h>
#include<stdlib.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "hardware/pwm.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#else
#include <ncurses.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#endif
#include "main.h"
#include "hvrprot.h"
#include "utils.h"
#include "init.h"

#include "deviceid.h"
#include "init.h"
#include "displaycharlib.h"
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Alphabets 8X7 Size Two Lines //////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////Alphabets 8X7 Size New 19 - 11 - 2022////////////////////////////////////////////////////////////////////////////////////////////
char A[8]={0x10,0x38,0x6c,0xc6,0xfe,0xc6,0xc6,0x00};
char B[8]={0xf8,0xfc,0xc4,0xf8,0xc4,0xfc,0xf8,0x00};
char C[8]={0x78,0xfc,0xc0,0xc0,0xc0,0xfc,0x78,0x00};
char D[8]={0xf8,0xfc,0xcc,0xcc,0xcc,0xfc,0xf8,0x00};
char E[8]={0xfc,0xfc,0xc0,0xf8,0xc0,0xfc,0xfc,0x00};
char F[8]={0xfc,0xfc,0xc0,0xf8,0xf8,0xc0,0xc0,0x00};
char G[8]={0x7c,0xfe,0xc0,0xce,0xc6,0xfe,0x7c,0x00};
char H[8]={0xc6,0xc6,0xc6,0xfe,0xfe,0xc6,0xc6,0x00};
//char I[8]={0x78,0x78,0x30,0x30,0x30,0x78,0x78,0x00};
char I[8]={0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00};
char J[8]={0x7e,0x7e,0x18,0x18,0x18,0xf8,0x70,0x00};
char K[8]={0xc6,0xcc,0xd8,0xf0,0xd8,0xcc,0xc6,0x00};
char L[8]={0xc0,0xc0,0xc0,0xc0,0xc0,0xfc,0xfc,0x00};
char M[8]={0xc6,0xee,0xfe,0xd6,0xc6,0xc6,0xc6,0x00};
char N[8]={0xc6,0xe6,0xf6,0xde,0xce,0xc6,0xc6,0x00};
char O[8]={0x7c,0xfe,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char P[8]={0xf8,0xfc,0xc4,0xfc,0xf8,0xc0,0xc0,0x00};
char Q[8]={0x38,0x7c,0xc6,0xc6,0xd6,0x7c,0x3a,0x00};
char R[8]={0xfc,0xfe,0xc6,0xfc,0xf8,0xcc,0xc6,0x00};
char S[8]={0x7e,0xfe,0xc0,0x7c,0x06,0xfe,0xfc,0x00};
char T[8]={0xfc,0xfc,0x30,0x30,0x30,0x30,0x30,0x00};
char U[8]={0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char V[8]={0xc6,0xc6,0xc6,0xc6,0x6c,0x38,0x10,0x00};
char W[8]={0xc6,0xc6,0xc6,0xc6,0xd6,0xee,0xc6,0x00};
char X[8]={0x84,0xcc,0x78,0x30,0x78,0xcc,0x84,0x00};
char Y[8]={0xcc,0xcc,0xcc,0x78,0x30,0x30,0x30,0x00};
char Z[8]={0xfc,0xfc,0x18,0x30,0x60,0xfc,0xfc,0x00};

char one[8]={0x30,0x70,0x30,0x30,0x30,0x30,0xfc,0x00};
char two[8]={0x7c,0x86,0x06,0x0c,0x18,0x70,0xfe,0x00};
char three[8]={0x7c,0x86,0x06,0x7c,0x06,0x86,0x7c,0x00};
char four[8]={0x18,0x38,0x58,0x98,0xfe,0x18,0x18,0x00};
char five[8]={0xfe,0xc0,0xc0,0xfc,0x06,0x06,0xfc,0x00};
char six[8]={0x7c,0xc0,0xc0,0xfc,0xc6,0xc6,0x7c,0x00};
char seven[8]={0xfe,0x06,0x0c,0x18,0x30,0x30,0x30,0x00};
char eight[8]={0x7c,0xc6,0xc6,0x7c,0xc6,0xc6,0x7c,0x00};
char nine[8]={0x7c,0xc6,0xc6,0x7e,0x06,0x06,0x7c,0x00};
char zero[8]={0x7c,0xc6,0xc6,0xc6,0xc6,0xc6,0x7c,0x00};
char space[8]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

/*char one[8]={0x10,0x30,0x50,0x10,0x10,0x10,0x7c,0x00};
char two[8]={0x3e,0x41,0x01,0x3e,0x40,0x40,0x7f,0x00};
char three[8]={0x3e,0x41,0x01,0x3e,0x01,0x41,0x3e,0x00};
char four[8]={0x40,0x42,0x42,0x42,0x7f,0x02,0x02,0x00};
char five[8]={0x7f,0x40,0x40,0x7e,0x01,0x41,0x3e,0x00};
char six[8]={0x3e,0x41,0x40,0x7e,0x41,0x41,0x3e,0x00};
char seven[8]={0x7f,0x42,0x04,0x08,0x10,0x10,0x10,0x00};
char eight[8]={0x3e,0x41,0x41,0x3e,0x41,0x41,0x3e,0x00};
char nine[8]={0x3e,0x41,0x41,0x3f,0x01,0x41,0x3e,0x00};
char zero[8]={0x1c,0x22,0x41,0x41,0x41,0x22,0x1c,0x00};
char space[8]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// Alphabets Small a to z 8x8 //////////////////////////////////////////////////////////////////////////////////
char a[8]= {0x00,0x3C,0x7E,0x06,0x7E,0xC6,0x7C,0x00};
char b[8]= {0xc0,0xc0,0xc0,0xfc,0xc6,0xc6,0x7c,0x00};
char c[8]= {0x00,0x00,0x7c,0xc6,0xc0,0xc6,0x78,0x00};
char d[8]= {0x06,0x06,0x06,0x7e,0xc6,0xc6,0x7e,0x00};
char e[8]= {0x00,0x00,0x7c,0xc6,0xfe,0xc0,0x7e,0x00};
char f[8]= {0x0e,0x18,0x7e,0x18,0x18,0x18,0x18,0x00};
char g[8]= {0x00,0x7c,0xc6,0xc6,0x7e,0x06,0x7c,0x00};
char h[8]= {0xc0,0xc0,0xc0,0xfc,0xc6,0xc6,0xc6,0x00};
char i[8]= {0x06,0x00,0x06,0x06,0x06,0x06,0x06,0x00};
char j[8]= {0x0c,0x00,0x0c,0x0c,0x0c,0x6c,0x38,0x00};
char k[8]= {0x60,0x60,0x66,0x6c,0x78,0x6c,0x66,0x00};
char l[8]= {0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00};
char m[8]= {0x00,0x00,0x6c,0xfe,0xd6,0xc6,0xc6,0x00};
char n[8]= {0x00,0x00,0x7c,0x66,0x66,0x66,0x66,0x00};
char o[8]= {0x00,0x00,0x7c,0xc6,0xc6,0xc6,0x7c,0x00};
char p[8]= {0x00,0xfc,0xc6,0xc6,0xfc,0xc0,0xc0,0x00};
char q[8]= {0x00,0x7c,0xc6,0xc6,0x7e,0x06,0x06,0x00};
char r[8]= {0x00,0xb8,0x64,0x60,0x60,0x60,0x60,0x00};
char s[8]= {0x00,0x7C,0xC2,0xC0,0x7C,0x86,0x7C,0x00};
char t[8]= {0x18,0x18,0x7e,0x18,0x18,0x18,0x0c,0x00};
char u[8]= {0x00,0x00,0xc6,0xc6,0xc6,0xc6,0x7e,0x00};
char v[8]= {0x00,0x00,0xc6,0xc6,0x6c,0x38,0x10,0x00};
char w[8]= {0x00,0x00,0xc6,0xc6,0xd6,0xfe,0x6c,0x00};
char x[8]= {0x00,0x00,0xc6,0x6c,0x38,0x6c,0xc6,0x00};
char y[8]= {0x00,0x00,0xc6,0xc6,0x7e,0x06,0x7c,0x00};
char z[8]= {0x00,0x00,0x7e,0x0c,0x18,0x30,0x7e,0x00};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// typedef struct {
//         char *font[26];     
// } FONT_TABLE;


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// Alphabets of 8X16 size Capitals Uppercase////////////////////////////////////
char A_8X16[16] = {0x10,0x38,0x6c,0xc6,0xc6,0xc6,0xc6,0xfe,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char B_8X16[16] = {0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xfc,0xfc,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0xfc,0x00};
char C_8X16[16] = {0x7c,0xfe,0xc6,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc6,0xfe,0x7c,0x00};
char D_8X16[16] = {0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0xfc,0x00};
char E_8X16[16] = {0xfe,0xfe,0xc0,0xc0,0xc0,0xc0,0xf8,0xf8,0xc0,0xc0,0xc0,0xc0,0xc0,0xfe,0xfe,0x00};
char F_8X16[16] = {0xfe,0xfe,0xc0,0xc0,0xc0,0xc0,0xf8,0xf8,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0x00};
char G_8X16[16] = {0x7c,0xfe,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xce,0xce,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char H_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char I_8X16[16] = {0x7E,0x7E,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x7E,0x7E,0x00};
char J_8X16[16] = {0x1E,0x1E,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0xCC,0xFC,0x78,0x00};
char K_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xcc,0xd8,0xf0,0xf0,0xd8,0xcc,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char L_8X16[16] = {0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xfe,0xfe,0x00};
char M_8X16[16] = {0x82,0xc6,0xee,0xfe,0xd6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char N_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xe6,0xf6,0xfe,0xde,0xce,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char O_8X16[16] = {0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char P_8X16[16] = {0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xfE,0xfc,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0x00};
char Q_8X16[16] = {0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xce,0xfc,0x7a,0x00};
char R_8X16[16] = {0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xfc,0xfc,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char S_8X16[16] = {0x7c,0xfe,0xc6,0xc0,0xc0,0xc0,0xfc,0x7e,0x06,0x06,0x06,0x06,0xc6,0xfe,0x7c,0x00};
char T_8X16[16] = {0xfc,0xfc,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x00};
char U_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char V_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x6c,0x38,0x10,0x00};
char W_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xd6,0xd6,0xfe,0xee,0xc6,0x82,0x00};
char X_8X16[16] = {0xc6,0xc6,0xc6,0xc6,0xc6,0x6c,0x38,0x38,0x6c,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char Y_8X16[16] = {0xcc,0xcc,0xcc,0xcc,0xcc,0xcc,0x78,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x00};
char Z_8X16[16] = {0xfe,0xfe,0x06,0x06,0x06,0x0c,0x18,0x30,0x60,0xc0,0xc0,0xc0,0xc0,0xfe,0xfe,0x00};
////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// Alphabets of 8X16 size Smalls Lowerercase////////////////////////////////////
char a_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0x06,0x06,0x7e,0xfe,0xc6,0xc6,0xfe,0x7c,0x00};
char b_8X16[16] = {0x00,0xc0,0xc0,0xc0,0xc0,0xc0,0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0xfc,0x00};
char c_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xc0,0xc0,0xc6,0xc6,0xfe,0x7c,0x00};
char d_8X16[16] = {0x00,0x06,0x06,0x06,0x06,0x06,0x7e,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7e,0x00};
char e_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xfe,0xfe,0xc0,0xc0,0xfe,0x7c,0x00};
char f_8X16[16] = {0x00,0x1e,0x3e,0x30,0x30,0x30,0xfe,0xfe,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x00};
char g_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xfe,0x7e,0x06,0x06,0xfe,0x7c,0x00};
char h_8X16[16] = {0x00,0xc0,0xc0,0xc0,0xc0,0xc0,0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char i_8X16[16] = {0x00,0x00,0x00,0x06,0x06,0x00,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00};
char j_8X16[16] = {0x00,0x00,0x00,0x06,0x06,0x00,0x06,0x06,0x06,0x06,0x06,0xc6,0xc6,0xfe,0x7c,0x00};
char k_8X16[16] = {0x00,0xc0,0xc0,0xc0,0xc0,0xc6,0xc6,0xcc,0xcc,0xf8,0xf8,0xcc,0xcc,0xc6,0xc6,0x00};
char l_8X16[16] = {0x00,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00};
char m_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x6c,0xee,0xfe,0xd6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char n_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char o_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char p_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xfc,0xfe,0xc6,0xc6,0xc6,0xfe,0xfc,0xc0,0xc0,0xc0,0x00};
char q_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7e,0xfe,0xc6,0xc6,0xc6,0xfe,0x7e,0x06,0x06,0x06,0x00};
char r_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xde,0xfe,0xe0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0x00};
char s_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc0,0xfc,0x7e,0x06,0xc6,0xfe,0x7c,0x00};
char t_8X16[16] = {0x00,0x30,0x30,0x30,0x30,0xfe,0xfe,0x30,0x30,0x30,0x30,0x30,0x30,0x3e,0x1e,0x00};
char u_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char v_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x6c,0x38,0x10,0x00};
char w_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xd6,0xfe,0xee,0x6c,0x00};
char x_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0x6c,0x6c,0x38,0x38,0x6c,0x6c,0xc6,0xc6,0x00};
char y_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xfe,0x7e,0x06,0x86,0xfe,0x7c,0x00};
char z_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xfe,0xfe,0x06,0x0c,0x18,0x30,0x60,0xc0,0xfe,0xfe,0x00};

// Alphabets of 8X8 size Smalls Lower case////////////////////////////////////
/*
char a_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0x06,0x06,0x7e,0xfe,0xc6,0xc6,0xfe,0x7c,0x00};
char b_lc[16] = {0x00,0xc0,0xc0,0xc0,0xc0,0xc0,0xfc,0xfc,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0xbc,0x00};
char c_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xc0,0xc0,0xc6,0xc6,0xfe,0x7c,0x00};
char d_lc[16] = {0x00,0x06,0x06,0x06,0x06,0x06,0x7e,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7a,0x00};
char e_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xfe,0xfe,0xc0,0xc0,0xfe,0x7c,0x00};
char f_lc[16] = {0x00,0x1e,0x3e,0x30,0x30,0x30,0xfe,0xfe,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x00};
char g_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xfe,0x7e,0x06,0x06,0xfe,0x7c,0x00};
char h_lc[16] = {0x00,0xc0,0xc0,0xc0,0xc0,0xc0,0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char i_lc[16] = {0x00,0x00,0x00,0x18,0x18,0x00,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x00};
char j_lc[16] = {0x00,0x00,0x00,0x06,0x06,0x00,0x06,0x06,0x06,0x06,0x06,0xc6,0xc6,0xfe,0x7c,0x00};
char k_lc[16] = {0x00,0xc0,0xc0,0xc0,0xc0,0xc6,0xc6,0xcc,0xcc,0xf8,0xf8,0xcc,0xcc,0xc6,0xc6,0x00};
char l_lc[16] = {0x00,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x00};
char m_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x6c,0xee,0xfe,0xd6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char n_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xbc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x00};
char o_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char p_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xbc,0xfe,0xc6,0xc6,0xc6,0xfe,0xfc,0xc0,0xc0,0xc0,0x00};
char q_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7a,0xfe,0xc6,0xc6,0xc6,0xfe,0x7e,0x06,0x06,0x06,0x00};
char r_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xde,0xfe,0xf0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0x00};
char s_lc[16] = {0x00,0x00,0x00,0x00,0x00,0x7c,0xfe,0xc6,0xc0,0xfc,0x7e,0x06,0xc6,0xfe,0x7c,0x00};
char t_lc[16] = {0x00,0x18,0x18,0x18,0x18,0x7e,0x7e,0x18,0x18,0x18,0x18,0x18,0x18,0x1e,0x0c,0x00};
char u_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7a,0x00};
char v_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0x6c,0x38,0x10,0x00};
char w_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xd6,0xfe,0xee,0x6c,0x00};
char x_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0x6c,0x6c,0x38,0x38,0x6c,0x6c,0xc6,0xc6,0x00};
char y_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xc6,0xc6,0xc6,0xc6,0xfe,0x7e,0x06,0x86,0xfe,0x7c,0x00};
char z_lc[16] = {0x00,0x00,0x00,0x00,0x00,0xfe,0xfe,0x06,0x0c,0x18,0x30,0x60,0xc0,0xfe,0xfe,0x00};
*/
////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////// Numbers 0 to 9 and space 16 rows high ////////////////////////////////////////////
char one_8X16[16] = {0x30,0x70,0xf0,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0xfc,0xfc,0x00};
char two_8X16[16] = {0x7c,0xfe,0xc6,0x06,0x06,0x0c,0x18,0x30,0x60,0xc0,0xc0,0xc0,0xc0,0xfe,0xfe,0x00};
char three_8X16[16] = {0x7c,0xfe,0xc6,0x06,0x06,0x06,0x1c,0x1c,0x06,0x06,0x06,0x06,0xc6,0xfe,0x7c,0x00};
char four_8X16[16] = {0x04,0x0c,0x1c,0x3c,0x6c,0xcc,0xcc,0xcc,0xfe,0xfe,0x0c,0x0c,0x0c,0x0c,0x0c,0x00};
char five_8X16[16] = {0xfe,0xfe,0xc0,0xc0,0xc0,0xc0,0xfc,0xfe,0x06,0x06,0x06,0x06,0xc6,0xfe,0x7c,0x00};
char six_8X16[16] = {0x7c,0xfe,0xc0,0xc0,0xc0,0xc0,0xfc,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char seven_8X16[16] = {0xfe,0xfe,0x06,0x06,0x06,0x0c,0x18,0x30,0x60,0x60,0x60,0x60,0x60,0x60,0x60,0x00};
char eight_8X16[16] = {0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0x7c,0x7c,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char nine_8X16[16] = {0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0xfe,0x7e,0x06,0x06,0x06,0x06,0x06,0xfe,0x7c,0x00};
char zero_8X16[16] = {0x7c,0xfe,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xc6,0xfe,0x7c,0x00};
char space_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};


///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////// Special Char 16X8 /////////////////////////////////////////////////////////////////////////////

char exclamation_mark_8X16[16] = {0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00,0x00,0x06,0x06,0x06,0x00}; //!
char double_quotation_mark_8X16[16] = {0x6C,0x6C,0x6C,0x6C,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//"
char pound_8X16[16] = {0x00,0x00,0x6C,0x6C,0xFE,0xFE,0x6C,0x6C,0x6C,0xFE,0xFE,0x6C,0x6C,0x00,0x00,0x00};//#
char dollor_8X16[16] ={0x28,0x7C,0xFE,0xAA,0xA8,0xA8,0xFC,0x7E,0x2E,0x2A,0x2A,0xAA,0xFE,0x7C,0x28,0x00};//$
char percent_sign_8X16[16] ={0x00,0x00,0x00,0x00,0x42,0xA6,0xAC,0x58,0x34,0x6A,0xCA,0x84,0x00,0x00,0x00,0x00};//%
char ampersand_8X16[16] = {0x00,0x70,0x88,0x88,0x88,0x88,0x50,0x20,0x50,0x8A,0x86,0x84,0x8E,0x72,0x02,0x00};//&
char single_quotation_mark_8X16[16]={0x38,0x38,0x38,0x18,0x30,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//'
char left_parenthesis_8X16[16] = {0x0C,0x18,0x30,0x60,0x60,0x60,0x60,0x60,0x60,0x60,0x60,0x60,0x30,0x18,0x0C,0x00};// (
char right_parenthesis_8X16[16] = {0x60,0x30,0x18,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x18,0x30,0x60,0x00};// )
char asterisk_8X16[16] = {0x00,0x00,0x00,0x10,0x92,0x54,0x38,0xFE,0x38,0x54,0x92,0x10,0x00,0x00,0x00,0x00}; //*
char plus_8X16[16] = {0x00,0x00,0x00,0x00,0x18,0x18,0x18,0x7E,0x7E,0x18,0x18,0x18,0x00,0x00,0x00,0x00};//+
char comma_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x38,0x38,0x38,0x18,0x30,0x00};//,
char minus_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x00,0xFE,0xFE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//-
char full_stop_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x18,0x3C,0x3C,0x18,0x00};//.
char slash_8X16[16] = {0x00,0x00,0x00,0x00,0x02,0x06,0x0C,0x18,0x30,0x60,0xC0,0x80,0x00,0x00,0x00,0x00};//'/'
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char colon_8X16[16] = {0x00,0x00,0x00,0x00,0x18,0x3C,0x3C,0x18,0x00,0x00,0x18,0x3C,0x3C,0x18,0x00,0x00};//:
char semicolon_8X16[16] = {0x00,0x00,0x00,0x00,0x10,0x38,0x38,0x10,0x00,0x00,0x38,0x38,0x38,0x18,0x30,0x00};//;
char less_than_8X16[16] = {0x00,0x00,0x06,0x0C,0x18,0x30,0x60,0xC0,0xC0,0x60,0x30,0x18,0x0C,0x06,0x00,0x00};//<
char equal_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0xFE,0xFE,0x00,0x00,0xFE,0xFE,0x00,0x00,0x00,0x00,0x00};//=
char greater_than_8X16[16] = {0x00,0x00,0xC0,0x60,0x30,0x18,0x0C,0x06,0x06,0x0C,0x18,0x30,0x60,0xC0,0x00,0x00};//>
char question_mark_8X16[16] = {0x7C,0xFE,0xEE,0xC6,0xC6,0x0C,0x18,0x30,0x30,0x30,0x30,0x00,0x00,0x30,0x30,0x00};//?
char commercial_at_8X16[16] = {0x7C,0xFE,0xC6,0xD6,0xD6,0xD6,0xD6,0xD6,0xD6,0xD6,0xDC,0xC0,0xC2,0xFE,0x7C,0x00};//@
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char left_square_bracket_8X16[16] = {0xFE,0xFE,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xC0,0xFE,0xFE,0x00};//[
char backslash_8X16[16] = {0x00,0x00,0x00,0x00,0x80,0xC0,0x60,0x30,0x18,0x0C,0x06,0x02,0x00,0x00,0x00,0x00};/* \*/
char right_square_bracket_8X16[16] = {0xFE,0xFE,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0xFE,0xFE,0x00};//]
char spacing_circumflex_accent_8X16[16] ={0x10,0x38,0x6c,0xC6,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//^
char spacing_underscore_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFE,0xFE,0x00};//_
char back_apostrophe_8X16[16] = {0x38,0x38,0x38,0x30,0x18,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,};//`
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char left_curly_bracket_8X16[16] = {0x3E,0x7C,0x60,0x60,0x60,0x60,0xC0,0xC0,0x60,0x60,0x60,0x60,0x60,0x7C,0x3E,0x00};//{
char vertical_bar_8X16[16] = {0x00,0x00,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00,0x00};//|
char right_curly_bracket_8X16[16] = {0xF8,0x7C,0x0C,0x0C,0x0C,0x0C,0x06,0x06,0x0C,0x0C,0x0C,0x0C,0x0C,0x7C,0xF8,0x00};//}
char tilde_accent_8X16[16] = {0x00,0x00,0x00,0x00,0x00,0x60,0x92,0x0C,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};//~





////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////// Special Char 8X8 /////////////////////////////////////////////////////////////////////////////

char exclamation_mark_8X8[8] = {0x06,0x06,0x06,0x06,0x00,0x06,0x06,0x00}; //!
char double_quotation_mark_8X8[8] = {0xEE,0xEE,0x44,0x00,0x00,0x00,0x00,0x00};//"
char pound_8X8[8] = {0x28,0x28,0xFE,0x28,0xFE,0x28,0x28,0x00};//#
char dollor_8X8[8] ={0x28,0x7E,0xA8,0x7C,0x2A,0xFC,0x28,0x00};//$
char percent_sign_8X8[8] ={0x42,0xA4,0x48,0x10,0x24,0x4A,0x84,0x00};//%
char ampersand_8X8[8] = {0x30,0x48,0x30,0x70,0x8A,0x84,0x7A,0x00};//&
char single_quotation_mark_8X8[8]={0x38,0x38,0x10,0x20,0x00,0x00,0x00,0x00};//'
char left_parenthesis_8X8[8] = {0x18,0x20,0x40,0x40,0x40,0x20,0x18,0x00};// (
char right_parenthesis_8X8[8] = {0x60,0x10,0x08,0x08,0x08,0x10,0x60,0x00};// )
char asterisk_8X8[8] = {0x10,0x54,0x38,0xFE,0x38,0x54,0x10,0x00}; //*
char plus_8X8[8] = {0x00,0x18,0x18,0x7E,0x7E,0x18,0x18,0x00};//+
char comma_8X8[8] = {0x00,0x00,0x00,0x38,0x38,0x10,0x20,0x00};//,
char minus_8X8[8] = {0x00,0x00,0x00,0x7C,0x7C,0x00,0x00,0x00};//-
char full_stop_8X8[8] = {0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00};//.
char slash_8X8[8] = {0x04,0x0C,0x18,0x30,0x60,0xC0,0x80,0x00};//'/'
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char colon_8X8[8] = {0x00,0x30,0x30,0x00,0x30,0x30,0x00,0x00};//:
char semicolon_8X8[8] = {0x00,0x30,0x30,0x00,0x30,0x10,0x20,0x00};//;
char less_than_8X8[8] = {0x08,0x10,0x20,0x40,0x20,0x10,0x08,0x00};//<
char equal_8X8[8] = {0x00,0x00,0x7C,0x00,0x7C,0x00,0x00,0x00};//=
char greater_than_8X8[8] = {0x40,0x20,0x10,0x08,0x10,0x20,0x40,0x00};//>
char question_mark_8X8[8] = {0x38,0x44,0x04,0x18,0x20,0x00,0x20,0x00};//?
char commercial_at_8X8[8] = {0x7C,0x82,0xBA,0xBA,0xBC,0x80,0x7C,0x00};//@
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char left_square_bracket_8X8[8] = {0x7C,0x40,0x40,0x40,0x40,0x40,0x7C,0x00};//[
char backslash_8X8[8] = {0x40,0x60,0x30,0x18,0x0C,0x06,0x02,0x00};/* \*/
char right_square_bracket_8X8[8] = {0x7C,0x04,0x04,0x04,0x04,0x04,0x7C,0x00};//]
char spacing_circumflex_accent_8X8[8] ={0x10,0x28,0x44,0x00,0x00,0x00,0x00,0x00};//^
char spacing_underscore_8X8[8] = {0x00,0x00,0x00,0x00,0x00,0xFE,0xFE,0x00};//_
char back_apostrophe_8X8[8] = {0x38,0x38,0x10,0x08,0x00,0x00,0x00,0x00};//`
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char left_curly_bracket_8X8[8] = {0x0E,0x10,0x10,0x20,0x10,0x10,0x0E,0x00};//{
char vertical_bar_8X8[8] = {0x06,0x06,0x06,0x06,0x06,0x06,0x06,0x00};//|
char right_curly_bracket_8X8[8] = {0x70,0x08,0x08,0x04,0x08,0x08,0x70,0x00};//}
char tilde_accent_8X8[8] = {0x00,0x60,0x92,0x0C,0x00,0x00,0x00,0x00};//~





////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////// Alphabets A to Z 8X16_vertical Raster formating /////////////////////////////////////////



////////////// Alphabets A to Z 8X16_vertical Raster formating /////////////////////////////////////////
/*char A_8X16_VR[22] = {0xE0,0xFF,0xF0,0xFF,0xF8,0xFF,0x3C,0x07,0x1E,0x07,0x0F,0x07,0x1E,0x07,0x3C,0x07,0xF8,0xFF,0xF0,0xFF,0xE0,0xFF};
char B_8X16_VR[20] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xC7,0xE1,0xC7,0xE1,0xC7,0xE1,0xC7,0xE1,0xFF,0xFF,0xFE,0x7F,0x7C,0x3E};
char C_8X16_VR[22] = {0xFC,0x3F,0xFE,0x7F,0xFF,0xFF,0x0F,0xF0,0x07,0xE0,0x07,0xE0,0x07,0xE0,0x07,0xE0,0x0F,0xF0,0x1E,0x78,0x3C,0x3C};
char D_8X16_VR[22] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x07,0xE0,0x07,0xE0,0x07,0xE0,0x07,0xE0,0x0F,0xF0,0xFF,0xFF,0xFE,0x7F,0xFC,0x3F};
char E_8X16_VR[18] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xC7,0xE1,0xC7,0xE1,0xC7,0xE1,0xC7,0xE1,0xC7,0xE1,0x07,0xE0};*/


FONT_TABLE CapitalFontTable8x8[] = {
        {A},
        {B},
        {C},
        {D},
        {E},
        {F},
        {G},
        {H},
        {I},
        {J},
        {K},
        {L},
        {M},
        {N},
        {O},
        {P},
        {Q},
        {R},
        {S},
        {T},
        {U},
        {V},
        {W},
        {X},
        {Y},
        {Z}
};


/*FONT_TABLE SmallFontTable8x8[] = {
        {a_lc},
        {b_lc},
        {c_lc},
        {d_lc},
        {e_lc},
        {f_lc},
        {g_lc},
        {h_lc},
        {i_lc},
        {j_lc},
        {k_lc},
        {l_lc},
        {m_lc},
        {n_lc},
        {o_lc},
        {p_lc},
        {q_lc},
        {r_lc},
        {s_lc},
        {t_lc},
        {u_lc},
        {v_lc},
        {w_lc},
        {x_lc},
        {y_lc},       
        {z_lc}
};*/

FONT_TABLE SmallFontTable8x8[] = {
        {a},
        {b},
        {c},
        {d},
        {e},
        {f},
        {g},
        {h},
        {i},
        {j},
        {k},
        {l},
        {m},
        {n},
        {o},
        {p},
        {q},
        {r},
        {s},
        {t},
        {u},
        {v},
        {w},
        {x},
        {y},       
        {z}
};

FONT_TABLE NumberFontTable8x8[] = {
        {zero},
        {one},
        {two},
        {three},
        {four},
        {five},
        {six},
        {seven},
        {eight},
        {nine}
};

FONT_TABLE CapitalFontTable8x16[] = {
        {A_8X16},
        {B_8X16},
        {C_8X16},
        {D_8X16},
        {E_8X16},
        {F_8X16},
        {G_8X16},
        {H_8X16},
        {I_8X16},
        {J_8X16},
        {K_8X16},
        {L_8X16},
        {M_8X16},
        {N_8X16},
        {O_8X16},
        {P_8X16},
        {Q_8X16},
        {R_8X16},
        {S_8X16},
        {T_8X16},
        {U_8X16},
        {V_8X16},
        {W_8X16},
        {X_8X16},
        {Y_8X16},
        {Z_8X16}
};

FONT_TABLE SmallFontTable8x16[] = {
        {a_8X16},
        {b_8X16},
        {c_8X16},
        {d_8X16},
        {e_8X16},
        {f_8X16},
        {g_8X16},
        {h_8X16},
        {i_8X16},
        {j_8X16},
        {k_8X16},
        {l_8X16},
        {m_8X16},
        {n_8X16},
        {o_8X16},
        {p_8X16},
        {q_8X16},
        {r_8X16},
        {s_8X16},
        {t_8X16},
        {u_8X16},
        {v_8X16},
        {w_8X16},
        {x_8X16},
        {y_8X16},       
        {z_8X16}
};


FONT_TABLE NumberFontTable8x16[] = {
        {zero_8X16},
        {one_8X16},
        {two_8X16},
        {three_8X16},
        {four_8X16},
        {five_8X16},
        {six_8X16},
        {seven_8X16},
        {eight_8X16},
        {nine_8X16}
};

FONT_TABLE SpecialChar8x16set1[] = {
        {exclamation_mark_8X16},
        {double_quotation_mark_8X16},
        {pound_8X16},
        {dollor_8X16},
        {percent_sign_8X16},
        {ampersand_8X16},
        {single_quotation_mark_8X16},
        {left_parenthesis_8X16},
        {right_parenthesis_8X16},
        {asterisk_8X16},
        {plus_8X16},
        {comma_8X16},
        {minus_8X16},
        {full_stop_8X16},
        {slash_8X16}
};
/////////////////////////////////////////////////////////////////////////////
FONT_TABLE SpecialChar8x16set2[] = {
        {colon_8X16},
        {semicolon_8X16},
        {less_than_8X16},
        {equal_8X16},
        {greater_than_8X16},
        {question_mark_8X16},
        {commercial_at_8X16}
};
/////////////////////////////////////////////////////////////////////////////
FONT_TABLE SpecialChar8x16set3[] = {
        {left_square_bracket_8X16},
        {backslash_8X16},
        {right_square_bracket_8X16},
        {spacing_circumflex_accent_8X16},
        {spacing_underscore_8X16},
        {back_apostrophe_8X16}
};
/////////////////////////////////////////////////////////////////////////////
FONT_TABLE SpecialChar8x16set4[] = {
        {left_curly_bracket_8X16},
        {vertical_bar_8X16},
        {right_curly_bracket_8X16},
        {tilde_accent_8X16}
};
// /////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////8X8 Special Characters ////////////////////////////
FONT_TABLE SpecialChar8x8set1[] = {
        {exclamation_mark_8X8},
        {double_quotation_mark_8X8},
        {pound_8X8},
        {dollor_8X8},
        {percent_sign_8X8},
        {ampersand_8X8},
        {single_quotation_mark_8X8},
        {left_parenthesis_8X8},
        {right_parenthesis_8X8},
        {asterisk_8X8},
        {plus_8X8},
        {comma_8X8},
        {minus_8X8},
        {full_stop_8X8},
        {slash_8X8}
};
/////////////////////////////////////////////////////////////////////////////
FONT_TABLE SpecialChar8x8set2[] = {
        {colon_8X8},
        {semicolon_8X8},
        {less_than_8X8},
        {equal_8X8},
        {greater_than_8X8},
        {question_mark_8X8},
        {commercial_at_8X8}
};
/////////////////////////////////////////////////////////////////////////////
FONT_TABLE SpecialChar8x8set3[] = {
        {left_square_bracket_8X8},
        {backslash_8X8},
        {right_square_bracket_8X8},
        {spacing_circumflex_accent_8X8},
        {spacing_underscore_8X8},
        {back_apostrophe_8X8}
};
/////////////////////////////////////////////////////////////////////////////
FONT_TABLE SpecialChar8x8set4[] = {
        {left_curly_bracket_8X8},
        {vertical_bar_8X8},
        {right_curly_bracket_8X8},
        {tilde_accent_8X8}
};
////////////////////////////////////////////////////////////////
char ipstring_Top_8X8[25]="   HAPPY BIRTHDAY   ";
char ipstring_Bottom_8X8[20] = "    HELLO    ";
char ipstring8X16[20] = "X Y Z A B C";
//static char select_buffer[288]={0};
// static char Top_Row_8X8_select_buffer[128] ={0};
// static char Bottom_Row_8X8_select_buffer[128] ={0};
// static char Single_Row_16X16_select_buffer[128] ={0};

void delay(int value)
{
        int i=0;
        for(i=0;i<=value;i++)
        {;}
}



// int display_string(char *charptr, uint8_t * outputbuffer)
// {
//     //printf("Hello World");
//     int i=0,position=0,position1=0,buffer_length=18;
//     float data8X8 = 0, data8X16 =0;
//     //int buffer_length = 16;
//     data8X8 = 0;// TThis variable is to be made one when 8X8 characters are to be displayed on the display
//     data8X16 = 1;// This variable is to be made one when 8X16 characters are to be displayed on the display
//         //printf("Hello World\n");
//         //////////////////////////////////////////////////////////////////////////////////////////////////
//         if(systemInfo.Board_Type == 1)
//         {
//                 for(i=0;i<=288;i++)
//         {
//                 select_buffer[i] = 0x00;
//                 buffer_length =18;
//         }
//         }
//         /////////////////////////////////////////////////////////////////////////////////////////////////
//         else if(systemInfo.Board_Type>1)
//         {
//         for(i=0;i<=255;i++)
//         {
//                 select_buffer[i] = 0x00;
//                 buffer_length=16;
//         }
//         }
//         //////////////////////////////////////////////////////////////////////////////////////////////////
//         /*k=0;
//         printf("\n\r");
//         for(j=0;j<=15;j++)
//         {
//                 for(i=0;i<=17;i++)
//                 {
//                         printf("0x%02X,", select_buffer[k]);
//                         delay(1000);
//                        k=k+1;

//                 }
//                 printf("\n");
//         }
//         k=0;
//         for(j=0;j<=15;j++)
//         {
//                 for(i=0;i<=17;i++)
//                 {
//                         printf("0x%02X\t", select_buffer[k]);
//                         k=k+1;
//                         delay(1000);

//                 }
//                 printf("\n");
//         }*/
//        //ipstring[] = "HELLO WORLD";
// 	/*if(ipstring_Top_8x8[0]=='H')
// 	{
// 		printf("\n ipstring first element is 'H'");
// 	}
// 	if(ipstring[1]=='E')
//         {
//                 printf("\n ipstring second element is 'E'");
//         }
// 	if(ipstring[2]=='L')
//         {
//                 printf("\n ipstring third element is 'L'");
//         }
// 	if(ipstring[3]=='L')
//         {
//                 printf("\n ipstring fourth element is 'L'");
//         }
// 	if(ipstring[4]=='O')
//         {
//                 printf("\n ipstring fifth element is 'O'");
//         }*/
//     if((data8X8==1)&&(data8X16==0))
//     {    
// 	for(position=0;position<=buffer_length-1;position++)
// 	{
// 		//position1=0;
// 		position1=position;

// 		//switch (ipstring_Top_8X8[position1])
//                 switch (charptr[position1])
// 		{
// 			//////////// Alphabets ////////////////////////////////////////////////////
// 			case 'A':
// 				 for(i=0;i<=7;i++)
//                 			{
//                         			select_buffer[position1]=A[i];
//                        				position1=position1+buffer_length;
// 					}
// 			break;
// 			case 'B':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=B[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			case 'C':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=C[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'D':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=D[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			case 'E':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=E[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'F':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=F[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'G':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=G[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'H':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=H[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			case 'I':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=I[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'J':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=J[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'K':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=K[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'L':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=L[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'M':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=M[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'N':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=N[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'O':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=O[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'P':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=P[i];
//                                                 position1=position1+buffer_length;
// 					}
// 			break;
// 			case 'Q':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=Q[i];
//                                                 position1=position1+buffer_length;
//                                         }
        
//                         break;
//                         case 'R':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=R[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'S':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=S[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'T':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=T[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'U':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=U[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'V':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=V[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'W':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=W[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'X':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=X[i];
//                                                 position1=position1+buffer_length;
        
              
// 					}
// 			break;
// 			case 'Y':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=Y[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'Z':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=Z[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			/////////////////////////////////////////////////////////////////////////////////////////////////////////
// 			// Numbers /////////////////////////////////////////////////////////////////////////////////////////////
// 			//
// 			case '1':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=one[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         }
//                                         printf("\n 1 appended into select_buffer at %d position",position1);
//                         break;
//                         case '2':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=two[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         }
//                                         printf("\n 2 appended into select_buffer at %d position",position1);
//                         break;
//                         case '3':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=three[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         }printf("\n 3 appended into select_buffer at %d position",position1);
//                         break;
//                         case '4':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=four[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         }printf("\n 4 appended into select_buffer at %d position",position1);
//                         break;
//                         case '5':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=five[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         }printf("\n 5 appended into select_buffer at %d position",position1);
//                         break;
//                         case '6':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=six[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         } printf("\n 6 appended into select_buffer at %d position",position1);
//                         break;
//                         case '7':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=seven[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         } printf("\n 7 appended into select_buffer at %d position",position1);
//                         break;
// 			 case '8':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=eight[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         } printf("\n 8 appended into select_buffer at %d position",position1);
//                         break;
//                         case '9':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=nine[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         } printf("\n 9 appended into select_buffer at %d position",position1);
//                         break;
//                         case '0':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=zero[i];
//                                                 position1=position1+buffer_length;
//                                                 //sleep_ms(5000);
//                                         } printf("\n 0 appended into select_buffer at %d position",position1);
//                         break;
// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 			case ' ':
// 				for(i=0;i<=7;i++)
// 					{
// 						select_buffer[position1] = space[i];
// 						position1=position1+buffer_length;
//                                                 ///sleep_ms(5000);
// 					} printf("\n Space ' ' appended into select_buffer at %d position",position1);
// 			break;


// 			default :
// 				for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=space[i];
//                                                 position1=position+buffer_length;
//                                                 //sleep_ms(5000);
//                                         } printf("\n *** DEFAULT *** Space ' ' appended into select_buffer at %d position",position1);
//                         break;

//                 }
// 		delay(200);
// 		printf("\n selected %c at %d \n",charptr[position],position );
// 	}
// 	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 	//First Line Data Appending Ends Here//////////////////////////////////////////////////////////////////////////////////
// 	//Second Line Data Appending Begins Here /////////////////////////////////////////////////////////////////////////////
// 	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 	for(position=0;position<=buffer_length-1;position++)
//         {
//                 position1=position+144;
//                 switch (ipstring_Bottom_8X8[position])
//                 {
//                         case 'A':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=A[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'B':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=B[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'C':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=C[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'D':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=D[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'E':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=E[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'F':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=F[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'G':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=G[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			 case 'H':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=H[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'I':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=I[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'J':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=J[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'K':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=K[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'L':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=L[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'M':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=M[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'N':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=N[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			            case 'O':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=O[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'P':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=P[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'Q':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=Q[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'R':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=R[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'S':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=S[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'T':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=T[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'U':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=U[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			case 'V':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=V[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'W':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=W[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'X':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=X[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'Y':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=Y[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case 'Z':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=Z[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// 			 /////////////////////////////////////////////////////////////////////////////////////////////////////////
//                         // Numbers /////////////////////////////////////////////////////////////////////////////////////////////
//                         //
//                         case '1':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=one[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '2':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=two[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '3':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=three[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '4':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=four[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '5':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=five[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '6':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=six[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '7':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=seven[i];
//                                                 position1=position1+buffer_length;
//                                         }
// 			 case '8':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=eight[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '9':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=nine[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
//                         case '0':
//                                  for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=zero[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;
// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//                         case ' ':
//                                 for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1] = space[i];
//                                                 position1=position1+buffer_length;
//                                         }
//                         break;


//         		default :
//                                 for(i=0;i<=7;i++)
//                                         {
//                                                 select_buffer[position1]=space[i];
//                                                 position1=position+buffer_length;
//                                         }
//                         break;
// 			}
//                 delay(200);
//                 printf("\n selected %c at %d \n",ipstring_Bottom_8X8[position],position );
//         }
//     }
// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// //Second Line data Appending Ends Here ////////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// //Switch case for 8X16 begins here //////////////////////////////////////////////////////////////////////////////////////////////////////////
// if((data8X8==0)&&(data8X16==1))
//     {
// 	for(position=0;position<=buffer_length-1;position++)
// 	{
// 		position1 = position ;
// 		switch(charptr[position])
// 				{
// 					case 'A':
// 						//alphabetsize=sizeof(A_8X16);
// 						for(i=0;i<=15;i++)
// 						{
// 						//select_buffer[position1]=A_8X16[i];
//                                                 select_buffer[position1]=A_8X16[i];
// 						                        /*select_buffer[position1+15]=A_8X16[1];
// 						                        select_buffer[position1+30]=A_8X16[2];
// 						                        select_buffer[position1+45]=A_8X16[3];
//                                                 select_buffer[position1+60]=A_8X16[4];
//                                                 select_buffer[position1+75]=A_8X16[5];
// 						                        select_buffer[position1+90]=A_8X16[6];
//                                                 select_buffer[position1+105]=A_8X16[7];
//                                                 select_buffer[position1+120]=A_8X16[8];
//                                                 select_buffer[position1+135]=A_8X16[9];
//                                                 select_buffer[position1+150]=A_8X16[10];
//                                                 select_buffer[position1+165]=A_8X16[11];
// 					                            select_buffer[position1+180]=A_8X16[12];
//                                                 select_buffer[position1+195]=A_8X16[13];
//                                                 select_buffer[position1+210]=A_8X16[14];
//                                                 select_buffer[position1+235]=A_8X16[15];
//                                                 select_buffer[position1+250]=A_8X16[16];
//                                                 select_buffer[position1+75]=A_8X16[5];*/

// 						position1=position1+buffer_length;
// 						}
// 					break;
					
// 					case 'B':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                 select_buffer[position1]=B_8X16[i];
//                                                 position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'C':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = C_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'D':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = D_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'E':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = E_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'F':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = F_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'G':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = G_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'H':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = H_8X16[i];
//                                                         position1=position1+buffer_length;

//                                                 }
//                                         break;
//                                         case 'I':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = I_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'J':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = J_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'K':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = K_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'L':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = L_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'M':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = M_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'N':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = N_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'O':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = O_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'P':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = P_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'Q':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = Q_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'R':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = R_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'S':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = S_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'T':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = T_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'U':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = U_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'V':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = V_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'W':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = W_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'X':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = X_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'Y':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = Y_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'Z':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = Z_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '1':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = one_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '2':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = two_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '3':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = three_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '4':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = four_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '5':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = five_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '6':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = six_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '7':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = seven_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '8':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = eight_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '9':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = nine_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case '0':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = zero_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'a':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = a_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'b':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = b_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'c':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = c_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'd':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = d_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'e':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = e_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'f':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = f_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'g':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = g_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'h':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = h_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'i':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = i_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'j':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = j_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'k':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = k_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'l':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = l_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'm':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = m_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'n':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = n_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'o':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = o_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'p':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = p_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'q':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = q_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'r':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = r_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 's':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = s_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 't':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = t_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'u':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = u_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'v':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = v_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'w':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = w_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'x':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = x_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'y':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = y_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
//                                         case 'z':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                         select_buffer[position1] = z_8X16[i];
//                                                         position1=position1+buffer_length;
//                                                 }
//                                         break;
// 					case ' ':
//                                                 for(i=0;i<=15;i++)
//                                                 {
//                                                 select_buffer[position1]=space_8X16[i];
//                                                 position1=position1+buffer_length;
//                                                 }
//                                         break;
// 					default :
// 						for(i=0;i<=15;i++)
// 						{
// 						select_buffer[position1]=space_8X16[i];
// 						position1=position1+buffer_length;
// 						}
// 					break;
// 				}
// 	}
	

/*	{
		select_buffer[0]=A[0];
		select_buffer[17]=A[1];
		select_buffer[34]=A[2];
		select_buffer[51]=A[3];
		select_buffer[68]=A[4];
		select_buffer[85]=A[4];
		select_buffer[102]=A[5];
		select_buffer[119]=A[6];
	}
	{
                select_buffer[0+1]=C[0];
                select_buffer[17+1]=C[1];
                select_buffer[34+1]=C[2];
                select_buffer[51+1]=C[3];
                select_buffer[68+1]=C[4];
                select_buffer[85+1]=C[4];
                select_buffer[102+1]=C[5];
                select_buffer[119+1]=C[6];
        }
*/
/*	k=0;
	printf("\n\r");
	for(j=0;j<=15;j++)
        {
                for(i=0;i<=15;i++)
                {
                        printf("0x%02X,", select_buffer[k]);
                        delay(1000);
			k=k+1;

                }
                printf("\n");
        }*/
	        /*k=0;
            printf("\n\r");
                for(j=0;j<=15;j++)
                {
                        for(i=0;i<=15;i++)
                        {
                                printf("0x%02X,\t", select_buffer[k]);
                                delay(1000);
                                k=k+1;

                        }
                        printf("\n");
                }
            printf("\n The size of C_8X16 is %ld ", sizeof(C_8X16));
            printf("\n The size of A_8X16 is %ld ", sizeof(A_8X16));
            printf("\n The size of B_8X16 is %ld ", sizeof(B_8X16));
            printf("\n The size of A_8X16 is %ld ", sizeof(A_8X16));
            return 0;
            //sleep_ms(50);*/
            

//         }
//         if(systemInfo.Board_Type > 1)
//         {
//         for(i=0;i<=255;i++)
//             {
//                 outputbuffer[i]=select_buffer[i];
//             }
//         }
//         if(systemInfo.Board_Type == 1)
//         {
//         for(i=0;i<=288;i++)
//             {
//                 outputbuffer[i]=select_buffer[i];
//             }
//         }
//         return 1;
// }

