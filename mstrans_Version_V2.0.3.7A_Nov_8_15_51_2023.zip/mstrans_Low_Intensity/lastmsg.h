#ifndef __LASTMSG__
#define __LASTMSG__

#define ERASE_BLOCK_SIZE 0x10000
#define MAX_BLOCK_SIZE  2048
#define MAX_MSG_SIZE (MAX_BLOCK_SIZE - (sizeof(int)*2))
#define BLOCK_FREE 0xffffffff
#define VALID_BLOCK_SIGNATURE   0xbead

uint8_t get_last_message(uint8_t *pMsg, uint16_t *pMsgLen);
uint8_t update_flash(uint8_t *pMsg, int msgLen);


#endif // __LASTMSG__
