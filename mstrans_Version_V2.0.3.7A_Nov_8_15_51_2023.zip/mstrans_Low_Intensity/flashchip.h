#include <stdio.h>
#include <stdlib.h>

#define WRITE_ENABLE        0x06
#define WRITE_DISABLE       0x04
#define READ_STATUS         0x05 
#define WRITE_STATUS        0x01
#define READ_DATA           0x03
#define FAST_READ_DATA      0x0b 
#define SECTOR_ERASE        0x20
#define BLOCK_ERASE_32K     0x52
#define BLOCK_ERASE_64K     0xd8
#define CHIP_ERASE          0xc7 
#define POWER_DOWN          0xb9
#define POWER_UP            0xab
#define READ_DEVINFO        0x90
#define READ_JEDEC_ID       0x9f
#define READ_UNIQUE_ID      0x4b
#define WRITE_PAGEPROGRAM   0x02

/* This is the maximum size in bytes that can be written in a single block */
#define MAX_PAGE_SIZE       256

void init_flash_chip(void);
void get_chipinfo(uint8_t *pManufacturer, uint8_t *pDeviceId);
uint8_t chipready();
void chipwakeup();
void chipErase();
void blockErase32k(uint32_t address);
void blockErase64k(uint32_t address);
void readFlash(uint32_t address, uint8_t *pBuf, uint32_t len);
void writeFlash(uint32_t address, uint8_t *pBuf, uint32_t len);
uint8_t readStatus();
void sectorErase(uint32_t address);

