/**
 * Copyright (c) 2022
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _PROC_CARD_
#define _PROC_CARD_


#define LED_DRIVER_BLANK_SIGNAL     21 
#define LED_DRIVER_STROBE_SIGNAL    14
#define LED_DRIVER_ROW_RESET_SIGNAL 8 // 9
#define LED_DRIVER_ROW_CLK_SIGNAL   9 // 8
#define LED_DRIVER_MOSI_SIGNAL      19
#define LED_DRIVER_SCLK_SIGNAL      18
#define LED_DRIVER_MISO_SIGNAL      20

#define ROW_CLK_ACTIVE      1
#define ROW_CLK_INACTIVE    0
#define ROW_RST_ACTIVE      1
#define ROW_RST_INACTIVE    0
#define DISABLE_OUTPUT      1
#define ENABLE_OUTPUT       0

#endif // _PROC_CARD_
