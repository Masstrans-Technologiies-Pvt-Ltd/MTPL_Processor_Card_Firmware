#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "hardware/pwm.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#include "init.h"
#include "main.h"
#include "display.h"
#include "scrollmsg.h"
#include "proc-card.h"
#include "hvrprot.h"
#include "utils.h"
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Xvalue=0,Yvalue=0;
uint16_t line=0,shift=0,value=0;
void CalculateXYCoordinates(uint8_t Xaxis, uint8_t Yaxis);
void coordinates(uint8_t xaxisvalue,uint8_t yaxisvalue);
void Appendintodisplaybuffer(uint8_t * inputdata,uint8_t * outputdata);
void scrollright(uint8_t * inputbuffer, uint8_t * outputbuffer);
void scrollleft(uint8_t * inputbuffer_left, uint8_t * outputbuffer_left);
extern unsigned char reverseBits(uint8_t num);

void group_manupulation_2b16R35C(uint8_t * inputbuf, uint8_t * output);

uint8_t Groupmanupulationcount=1;
uint8_t circular_shift(uint8_t input,uint8_t shiftval)
{
     uint8_t output;
     output = (input << shiftval) | (input >> (8 - shiftval));
     return output;
}
uint8_t circular_shiftR(uint8_t input,uint8_t shiftval)
{
     uint8_t output;
     output = (input >> shiftval) | (input << (8 - shiftval));
     return output;
}
 ///////////////////////////////////////////////////////////////////////////////////////////////
    uint8_t buf135X16[289] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   };
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t buf35X16[289] = {
0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xe1,0xc7,0x0f,0x0f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xe1,0x93,0x0e,0x6f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xef,0xbb,0x7e,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xe3,0xb9,0x1c,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xe1,0xb9,0x04,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xfc,0xb9,0xe4,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xfd,0x9b,0xe6,0x7f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xc1,0x83,0x0e,0x0f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xf7,0xef,0x9f,0x9f,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
   uint8_t Toprowbuf135X16[105] = { 
    0x00, 0x7E, 0x00, 0xFF, 0xC1, 0x80, 0xC1, 0x80, 0xC0, 0xC0, 0xC1, 0x80, 0xC3, 0x7F, 0x0F,
    0x00, 0xC3, 0x00, 0x18, 0xC1, 0x80, 0xC1, 0x80, 0xCC, 0xC0, 0x63, 0x00, 0x66, 0x06, 0x0F,
    0x00, 0xC0, 0x00, 0x18, 0xC1, 0x80, 0xC1, 0x80, 0xCC, 0xC0, 0x36, 0x00, 0x3C, 0x0C, 0x0F,
    0x00, 0x7E, 0x00, 0x18, 0xC1, 0x80, 0xC1, 0x80, 0xCC, 0xC0, 0x1C, 0x00, 0x18, 0x18, 0x0F,
    0x00, 0x03, 0x00, 0x18, 0xC1, 0x80, 0x63, 0x00, 0xCC, 0xC0, 0x36, 0x00, 0x18, 0x30, 0x0F,
    0x00, 0xC3, 0x00, 0x18, 0xC1, 0x80, 0x36, 0x00, 0xCC, 0xC0, 0x63, 0x00, 0x18, 0x60, 0x0F,
    0x00, 0x7E, 0x00, 0x18, 0x7F, 0x00, 0x1C, 0x00, 0x73, 0x80, 0xC1, 0x80, 0x18, 0xFE, 0x0F,
    };
   ////////////////////////////////////////////////////////////////////////////////////////////////////////////
   /////////////////////////////////////////////////////////////////////////////////////////////////////////////
   uint8_t Toprowbuf235X16[105] = { 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };
   ////////////////////////////////////////////////////////////////////////////////////////////////////////////
   ////////////////////////////////////////////////////////////////////////////////////////////////
   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Toprowbuf335X16[105] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Toprowbuf435X16[105] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};
uint8_t ptrinput[72], ptroutput[72];
void group_manupulation_2b16R35C(uint8_t * inputbuf,uint8_t * outputbuf)
{
    int i; 
    uint8_t x=0;
    
    //uint8_t *ptrinput=NULL, * ptroutput=NULL,x=0;
    // Dynamically allocate memory using malloc()
    for(i=0;i<72;i++)
    {
        ptrinput[i]=0x00;
    }
    for(i=0;i<72;i++)
    {
        ptroutput[i]=0x00;
    }
    for(i=0;i<72;i++)
    {
        ptrinput[i]=inputbuf[i];
        //printf(" assinged ptrinput[%d] = %d == inputbuf[%d] = %d\t",i,ptrinput[i],i,inputbuf[i]);
        //sleep_ms(500);
    }
     ////////////////byte 1////////////////////////////////////////////////////////////////////////////
    x=0;
    //ptrinput[0]=0xFF;
    x=ptrinput[0];
    x=x&0xE0;
    x=x>>5;
    //x=circular_shiftR(x,5);
    ptroutput[13]=ptroutput[13]|x;
    //ptrinput[0]=0xFF;
    x=0;
    x=ptrinput[0];
    x=x&0x1F;
    x=x<<3;
    //ptroutput[14]=0xFF;
    //x=circular_shift(x,3);
    ptroutput[14]=ptroutput[14]|x;
    /////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////byte 2//////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[1];
    x=x&0xE0;
    x=x>>5;
    ptroutput[14]=ptroutput[14]|x;
    x=0;
    x=ptrinput[1];
    x=x&0x1F;
    ptroutput[15]=x<<3;
    //////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////////////////
    /////////////// byte 3///////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[2];
    x=x&0xE0;
    x=x>>5;
    ptroutput[15]=ptroutput[15]|x;
    x=0;
    x=ptrinput[2];
    x=x&0x1F;
    ptroutput[16]=x<<3;
    ////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////byte 4/////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[3];
    x=x&0xE0;
    x=x>>5;
    ptroutput[16]=ptroutput[16]|x;
    x=0;
    x=ptrinput[3];
    x=x&0x1F;
    ptroutput[17]=x<<3;
    ////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////byte 5/////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[4];
    x=x&0xE0;
    x=x>>5;
    ptroutput[17]=ptroutput[17]|x;
    x=0;
    x=ptrinput[4];
    x=x&0x1C;
    x=x>>2;
    ptroutput[31]=ptroutput[31]|x;
    x=0;
    x=ptrinput[4];
    x=x&0x03;
    ptroutput[32]=ptroutput[32]|x<<6;    //09-08-2022 Working Modified
    /////////////////////////////////////////////////////////////////////////////////////
   /////////////////////////// byte 6 //////////////////////////////////////////////////
    x=0;
    x=ptrinput[5];
    x=x&0xFC;  // mask all bits except M S B last two bits
    x=x>>2;
    //x=circular_shiftR(x,2); //last two bits of ptroutput[33]
    ptroutput[32]=ptroutput[32]|x;// This line completes buf[5] completely
    ///////////////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[5];  // writing of buf[6] begins here
    x=x&0x03;
    x=x<<6;
    //x=circular_shiftR(x,6);
    ptroutput[33]=ptroutput[33]|x; // This line completes buf[6] L S B 6 bits
    /////////////////////////////////////////////////////////////////////////////////////
    /////////////byte 7 /////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[6];
    x=x&0xFC;  // mask all bits except M S B last two bits
    x=x>>2;
    //x=circular_shiftR(x,2); //last two bits of ptroutput[33]
    //ptroutput[33]=0xFF;
    ptroutput[33]=ptroutput[33]|x;// This line completes buf[5] completely
    ///////////////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[6];  // writing of buf[6] begins here
    x=x&0x03;
    x=x<<6;
    //x=circular_shift(x,6);
    ptroutput[34]=ptroutput[34]|x; // This line completes buf[6] L S B 6 bits
    /////////////////////////////////////////////////////////////////////////////////////
    /////////////byte 8 /////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[7];
    x=x&0xFC;  // mask all bits except M S B last two bits
    x=x>>2;
    //x=circular_shiftR(x,2); //last two bits of ptroutput[33]
    ptroutput[34]=ptroutput[34]|x;// This line completes buf[5] completely
    ///////////////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[7];  // writing of buf[7] begins here
    x=x&0x03;
    x=x<<6;
    //x=circular_shift(x,6);
    ptroutput[35]=ptroutput[35]|x; // This line completes buf[6] L S B 6 bits
    /////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////// byte 9//////////////////////////////////////////////////
    x=0;
    x=ptrinput[8]; // writing of buf[8] begins here
    x=x&0xFC;
    x=x>>2;
    //x=circular_shiftR(x,2);
    ptroutput[35]=ptroutput[35]|x; //This line compleats buf[8] M S B s
    ///////////////////////////////////////////////////////////////////////////////////
    //////////////////// writing byte 9 2 L S B part 2 board 3 begins here////////////
    x=0;
    x=ptrinput[8];
    x=x&0x03;
    x=x<<1;
    //x=circular_shift(x,1);
    ptroutput[49]=ptroutput[49]|x;// This compleats writing 9 byte in part 2 board 3
    //////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////// writing byte 10 begins here part 2 board 3///////////////
    x=0;
    x=ptrinput[9];
    x=x&0x80;
    x=x>>7;
    //x=circular_shiftR(x,7);
    ptroutput[49]=ptroutput[49]|x;
    //////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[9];
    x=x&0x7F;
    x=x<<1;
    //x=circular_shift(x,1);
    ptroutput[50]=ptroutput[50]|x; // This Compleates writing of 10 byte part 2 
    //////////////////////////////////////////////////////////////////////////////////
    /////////////////////// writing byte 11 begins here part 2 board 3///////////////
    x=0;
    x=ptrinput[10];
    x=x&0x80;
    x=x>>7;
    //x=circular_shiftR(x,7);
    ptroutput[50]=ptroutput[50]|x;
    //////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[10];
    x=x&0x7F;
    x=x<<1;
    //x=circular_shift(x,1);
    //x=x<<1;
    ptroutput[51]=ptroutput[51]|x; // This Compleates writing of 11 byte part 2 board 3
    ///////////////////////////////////////////////////////////////////////////////////
    /////////////////////// writing byte 12 begins here part 2 board 3///////////////
    x=0;
    x=ptrinput[11];
    x=x&0x80;
    x=x>>7;
    //x=circular_shiftR(x,7);
    ptroutput[51]=ptroutput[51]|x;
    //////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[11];
    x=x&0x7F;
    x=x<<1;
    //x=circular_shift(x,1);
    ptroutput[52]=ptroutput[52]|x; // This Compleates writing of 12 byte part 2 board 3
    ///////////////////////////////////////////////////////////////////////////////////
    /////////////////////// writing byte 13 begins here part 2 board 3///////////////
    x=0;
    x=ptrinput[12];
    x=x&0x80;
    x=x>>7;
    //x=circular_shiftR(x,7);
    ptroutput[52]=ptroutput[52]|x;
    //////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[12];
    x=x&0x7F;
    x=x<<1;
    //x=circular_shift(x,1);
    ptroutput[53]=ptroutput[53]|x; // This Compleates writing of 12 byte part 2 board 3
    ///////////////////////////////////////////////////////////////////////////////////
    /////////////////////// writing byte 14 begins here part 2 board 3///////////////
    x=0;
    x=ptrinput[13];
    x=x&0x80;
    x=x>>7;
    //x=circular_shiftR(x,7);
    ptroutput[53]=ptroutput[53]|x; // Writing M S B bite of byte 14
    //////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[13];
    x=x&0x70;
    x=x>>4;
    //x=circular_shiftR(x,4);
    ptroutput[67]=ptroutput[67]|x; // This Compleates writing 4, 2, 1 Bits of 14 byte part 2 board 4
    //////////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[13];
    x=x&0x0F;
    x=x<<4;
    //x=circular_shift(x,4);
    ptroutput[68]=ptroutput[68]|x; // This Compleates writing 4 L S B Bits of 14 byte part 2 board 3
    ///////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////// writing byte 15 begins here part 2 board 4 /////
    x=0;
    x=ptrinput[14];
    x=x&0xF0;
    x=x>>4;
    //x=circular_shiftR(x,4);
    ptroutput[68]=ptroutput[68]|x; // writing of 4 M S B  Bits of byte 15 part 2 board 4 
    ////////////////////////////////////////////////////////////////////////////////////    
    x=0;
    x=ptrinput[14];
    x=x&0x0F;
    x=x<<4;
    //x=circular_shift(x,4);
    ptroutput[69]=ptroutput[69]|x; // This Compleats writing of 4 L S B Bits of byte 15 part 2 board 4
    ////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////// writing byte 16 begins here part 2 board 4 /////
    x=0;
    x=ptrinput[15];
    x=x&0xF0;
    x=x>>4;
    //x=circular_shiftR(x,4);
    ptroutput[69]=ptroutput[69]|x; // writing of 4 M S B  Bits of byte 16 part 2 board 4 
    ////////////////////////////////////////////////////////////////////////////////////    
    x=0;
    x=ptrinput[15];
    x=x&0x0F;
    x=x<<4;
    //x=circular_shift(x,4);
    ptroutput[70]=ptroutput[70]|x; // This Compleats writing of 4 L S B Bits of byte 16 part 2 board 4
    ////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////// writing byte 17 begins here part 2 board 4 /////
    x=0;
    x=ptrinput[16];
    x=x&0xF0;
    x=x>>4;
    //x=circular_shiftR(x,4);
    ptroutput[70]=ptroutput[70]|x; // writing of 4 M S B  Bits of byte 17 part 2 board 4 
    ////////////////////////////////////////////////////////////////////////////////////    
    x=0;
    x=ptrinput[16];
    x=x&0x0F;
    x=x<<4;
    //x=circular_shift(x,4);
    ptroutput[71]=ptroutput[71]|x; // This Compleats writing of 4 L S B Bits of byte 17 part 2 board 4
    ////////////////////////////////////////////////////////////////////////////////////////
     ///////////////////////////////// writing byte 18 begins here part 2 board 4 /////
    x=0;
    x=ptrinput[17];
    x=x&0xF0;
    x=x>>4;
    //x=circular_shiftR(x,4);
    //ptroutput[71]=0xFF;
    ptroutput[71]=ptroutput[71]|x; // writing of 4 M S B  Bits of byte 18 part 2 board 4 
    ////////////////////////////////////////////////////////////////////////////////////    
    /*x=0;
    x=ptrinput[17];
    x=x&0x0F;
    x=x<<4;
    //x=circular_shiftR(x,4);
    ptroutput[71]=ptroutput[71]|x;*/ // This Compleats writing of 4 L S B Bits of byte 18 part 2 board 4 After 71 No LED is Present.*/
    ////////////////////////////////////////////////////////////////////////////////////////
    ////////*****************/////////////////////***************////////////////////////// Four Board Line 1 Compleats
    ////////////////////////////////////////////////////////////////////////////////////
    ///////////////////// byte 19 of 16 Rows X 35 Columns Two consiquitive boards/////
    x=0;
    x=ptrinput[18];
    x=reverseBits(x);
    x=x&0x1F;
    x=x<<3;
    //x=circular_shift(x,3);
    ptroutput[13]= ptroutput[13]|x; // This Line completes 5 M S B bits of byte [10] and there are remaining 3 L S B bits of byte[19] which are shuffeled as follows
    /////////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[18];
    x=reverseBits(x);
    x=x&0xE0;
    x=x>>5;
    //x=circular_shiftR(x,5);
    ptroutput[12]=ptroutput[12]|x; // This Completes remaining 3 L S B bits of byte [19]
    ///////////////////////////////////////////////////////////////////////////
    /////////////// byte Twenty begins here  //////////////////////////////////////
    x=0;
    x=ptrinput[19];
    x=reverseBits(x);
    x=x&0x1F;
    x=x<<3;
    //x=circular_shift(x,3);
    ptroutput[12]=ptroutput[12]|x; //  This Line completes 5 M S B bits of byte [11] and there are remaining 3 L S B bits of byte[Twenty] which are shuffeled as follows
    //////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[19];
    x=reverseBits(x);
    x=x&0xE0;
    x=x>>5;
    //x=circular_shiftR(x,5);
    ptroutput[11]=ptroutput[11]|x; // This Completes remaining 3 L S B bits of byte [Twenty]
    /////////////////////////////////////////////////////////////////////////
    /////////////// byte 21 begins here  //////////////////////////////////////
    x=0;
    x=ptrinput[20];
    x=reverseBits(x);
    x=x&0x1F;
    x=x<<3;
    //x=circular_shift(x,3);
    ptroutput[11]=ptroutput[11]|x; //  This Line completes 5 M S B bits of byte [21] and there are remaining 3 L S B bits of byte[10] which are shuffeled as follows
    //////////////////////////////////////////////////////////////////////////
    /*x=0;
    x=buf[11];
    x=reverseBits(x);
    x=x&0x1F;
    x=circular_shift(x,3);
    buf1[11]=buf1[11]|x;*/
    /////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[20];
    x=reverseBits(x);
    x=x&0xE0;
    x=x>>5;
    //x=circular_shiftR(x,5);
    ptroutput[10]=ptroutput[10]|x; // This Completes remaining 3 L S B bits of byte [21]
    /////////////////////////////////////////////////////////////////////////
     /////////////// byte 22 begins here  //////////////////////////////////////
    x=0;
    x=ptrinput[21];
    x=reverseBits(x);
    x=x&0x1F;
    x=x<<3;
    //x=circular_shift(x,3);
    ptroutput[10]=ptroutput[10]|x; //  This Line completes 5 M S B bits of byte [22] and there are remaining 3 L S B bits of byte[22] which are shuffeled as follows
    //////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[21];
    x=reverseBits(x);
    x=x&0xE0;
    x=x>>5;
    //x=circular_shiftR(x,5);
    ptroutput[9]=ptroutput[9]|x; // This Completes remaining 3 L S B bits of byte [Twenty Two]
    /////////////////////////////////////////////////////////////////////////
    /////////////// byte 23 begins here  //////////////////////////////////////
    x=0;
    x=ptrinput[22];
    x=reverseBits(x);
    x=x&0x07;
    x=x<<3;
    //x=circular_shift(x,3);
    ptroutput[9]=ptroutput[9]|x; //  This Line completes 3 M S B bits of byte [23] and there are remaining 5 L S B bits of byte[23] which are shuffeled as follows
    ///////////////////////////////////////////////////////////////////////////
    x=0;
    x=ptrinput[22];
    x=x&0x1F;
    x=reverseBits(x);
    ptroutput[31]=ptroutput[31]|x; // This Completes remaining 5 L S B bits of byte [23]
    /*x=0;
    x=buf[13]; 
    x=reverseBits(x);
    x=x&0xF8;
    ptroutput[31]=ptroutput[31]|x; // This Completes remaining 5 L S B bits of byte [23]*/
    ///////////////////////////////////////////////////////////////////////////
     /////////////// byte 24 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[23];  //0x17
     x=reverseBits(x);
     ptroutput[30]=x;
     //////////////////////////////////////////////////////////////////////////
     /////////////// byte 25 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[24];  //0x18
     x=reverseBits(x);
     ptroutput[29]=x;
     //////////////////////////////////////////////////////////////////////////
     /////////////// byte 26 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[25];  //0x19
     x=reverseBits(x);
     ptroutput[28]=x;
     //////////////////////////////////////////////////////////////////////////
     /////////////// byte 27 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[26]; //0x1A
     x=x&0xFC;
     x=reverseBits(x);
     ptroutput[27]=x;
     //////////////////////////////////////////////////////////////////////////
     /////////////// byte 27 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[26];  
     x=x&0x03;
     x=reverseBits(x);
     x=x>>3;
     //circular_shiftR(x,3);
     ptroutput[49]=ptroutput[49]|x; // 2 L S B Bits of byte 27 is compleated
     ///////////////////////////////////////////////////////////////////////////
     /////////////////////////// byte 28 begins here /////////////////////////
     x=0;
     x=ptrinput[27];
     x=x&0xE0;
     x=reverseBits(x);
     x=x<<5;
     //x=circular_shift(x,5);
     ptroutput[49]=ptroutput[49]|x;// This completes writing of byte 28 Compleatly
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[27];
     x=x&0x1F;
     x=reverseBits(x);
     x=x>>3;
     //x=circular_shiftR(x,3);
     ptroutput[48]=ptroutput[48]|x;// This compleats writing of byte 28 compleatly
     ////////////////////////////////////////////////////////////////////////////
     ///////////////////////////// byte 29 Writing begins here /////////////////
     x=0;
     x=ptrinput[28];
     x=x&0xE0;
     x=reverseBits(x);
     x=x<<5;
     //x=circular_shift(x,5);
     ptroutput[48]=ptroutput[48]|x;// This Compleats writing 3 M S B Bits of byte 29
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[28];
     x=x&0x1F;
     x=reverseBits(x);
     x=x>>3;
     //x=circular_shiftR(x,3);
     ptroutput[47]=ptroutput[47]|x; // This Compleats writing of byte 29 compleatly
     /////////////////////////////////////////////////////////////////////////
     ///////////////////////////// byte 30 Writing begins here /////////////////
     x=0;
     x=ptrinput[29];
     x=x&0xE0;
     x=reverseBits(x);
     x=x<<5;
     //x=circular_shift(x,5);
     ptroutput[47]=ptroutput[47]|x;// This Compleats writing 3 M S B Bits of byte 30
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[29];
     x=x&0x1F;
     x=reverseBits(x);
     x=x>>3;
     //x=circular_shiftR(x,3);
     ptroutput[46]=ptroutput[46]|x; // This Compleats writing of byte 30 compleatly
     /////////////////////////////////////////////////////////////////////////
     ///////////////////////////// byte 31 Writing begins here /////////////////
     x=0;
     x=ptrinput[30];
     x=x&0xE0;
     x=reverseBits(x);
     x=x<<5;
     //x=circular_shift(x,5);
     ptroutput[46]=ptroutput[46]|x;// This Compleats writing 3 M S B Bits of byte 31
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[30];
     x=x&0x1F;
     x=reverseBits(x);
     x=x>>3;
     //x=circular_shiftR(x,3);
     ptroutput[45]=ptroutput[45]|x; // This Compleats writing of byte 31 compleatly
     /////////////////////////////////////////////////////////////////////////
     //////////////////////// byte 32 Writing Begins here ///////////////////
     x=0;
     x=ptrinput[31];
     x=x&0x80;
     x=reverseBits(x);
     x=x<<5;
     //x=circular_shift(x,5);
     ptroutput[45]=ptroutput[45]|x;   // Writing M S B Bit of byte 32 compleats here
     //////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[31];
     x=x&0x7C;
     x=reverseBits(x);
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[67]=ptroutput[67]|x;  // Writing 4 2 1 8 4 Bits of Byte 32 compleats here
     ////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[31];
     x=x&0x03;
     x=reverseBits(x);
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[66]=ptroutput[66]|x;  // Writing 2 L S B Bits of byte 32 compleats here and this compleats writing of byte 32
     /////////////////////////////////////////////////////////////////////////
     /////////////// byte 33 Writing begins here ////////////////////////////
     x=0;
     x=ptrinput[32];
     x=x&0xFC;
     x=reverseBits(x);
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[66]=ptroutput[66]|x;  // writing 6 M S B Bits of byte 33 compleats here
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[32];
     x=x&0x03;
     x=reverseBits(x);
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[65]=ptroutput[65]|x;  // Writing 2 L S B  Bits of byte 33 compleats here
     /////////////////////////////////////////////////////////////////////////////
     /////////////// byte 34 Writing begins here ////////////////////////////
     x=0;
     x=ptrinput[33];
     x=x&0xFC;
     x=reverseBits(x);
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[65]=ptroutput[65]|x;  // writing 6 M S B Bits of byte 34 compleats here
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[33];
     x=x&0x03;
     x=reverseBits(x);
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[64]=ptroutput[64]|x;  // Writing 2 L S B  Bits of byte 34 compleats here
     /////////////////////////////////////////////////////////////////////////////
     /////////////// byte 35 Writing begins here ////////////////////////////
     x=0;
     x=ptrinput[34];
     x=x&0xFC;
     x=reverseBits(x);
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[64]=ptroutput[64]|x;  // writing 6 M S B Bits of byte 35 compleats here
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[34];
     x=x&0x03;
     x=reverseBits(x);
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[63]=ptroutput[63]|x;  // Writing 2 L S B  Bits of byte 35 compleats here
     ///////////////////////////////////////////////////////////////////////////
     /////////////// byte 36 Writing begins here ////////////////////////////
     x=0;
     x=ptrinput[35];
     x=x&0xF0;
     x=reverseBits(x);
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[63]=ptroutput[63]|x;  // writing 4 M S B Bits of byte 36 compleats here
     //////////////////////////////////////////////////////////////////////////  Four Board Line 2 Compleats
                                                                                                //////////////////////////////////////////////
     
     /////////////// byte 37 begins here  //////////////////////////////////////
     /////////////// byte 37 begins here  //////////////////////////////////////
     x=0;
     //ptrinput[36]=0xFF;
     x=ptrinput[36];
     x=x&0x80;
     x=x>>7;
     ptroutput[4]=ptroutput[4]|x; // M S B of byte 37 is compleated
     x=0;
     x=ptrinput[36];
     x=x&0x7F;
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[5]=ptroutput[5]|x;// This completes writing of byte 37 Compleatly
     ////////////////////////////////////////////////////////////////////////////
     //////////////////// byte 38  begins here //////////////////////////////////
     x=0;
     x=ptrinput[37];
     x=x&0x80;
     x=x>>7;
     ptroutput[5]=ptroutput[5]|x; // M S B of byte 38 is compleated
     x=0;
     x=ptrinput[37];
     x=x&0x7F;
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[6]=ptroutput[6]|x;// This completes writing of byte 38 Compleatly
     ////////////////////////////////////////////////////////////////////////////
     
      /////////////// byte 39 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[38];
     x=x&0x80;
     x=x>>7;
     ptroutput[6]=ptroutput[6]|x; // M S B of byte 39 is compleated
     x=0;
     x=ptrinput[38];
     x=x&0x7F;
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[7]=ptroutput[7]|x;// This completes writing of byte 39 Compleatly
     ////////////////////////////////////////////////////////////////////////////
     /////////////// byte 40 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[39];  //0x27
     x=x&0x80;
     x=x>>7;
     ptroutput[7]=ptroutput[7]|x; // M S B of byte 40 is compleated
     x=0;
     x=ptrinput[39];
     x=x&0x7F;
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[8]=ptroutput[8]|x;// This completes writing of byte 40 Compleatly
     ////////////////////////////////////////////////////////////////////////////
     /////////////// byte 41 begins here  //////////////////////////////////////
     x=0;
     x=ptrinput[40];  //0x28
     x=x&0x80;
     x=x>>7;
     //ptroutput[8]=0xFF;
     ptroutput[8]=ptroutput[8]|x; //    M S B bits of byte 41 is compleated
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[40];   //0x28
     x=x&0x60;
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[9]=ptroutput[9]|x;// This  writes 7 and 6 bits of byte 41 
     ////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[40];  //0x28
     x=x&0x10;
     x=x>>4;
     ptroutput[22]=ptroutput[22]|x; // This writes 5 bit of byte 41
     //////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[40];  //0x28
     x=x&0x0F;
     x=x<<4;
     ptroutput[23]=ptroutput[23]|x;  // This write completes remaining 4 L S B bits of byte 41 and byte 41 ends here
     ////////////////////////////////////////////////////////////////////////
     /////////////////////byte 42 writing begins here///////////////////////
     x=0;
     x=ptrinput[41];  // 0x29
     x=x&0xF0;
     x=x>>4;
     //x=circular_shift(x,4);
     ptroutput[23]=ptroutput[23]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[41];  //0x29
     x=x&0x0F;
     x=x<<4;
     //x=circular_shiftR(x,4);
     ptroutput[24]=ptroutput[24]|x; // byte 42 writing compleats here
     /////////////////////////////////////////////////////////////////////
     /////////////////////byte 43 writing begins here///////////////////////
     x=0;
     x=ptrinput[42];  //0x2A
     x=x&0xF0;
     x=x>>4;
     //x=circular_shiftR(x,4);
     ptroutput[24]=ptroutput[24]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[42];  //0x2A
     x=x&0x0F;
     x=x<<4;
     //x=circular_shift(x,4);
     ptroutput[25]=ptroutput[25]|x; // byte 43 writing compleats here
     /////////////////////////////////////////////////////////////////////
     /////////////////////byte 44 writing begins here///////////////////////
     x=0;
     x=ptrinput[43];  //0x2B
     x=x&0xF0;
     x=x>>4;
     //x=circular_shiftR(x,4);
     ptroutput[25]=ptroutput[25]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[43];  //0x2B
     x=x&0x0F;
     x=x<<4;
     //x=circular_shift(x,4);
     ptroutput[26]=ptroutput[26]|x; // byte 44 writing compleats here
     /////////////////////////////////////////////////////////////////////
    /////////////////////byte 45 writing begins here///////////////////////
     x=0;
     x=ptrinput[44];  //0x2C
     x=x&0xF0;
     x=x>>4;
     //x=circular_shiftR(x,4);
     ptroutput[26]=ptroutput[26]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[44];  //0x2C
     x=x&0x0C;
     x=x<<4;
     //x=circular_shift(x,4);
     ptroutput[27]=ptroutput[27]|x;  //byte 45 writing compleates here board 2
     ////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[44];
     x=x&0x02;
     x=x>>1;
     //x=circular_shiftR(x,1);
     ptroutput[40]=ptroutput[40]|x;  // writing X X X X X X 2 X L S B Bit of byte 45 is compleated here board 3
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[44];  //0x2C
     x=x&0x01;
     x=x<<7;
     //x=circular_shift(x,7);
     ptroutput[41]=ptroutput[41]|x;  // Writing X X X X X X X 1 L S B Bit of Byte 45 is compleated here board 3 This compleats writing of complete byte 45
     ///////////////////////////////////////////////////////////////////////
     //////////////////////////// Writing byte 46 begins here /////////////
     x=0;
     x=ptrinput[45];  //0x2D
     x=x&0xFE;
     x=x>>1;
     //x=circular_shiftR(x,1);
     ptroutput[41]=ptroutput[41]|x;  // Writing 7 M S B Bits of byte 46 complets here
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[45];  //0x2D
     x=x&0x01;
     x=x<<7;
     //x=circular_shift(x,7);
     ptroutput[42]=ptroutput[42]|x; // Writing L S B Bit of byt 46 complets here and This write complets writing byte 46 compleatly
     ////////////////////////////////////////////////////////////////////////
     //////////////////////////// Writing byte 47 begins here /////////////
     x=0;
     x=ptrinput[46];  //0x2E
     x=x&0xFE;
     x=x>>1;
     //x=circular_shiftR(x,1);
     ptroutput[42]=ptroutput[42]|x;  // Writing 7 M S B Bits of byte 47 complets here
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[46];  //0x2E
     x=x&0x01;
     x=x<<7;
     //x=circular_shift(x,7);
     ptroutput[43]=ptroutput[43]|x; // Writing L S B Bit of byt 47 complets here and This write complets writing byte 37 compleatly
     ////////////////////////////////////////////////////////////////////////
     //////////////////////////// Writing byte 48 begins here /////////////
     x=0;
     x=ptrinput[47];  //0x2F
     x=x&0xFE;
     x=x>>1;
     //x=circular_shiftR(x,1);
     ptroutput[43]=ptroutput[43]|x;  // Writing 7 M S B Bits of byte 48 complets here
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[47];  //0x2F
     x=x&0x01;
     x=x<<7;
     //x=circular_shift(x,7);
     ptroutput[44]=ptroutput[44]|x; // Writing L S B Bit of byt 48 complets here and This write complets writing byte 39 compleatly
     ////////////////////////////////////////////////////////////////////////
     //////////////////////////// Writing byte 49 begins here /////////////
     x=0;
     x=ptrinput[48];  //0x30
     x=x&0xFE;
     x=x>>1;
     //x=circular_shiftR(x,1);
     ptroutput[44]=ptroutput[44]|x;  // Writing 7 M S B Bits of byte 49 complets here
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[48];  //0x30
     x=x&0x01;
     x=x<<7;
     //x=circular_shift(x,7);
     ptroutput[45]=ptroutput[45]|x; // Writing L S B Bit of byt 49 complets here and This write complets writing byte 49 compleatly
     ////////////////////////////////////////////////////////////////////////
     ///////////////////////// Writing byte 50 begins here /////////////////
     x=0;
     x=ptrinput[49];  // 0x31
     x=x&0x80;
     x=x>>1;
     //x=circular_shiftR(x,1);
     ptroutput[45]=ptroutput[45]|x;  // writing 2 M S B Bits of byte 50 
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[49];  // 0x31
     x=x&0x40;
     x=x>>6;
     //x=circular_shift(x,2);
     ptroutput[58]=ptroutput[58]|x;  // Writing X X 2 X X X X X Bit of byte 50 Compleats here
     /////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[49]; // 0x31
     x=x&0x3F;
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[59]=ptroutput[59]|x;  // Writing 5 L S B Bits of byte 50 compleats here and this compleats byte 50 compleatly
     //////////////////////////////////////////////////////////////////////
     ////////////////// Writing 51 byte Begins here //////////////////////
     x=0;
     x=ptrinput[50]; // 0x32
     x=x&0xC0;
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[59]=ptroutput[59]|x;  // Writing 2 M S B Bits of byte 51 compleats here
     ////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[50]; // 0x32
     x=x&0x3F;
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[60]=ptroutput[60]|x;  // writing 6 L S B Bits of Byte 51 Compleats here and this compleats writing byte 51 compleatly
     //////////////////////////////////////////////////////////////////////////
     ////////////////// Writing 52 byte Begins here //////////////////////
     x=0;
     x=ptrinput[51]; // 0x33
     x=x&0xC0;
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[60]=ptroutput[60]|x;  // Writing 2 M S B Bits of byte 52 compleats here
     ////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[51]; // 0x33
     x=x&0x3F;
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[61]=ptroutput[61]|x;  // writing 6 L S B Bits of Byte 52 Compleats here and this compleats writing byte 52 compleatly
     //////////////////////////////////////////////////////////////////////////
     ////////////////// Writing 53 byte Begins here //////////////////////
     x=0;
     x=ptrinput[52]; // 0x34
     x=x&0xC0;
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[61]=ptroutput[61]|x;  // Writing 2 M S B Bits of byte 53 compleats here
     ////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[52]; // 0x34
     x=x&0x3F;
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[62]=ptroutput[62]|x;  // writing 6 L S B Bits of Byte 53 Compleats here and this compleats writing byte 53 compleatly
     //////////////////////////////////////////////////////////////////////////
     ////////////////// Writing 54 byte Begins here //////////////////////
     x=0;
     x=ptrinput[53]; // 0x35
     x=x&0xC0;
     x=x>>6;
     //x=circular_shiftR(x,6);
     ptroutput[62]=ptroutput[62]|x;  // Writing 2 M S B Bits of byte 54 compleats here
     ////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[53]; // 0x35
     x=x&0x30;
     x=x<<2;
     //x=circular_shift(x,2);
     ptroutput[63]=ptroutput[63]|x;  // writing 6 L S B Bits of Byte 54 Compleats here and this compleats writing byte 54 compleatly
     //////////////////////////////////////////////////////////////////////////
     /////////////////////************/////////////////////**************/////// Four Board Line 3 Compleats
     //////////////////////////////////////////////////////////////////////////
     //ptrinptu
     //ptroutput[44]=0xFF;
     /////////////////////byte 55 writing begins here///////////////////////
     x=0;
     x=ptrinput[54];  //0x36
     x=x&0xFE; 
     x=reverseBits(x);
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[4]=ptroutput[4]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[54];  //0x36
     x=x&0x01;
     x=reverseBits(x);
     x=x>>7;
     //x=circular_shiftR(x,7);
     ptroutput[3]=ptroutput[3]|x;  //byte 55 writing compleates here*/
     ////////////////////////////////////////////////////////////////////////
     /////////////////////byte 56 writing begins here///////////////////////
     x=0;
     x=ptrinput[55];  //0x37
     x=x&0xFE; 
     x=reverseBits(x);
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[3]=ptroutput[3]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[55];  //0x37
     x=x&0x01;
     x=reverseBits(x);
     x=x>>7;
     //x=circular_shiftR(x,7);
     ptroutput[2]=ptroutput[2]|x;  //byte 56 writing compleates here*/
     ////////////////////////////////////////////////////////////////////////
     /////////////////////byte 57 writing begins here///////////////////////
     x=0;
     x=ptrinput[56];  //0x38
     x=x&0xFE; 
     x=reverseBits(x);
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[2]=ptroutput[2]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[56];  //0x38
     x=x&0x01;
     x=reverseBits(x);
     x=x>>7;
     //x=circular_shiftR(x,7);
     ptroutput[1]=ptroutput[1]|x;  //byte 57 writing compleates here*/
     ////////////////////////////////////////////////////////////////////////
     /////////////////////byte 58 writing begins here///////////////////////
     x=0;
     //ptrinput[57]=0xF3;
     x=ptrinput[57];  //0x39
     x=x&0xFE; 
     x=reverseBits(x);
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[1]=ptroutput[1]|x;
     ///////////////////////////////////////////////////////////////////////
     x=0;
     //ptrinput[57]=0xF3;
     x=ptrinput[57];  //0x39
     x=x&0x01;
     x=reverseBits(x);
     x=x>>7;
     //x=circular_shiftR(x,7);
     ptroutput[0]=ptroutput[0]|x;  //byte 58 writing compleates here
     ////////////////////////////////////////////////////////////////////////
     /////////////////////byte 59 writing begins here///////////////////////
     x=0;
     //ptrinput[58]=0x4F;
     x=ptrinput[58];  //0x3A
     x=x&0xE0; 
     x=reverseBits(x);
     x=x<<1;
     //x=circular_shift(x,1);
     ptroutput[0]=ptroutput[0]|x;

     ///////////////////////////////////////////////////////////////////////
     x=0;
     //ptrinput[58]=0x4F;
     x=ptrinput[58];  // 0x3A
     x=x&0x1F;
     x=reverseBits(x);
     //x=x>>2;
     x=circular_shiftR(x,2);
     ptroutput[22]=ptroutput[22]|x;  //byte 59 writing compleates here*/
    ///**********XXX************
     ////////////////////////////////////////////////////////////////////////*/
     /////////////////////byte 60 writing begins here///////////////////////
     x=0;
     x=ptrinput[59];  //0x3B
     x=x&0xC0; 
     x=reverseBits(x);
     x=x<<6;
     //x=circular_shift(x,6);
     ptroutput[22]=ptroutput[22]|x; // Writing 2 M S B Bits of byte 60 compleates here. 
     ///////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[59];  //0x3B
     x=x&0x3F;
     x=reverseBits(x);
     x=x>>2;
     //x=circular_shiftR(x,2);
     ptroutput[21]=ptroutput[21]|x;  //Writing 6 L S B Bits of byte 60 writing compleates here also This compleates writing byte 60 compleatly.
     ////////////////////////////////////////////////////////////////////////*/
     /////////// byte 61 writing begins here ////////////////////////////////
     x=0;
     x=ptrinput[60];  //0x3C
     x=x&0xC0;
     x=reverseBits(x);
     x=x<<6;
     //x=circular_shift(x,6);
     ptroutput[21]=ptroutput[21]|x; // Writing 2 M S B Bits of byte 61 is compleated here
     //////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[60];  // 0x3C
     x=x&0x3F;
     x=reverseBits(x);
     x=x>>2;
     //x=circular_shiftR(x,2);
     ptroutput[20]=ptroutput[20]|x;  // Writing 6 L S B Bits of byte 61 writing compleates here also This Write compleates writing byte 61 compleatly.
     ////////////////////////////////////////////////////////////////////////// 
     /////////////////// byte 62 writing begins here /////////////////////////
     x=0;
     x=ptrinput[61];  //0x3D
     x=x&0xC0;
     x=reverseBits(x);
     x=x<<6;
     //x=circular_shiftR(x,6);
     ptroutput[20]=ptroutput[20]|x;  // Writing 2 M S B Bits of byte 62 is compleated here
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[61];  //0x3D
     x=x&0x3F;
     x=reverseBits(x);
     x=x>>2;
     //x=circular_shift(x,2);
     //ptroutput[19]=0xFF;
     ptroutput[19]=ptroutput[19]|x; //  Writing 6 L S B Bits of byte 62 writing compleates here also This write compleates writing byte 62 compleatly.
     ///////////////////////////////////////////////////////////////////////////
     ////////////////// byte 63 writing begins here ///////////////////////////
     x=0;
     //ptrinput[62]=0xFF;
     x=ptrinput[62];  //0x3E
     x=x&0xC0;
     x=reverseBits(x);
     x=x<<6;
     //x=circular_shiftR(x,6);
     ptroutput[19]=ptroutput[19]|x; // Writing 2 M S B Bits of byte 63 is compleated
     ////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[62];  //0x3E
     x=x&0x3C;
     x=reverseBits(x);
     x=x>>2;
     // x=circular_shiftR(x,2);
     ptroutput[18]=ptroutput[18]|x; // writing 6 L S B Bits of byte 63 writing compleats here Thsi Write compleats writing byte 36 Compleatly.
     //////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[62];  //0x3E
     x=x&0x03;
     x=reverseBits(x);
     x=x>>5;
     //x=circular_shiftR(x,5);
     ptroutput[40]=ptroutput[40]|x;  // This write compleats writing 
     ////////////////////////////////////////////////////////////////////////////////////
     /////////////////// writing byte 64 /////////////////////////////
     x=0;
     x=ptrinput[63];  //0x3F
     x=x&0xF8;
     x=reverseBits(x);
     x=x<<3;
     //x=circular_shift(x,3);
     ptroutput[40]=ptroutput[40]|x; //  This compleats writing of 5 M S B Bits of byte 64
     ////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[63];  //0x3F
     x=x&0x07;
     x=reverseBits(x);
     x=x>>5;
     //x=circular_shiftR(x,5);
     //x=x>>5;
     ptroutput[39]=ptroutput[39]|x; // This compleats writing of byte 64
     ///////////////////////////////////////////////////////
     /////////////////// writing byte 65 /////////////////////////////
     x=0;
     x=ptrinput[64];  //0x40
     x=x&0xF8;
     x=reverseBits(x);
     x=x<<3;
     //x=circular_shift(x,3);
     ptroutput[39]=ptroutput[39]|x; //  This compleats writing of 5 M S B Bits of byte 64
     ////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[64];  //0x40
     x=x&0x07;
     x=reverseBits(x);
     x=x>>5;
     //x=circular_shiftR(x,5);
     //x=x>>5;
     ptroutput[38]=ptroutput[38]|x; // This compleats writing of byte 65
     ///////////////////////////////////////////////////////

     /////////////////// writing byte 66 /////////////////////////////
     x=0;
     x=ptrinput[65];  //0x41
     x=x&0xF8;
     x=reverseBits(x);
     x=x<<3;
     //x=circular_shift(x,3);
     ptroutput[38]=ptroutput[38]|x; //  This compleats writing of 5 M S B Bits of byte 66
     ////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[65];  //0x41
     x=x&0x07;
     x=reverseBits(x);
     x=x>>5;
     //x=circular_shiftR(x,5);
     //x=x>>5;
     //ptroutput[39]=0xFF;
     ptroutput[37]=ptroutput[37]|x; // This compleats writing of byte 66
     ///////////////////////////////////////////////////////

     /////////////////// writing byte 67 /////////////////////////////
     x=0;
     x=ptrinput[66];  //0x42
     x=x&0xF8;
     x=reverseBits(x);
     x=x<<3;
     //x=circular_shift(x,3);
     ptroutput[37]=ptroutput[37]|x; //  This compleats writing of 5 M S B Bits of byte 67
     ////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[66];  //0x42
     x=x&0x07;
     x=reverseBits(x);
     x=x>>5;
     //x=circular_shiftR(x,5);
     //x=x>>5;
     //ptroutput[39]=0xFF;
     ptroutput[36]=ptroutput[36]|x; // This compleats writing of byte 67
     ///////////////////////////////////////////////////////

     /////////////////////////////////////////////////////////////////////////
     ////////////////////// writing byte 68 begins here /////////////////////      
     x=0;
     x=ptrinput[67];  //0x43
     x=x&0x80;
     x=reverseBits(x);
     x=x<<3;
     //x=circular_shift(x,3);
     ptroutput[36]=ptroutput[36]|x;  // Writing  M S B Bit of byte 68 is compleated here
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[67];  //0x43
     x=x&0x7F;
     x=reverseBits(x);
     ptroutput[58]=ptroutput[58]|x;  // Writing 7 L S B Bits of byte 68 is compleated here
     ////////////////////////////////////////////////////////////////////////////
     
     ////////////////////// writing byte 69 begins here /////////////////////      
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[68];  //0x44
     x=x&0xFF;
     x=reverseBits(x);
     ptroutput[57]=ptroutput[57]|x;  // Writing 7 L S B Bits of byte 69 is compleated here
     ////////////////////////////////////////////////////////////////////////////

     ////////////////////// writing byte 70 begins here /////////////////////      
     
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[69];  //0x45
     x=x&0xFF;
     x=reverseBits(x);
     ptroutput[56]=ptroutput[56]|x;  // Writing 7 L S B Bits of byte 70 is compleated here
     ////////////////////////////////////////////////////////////////////////////

     ////////////////////// writing byte 71 begins here /////////////////////      
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[70];  //0x46
     x=x&0xFF;
     x=reverseBits(x);
     ptroutput[55]=ptroutput[55]|x;  // Writing 7 L S B Bits of byte 71 is compleated here
     ////////////////////////////////////////////////////////////////////////////

    ////////////////////// writing byte 72 begins here /////////////////////      
     ////////////////////////////////////////////////////////////////////////////
     x=0;
     x=ptrinput[71];  //0x47
     x=x&0xFF;
     x=reverseBits(x);
     ptroutput[54]=ptroutput[54]|x;  // Writing 7 L S B Bits of byte 72 is compleated here
     ////////////////////////////////////////////////////////////////////////////
     ///////////************//////////////////**************///////////////////// Four Board Line 4 Compleats
     ///////////////////////////////////////////////////////////////////////////

     for(i=0;i<72;i++)
    {
        outputbuf[i]=ptroutput[i];
    }   
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static uint8_t ptrinputshuffel[289],ptroutputshuffel[289], ptr72_1[73], ptr72_2[73], ptr72_3[73], ptr72_4[73], ptr72_output[73];
void shuffel16RX35C(uint8_t * input289, uint8_t * output289)
{
    int i,j; 

    for(i=0;i<289;i++)
    {
        ptrinputshuffel[i]=0x00;
    }

    for(i=0;i<289;i++)
    {
        ptroutputshuffel[i]=0x00;
    }


    for(i=0;i<289;i++)
    {
        ptrinputshuffel[i]=input289[i];
    }

    for(i=0;i<72;i++)
    {
        ptr72_1[i]=ptrinputshuffel[i];
    }

    j=i;

    for(i=0;i<72;i++)
    {
        ptr72_2[i]=ptrinputshuffel[j];
        j=j+1;
    }

    for(i=0;i<72;i++)
    {
        ptr72_3[i]=ptrinputshuffel[j];
        j=j+1;
    }

    for(i=0;i<72;i++)
    {
        ptr72_4[i]=ptrinputshuffel[j];
        j=j+1;
    }

    group_manupulation_2b16R35C(ptr72_1,ptr72_output);

    for(i=0;i<=72;i++)
    {
        ptroutputshuffel[i]=ptr72_output[i];
    }

    group_manupulation_2b16R35C(ptr72_2,ptr72_output);
    j=i;
    for(i=0;i<72;i++)
    {
        ptroutputshuffel[j]=ptr72_output[i];
        j=j+1;
    }

    group_manupulation_2b16R35C(ptr72_3,ptr72_output);
    for(i=0;i<72;i++)
    {
        ptroutputshuffel[j]=ptr72_output[i];
        j=j+1;
    }

    group_manupulation_2b16R35C(ptr72_4,ptr72_output);
    for(i=0;i<72;i++)
    {
        ptroutputshuffel[j]=ptr72_output[i];
        j=j+1;
    }

    for(i=0;i<289;i++)
    {
        output289[i]=ptroutputshuffel[i];
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////