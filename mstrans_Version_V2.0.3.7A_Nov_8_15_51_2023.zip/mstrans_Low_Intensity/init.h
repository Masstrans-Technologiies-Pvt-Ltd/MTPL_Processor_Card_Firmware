//
// This file holds macros and function prototypes for initializing hardware
//
#ifndef __INIT__
#define __INIT__

#define PICO_LED_PIN 25
//#define LED_DRIVER_BLANK_SIGNAL     21
#define RS485_DIR 15
#define ASW0v 2
#define ASW1v 3
#define ASW2v 4
#define ASW3v 13
#define TEST_MODE 1
#define DEBUG_LED 0
#define UART_TX 16
#define UART_RX 17
#define ADC_LDR 26

#define ADC_LDR_INPUT 0

#define UART_BAUD_RATE 4800
#define HIGH    1
#define LOW     0

void init_gpio(void);
void init_adc(void);
void init_spi(void);
void init_pwm(void);
void init_led_driver_signals(void);
void init_spi_6000();

#ifdef ENABLE_PID_DTC
void init_temperature_sensor();
int read_cpu_temperature();
#endif
#endif // __INIT__
