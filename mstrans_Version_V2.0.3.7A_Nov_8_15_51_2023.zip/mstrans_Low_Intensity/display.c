//
// This file implements functions for display
//
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "hardware/pwm.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#include "hardware/timer.h"
#include "hardware/sync.h"
#include "hardware/irq.h"
#else
#include <ncurses.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#endif
#include "init.h"
#include "main.h"
#include "display.h"
#include "scrollmsg.h"
#include "proc-card.h"
#include "hvrprot.h"
#include "utils.h"
#include "pwm.h"
#include "ldr.h"
#include "deviceid.h"
#include "display35X16.h"
#include "displaycharlib.h"
#include "uart.h"
#include "errno.h"
#include "rcerr.h"
#include "pid_dtc.h"
#define SCROLL_SPEED 56
// #define SCROLL_SPEED_140X16 45
uint16_t SCROLL_SPEED_140X16 = 48;

#define DATA_DRIVING_MODE_TIMEOUT_US 15
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #define Version_NO 2.0
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define PWM_PIN 21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DISPLAY_MODE_INFO displayInfo = {0};
static uint8_t scrollBuffer[289];
static uint32_t displayDataChanged = 0;

#ifdef ENABLE_PICO
// #ifdef ENABLE_35X16

// #else

// #endif
// #ifdef ENABLE_35X16
static uint8_t outputbuffer_289[289];
// #else
static uint8_t outputbuffer_256[256];
// #endif
#endif
uint8_t displayBuf[MAX_VERTICAL_BYTE_BUFFER * 2] = {0};
int displayBufLen = 0;
bool Powerflag = 0;
// int flashingflag =0;
int led_value = 0;
// int previousflashingflag2 = 0;
int displayc_Scroll_Count = 0;
int displayc_Scroll_Count2 = 0;
/////////////////////////////////////////////////////////////////
/////// Testing mode functionality variables
int emptyflag = 0, loop_started = 0;
int loop_iteration_count_Test_Mode = 0;
int PwmBrightValue = 55, PwmDimValue = 245, current_Dim_Value = 245;
int Display_Buffer_Empty_Flag = 0; // for checking whether display buffer is empty or not
int scrolling_count = 0;           // scroll_Test_message = 0;
int result = 0;
int Scroll_Direction = SCROLL_LEFT;
int New_Message_Received_Data_Structure_Updated = 0;
static absolute_time_t onTimeEnd;
static absolute_time_t offTimeEnd;
static absolute_time_t currTime;
int idx = 0, row_count = 0;
// static uint8_t all_leds_on = 0;
bool lock_buf = false;
bool First_Count = true;
/////////////////////////////////////////////////////////////////
// int firstflag =0;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// This code is added to check the number of times the scrolling is happening on a single message  added on  27-12-2022 11_20////////////
// uint8_t  messagechangedflag = 0, messagelength = 0;
uint8_t scrolling_is_compleated_flag = 0;
uint8_t previous_scrolling_state = 0;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// bool timer_fired =0;
// uint8_t MAX_BOARDS = 4;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// Display Width in Columns //////////////////////////////////////////////////////////////
#ifdef ENABLE_PICO
uint8_t DISPLAY_WIDTH_IN_COLUMNS1dc = 144; //(32 * MAX_BOARDS);
#else
uint8_t DISPLAY_WIDTH_IN_COLUMNS1dc = 128; //(32 * MAX_BOARDS);
#endif
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////
void staticdisplay(uint8_t *inputdata);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef ENABLE_PICO
// extern uint8_t *fptr;
#endif

// #define TEST_DISPLAY

extern uint8_t horizBuffer[MAX_ROWS][MAX_HORIZONTAL_BYTE_BUFFER];
extern uint16_t vertBufferLen;
extern uint16_t horizBufferLen;
extern int topBufferLen;
extern int bottomBufferLen;
extern uint8_t hvrprot_Test_Mode_Message_Flag;
extern uint8_t hvrprot_Test_Mode_Scroll_Completed_Flag;
uint8_t Board140X16 = 0, Board128X16 = 0, Board96X16 = 0;
uint8_t Testmodeflag = 0, displaycharlibfuncalled = 0;
uint8_t flashingdata_arr[17] = {0};
//extern PID_DTC_INFO pid_dtc;
//uint32_t work_hour_count = 0;
// 18:35  ///////////////////////////////////////////////////////////////////////////////////////////
int First_Time_Flag = 0;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////// February 28 2023 11:37 //////////////////////////////////////////////////////////////////////////
uint8_t Identify_Is_Display_Empty(void);
///////////////////////////////////////////////////////////////////////////////////////////////////////
////////// May 20 2023 15:55  //////////////////////////////////////////////////////////////////////////////
uint8_t call_Test_Mode_Functionality(void);
//////////////////////////////////////////////////////////////////////////////////////////////////////
void call_LDR_Functionality(void);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void Power_On_Mode_Check(void);
//////////////////////////////////////////////////////////////////////////////////////////////////////////
void Scroll_Decision_Call(void);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void Flashing_Decision_Call(void);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void Re_Identify_The_Board_Type(void);
////////////////////////////////////////////////////////////////////////////////////////////////////////
void Display_Driving_Loop(void);
////////////////////////////////////////////////////////////////////////////////////////////////////////
void New_Message_Arrival_Check(void);
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////July 11 _2023_17:17/////////////////////////////////////////////////////////////////////
void printbuffer(uint8_t *inputbuffer, int sizeofbuffer);
////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////July 12 2023 _12:25 ///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
void printhorizontalbuffer(void);
/// @brief ////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
int map(int x, int in_min, int in_max, int out_min, int out_max);
///////////////////////////////////////////////////////////////////////////////////////////////////////

// BOARD_TYPE =1;
// #ifndef ENABLE_35X16

#ifdef ENABLE_35X16
void shuffel16RX35C(uint8_t *buf, uint8_t *buf1);
#endif

#ifdef ENABLE_PICO
////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////// MASSTRANS PROC CARD V 2.0/////////////////////////////////////////
uint8_t testModeBuffer_256[256] = {
    0xc1, 0x87, 0x07, 0xe3, 0xf3, 0xfd, 0xfe, 0x0e, 0x18, 0x67, 0xe0, 0xff, 0x3f, 0xc7, 0xf1, 0xf8,
    0xe3, 0x8d, 0x8c, 0x36, 0x18, 0x61, 0x83, 0x1b, 0x1c, 0x6c, 0x30, 0xc1, 0xb0, 0x6c, 0x1b, 0x0c,
    0xf7, 0x98, 0xcc, 0x06, 0x00, 0x61, 0x83, 0x31, 0x9e, 0x6c, 0x00, 0xc1, 0xb0, 0x6c, 0x1b, 0x00,
    0xdd, 0xb0, 0x67, 0xe3, 0xf0, 0x61, 0xfe, 0x60, 0xdb, 0x67, 0xe0, 0xff, 0x3f, 0xcc, 0x1b, 0x00,
    0xc1, 0xbf, 0xe0, 0x30, 0x18, 0x61, 0x8c, 0x7f, 0xd9, 0xe0, 0x30, 0xc0, 0x31, 0x8c, 0x1b, 0x00,
    0xc1, 0xb0, 0x6c, 0x36, 0x18, 0x61, 0x86, 0x60, 0xd8, 0xec, 0x30, 0xc0, 0x30, 0xcc, 0x1b, 0x0c,
    0xc1, 0xb0, 0x67, 0xe3, 0xf0, 0x61, 0x83, 0x60, 0xd8, 0x67, 0xe0, 0xc0, 0x30, 0x67, 0xf1, 0xf8,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x1c, 0x3f, 0xcf, 0xf1, 0xfc, 0xc3, 0x07, 0xe0, 0xe1, 0xfe, 0x7f, 0x83, 0x06, 0x7f, 0x00, 0xf8,
    0x36, 0x30, 0x6c, 0x1b, 0x06, 0xe3, 0x0c, 0x31, 0xb1, 0x83, 0x60, 0xc3, 0x06, 0xc1, 0x81, 0x8c,
    0x63, 0x30, 0x6c, 0x1b, 0x06, 0xf3, 0x0c, 0x03, 0x19, 0x83, 0x60, 0xc3, 0x06, 0x01, 0x83, 0x06,
    0xc1, 0xb0, 0x6c, 0x1b, 0x06, 0xdb, 0x0c, 0x06, 0x0d, 0xfe, 0x60, 0xc3, 0x06, 0x7f, 0x03, 0x06,
    0xff, 0xb0, 0x6c, 0x1b, 0x06, 0xcf, 0x0c, 0x07, 0xfd, 0x8c, 0x60, 0xc1, 0x8c, 0xc0, 0x03, 0x06,
    0xc1, 0xb0, 0x6c, 0x1b, 0x06, 0xc7, 0x0c, 0x36, 0x0d, 0x86, 0x60, 0xc0, 0xd8, 0xc0, 0x39, 0x8c,
    0xc1, 0xbf, 0xcf, 0xf1, 0xfc, 0xc3, 0x07, 0xe6, 0x0d, 0x83, 0x7f, 0x80, 0x70, 0xff, 0xb8, 0xf8,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
///////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////
////////////// HELLO WORLD 123 WELCOME THE DAY ///////////////////////////////////////////////////////
/*uint8_t testModeBuffer_256[256] = {
0x41,0x7F,0x40,0x40,0x7F,0x00,0x41,0x7F,0x7E,0x40,0x7E,0x00,0x10,0x3E,0x3E,0x00,
0x41,0x40,0x40,0x40,0x41,0x00,0x49,0x41,0x41,0x40,0x41,0x00,0x30,0x41,0x41,0x00,
0x41,0x40,0x40,0x40,0x41,0x00,0x49,0x41,0x41,0x40,0x41,0x00,0x50,0x01,0x01,0x00,
0x7F,0x7C,0x40,0x40,0x41,0x00,0x49,0x41,0x7E,0x40,0x41,0x00,0x10,0x3E,0x3E,0x00,
0x41,0x40,0x40,0x40,0x41,0x00,0x49,0x41,0x44,0x40,0x41,0x00,0x10,0x40,0x01,0x00,
0x41,0x40,0x40,0x40,0x41,0x00,0x49,0x41,0x42,0x40,0x41,0x00,0x10,0x40,0x41,0x00,
0x41,0x7F,0x7F,0x7F,0x7F,0x00,0x36,0x7F,0x41,0x7F,0x7E,0x00,0x7C,0x7F,0x3E,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x41,0x7F,0x40,0x3E,0x7F,0x41,0x7F,0x00,0x7F,0x41,0x7F,0x00,0x7E,0x08,0x41,0x00,
0x49,0x40,0x40,0x41,0x41,0x63,0x40,0x00,0x08,0x41,0x40,0x00,0x41,0x14,0x22,0x00,
0x49,0x40,0x40,0x40,0x41,0x55,0x40,0x00,0x08,0x41,0x40,0x00,0x41,0x22,0x14,0x00,
0x49,0x7C,0x40,0x40,0x41,0x49,0x7C,0x00,0x08,0x7F,0x7C,0x00,0x41,0x41,0x08,0x00,
0x49,0x40,0x40,0x40,0x41,0x41,0x40,0x00,0x08,0x41,0x40,0x00,0x41,0x7F,0x08,0x00,
0x49,0x40,0x40,0x41,0x41,0x41,0x40,0x00,0x08,0x41,0x40,0x00,0x41,0x41,0x08,0x00,
0x36,0x7F,0x7F,0x3E,0x7F,0x41,0x7F,0x00,0x08,0x41,0x7F,0x00,0x7E,0x41,0x08,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};*/

//////////////////////////////////////////////////////////////////////////////////////////////////////
// #else
/// @brief ///////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// HARMONICA  Test display//////////////////////////////////////
/*uint8_t testModeBuffer_289[289] = {
   0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xc7,0xf3,0xfc,0x3f,0xc0,0x3f,0x07,0xfc,0x3f,0x80,0x7f,0x0f,0xcf,0x1f,0xc0,0x7f,0x0f,0xf0
,0xc7,0xe1,0xf8,0x1f,0xc7,0x0f,0x03,0xf8,0x3e,0x1e,0x1e,0x07,0xcf,0x1f,0x0f,0x3e,0x07,0xf0
,0xc7,0xe1,0xf9,0x8f,0xc7,0x8f,0x11,0xf1,0x3c,0x7f,0x8e,0x23,0xcf,0x1e,0x3f,0xfe,0x63,0xf0
,0xc0,0x01,0xf1,0x8f,0xc7,0x0f,0x11,0xe3,0x38,0x7f,0x8e,0x31,0xcf,0x1c,0x3f,0xfc,0x61,0xf0
,0xc0,0x01,0xe3,0xc7,0xc0,0x3f,0x18,0xc7,0x38,0x7f,0x8e,0x38,0xcf,0x1c,0x7f,0xf8,0xf1,0xf0
,0xc7,0xe1,0xc0,0x03,0xc7,0x1f,0x1c,0x0f,0x3c,0x7f,0x8e,0x3c,0x0f,0x1c,0x3f,0xf0,0x00,0xf0
,0xc7,0xe1,0xc7,0xe1,0xc7,0x8f,0x1e,0x0f,0x3c,0x3e,0x1e,0x3e,0x0f,0x1e,0x1f,0xb1,0xf8,0x70
,0xc7,0xf1,0x8f,0xf1,0xc7,0xc7,0x1e,0x1f,0x3f,0x00,0x7e,0x3f,0x0f,0x1f,0x80,0x63,0xfc,0x70
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0
,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xf0


};*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @brief ///////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// MASSTRANS  Test Display//////////////////////////////////////////////////
uint8_t testModeBuffer_289[289] = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xc3, 0xff, 0x07, 0xf8, 0x7f, 0xe0, 0x7f, 0x03, 0x80, 0x07, 0x00, 0xff, 0xe1, 0xff, 0x1f, 0xcf, 0xc0, 0xff,
    0xc1, 0xff, 0x07, 0xf8, 0x3f, 0x80, 0x3c, 0x01, 0x80, 0x07, 0x00, 0x3f, 0xc1, 0xfe, 0x0f, 0xc7, 0x80, 0x7f,
    0xc0, 0xfe, 0x07, 0xf0, 0x3f, 0x8f, 0x3c, 0x79, 0xf8, 0x7f, 0x1c, 0x1f, 0xc0, 0xfe, 0x07, 0xc7, 0x0f, 0x7f,
    0xc0, 0xfe, 0x47, 0xf2, 0x3f, 0x8f, 0xf8, 0xff, 0xfc, 0x7f, 0x1f, 0x1f, 0x88, 0xfe, 0x03, 0xc7, 0x1f, 0xff,
    0xc4, 0x7c, 0x47, 0xe3, 0x1f, 0x8f, 0xf8, 0x7f, 0xfc, 0x7f, 0x1f, 0x1f, 0x8c, 0x7e, 0x23, 0xc7, 0x0f, 0xff,
    0xc4, 0x7c, 0xc7, 0xe3, 0x1f, 0x83, 0xfc, 0x1f, 0xfc, 0x7f, 0x1e, 0x1f, 0x9c, 0x7e, 0x31, 0xc7, 0x03, 0xff,
    0xc6, 0x38, 0xc7, 0xc7, 0x8f, 0xc0, 0x7e, 0x03, 0xfc, 0x7f, 0x00, 0x7f, 0x1c, 0x3e, 0x30, 0xc7, 0x80, 0xff,
    0xc6, 0x39, 0xc7, 0xc7, 0x8f, 0xf0, 0x3f, 0x81, 0xfc, 0x7f, 0x00, 0x7f, 0x3e, 0x3e, 0x38, 0xc7, 0xe0, 0x7f,
    0xc7, 0x11, 0xc7, 0x80, 0x07, 0xfe, 0x1f, 0xe0, 0xfc, 0x7f, 0x1c, 0x3e, 0x00, 0x1e, 0x3c, 0x47, 0xfc, 0x3f,
    0xc7, 0x03, 0xc7, 0x80, 0x07, 0xff, 0x1f, 0xf0, 0xfc, 0x7f, 0x1e, 0x3e, 0x00, 0x1e, 0x3c, 0x07, 0xfe, 0x3f,
    0xc7, 0x83, 0xc7, 0x8f, 0xc3, 0xff, 0x1f, 0xf0, 0xfc, 0x7f, 0x1e, 0x1c, 0x7f, 0x1e, 0x3e, 0x07, 0xfe, 0x3f,
    0xc7, 0x83, 0xc7, 0x1f, 0xe3, 0x1c, 0x38, 0xe1, 0xfc, 0x7f, 0x1f, 0x1c, 0x7f, 0x8e, 0x3e, 0x07, 0x18, 0x3f,
    0xc7, 0x87, 0xc7, 0x1f, 0xe3, 0x00, 0x78, 0x03, 0xfc, 0x7f, 0x1f, 0x08, 0xff, 0x8e, 0x3f, 0x07, 0x00, 0x7f,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xe1, 0xfe, 0x0f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xc3, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////// MASSTRANS  Test Display//////////////////////////////////////////////////
uint8_t Test_Sample_289[289] = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_35X16
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t inputbuffer123[289] = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe1, 0xc7, 0x0f, 0x0f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe1, 0x93, 0x0e, 0x6f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xef, 0xbb, 0x7e, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe3, 0xb9, 0x1c, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe1, 0xb9, 0x04, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xfc, 0xb9, 0xe4, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xfd, 0x9b, 0xe6, 0x7f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xc1, 0x83, 0x0e, 0x0f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xf7, 0xef, 0x9f, 0x9f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0

};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t outputbuffer123[289] = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe1, 0xc7, 0x0f, 0x0f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe1, 0x93, 0x0e, 0x6f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xef, 0xbb, 0x7e, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe3, 0xb9, 0x1c, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xe1, 0xb9, 0x04, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xfc, 0xb9, 0xe4, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xfd, 0x9b, 0xe6, 0x7f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xc1, 0x83, 0x0e, 0x0f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xf7, 0xef, 0x9f, 0x9f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0,
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xf0

};
#endif
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////// Row Reset Pulse///////////////////////////////////////////////////////////////////////////////
void Row_RESET(void)
{
    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_ACTIVE);
    sleep_us(5);
    // for(i=0;i<=1;i++)
    //{;}
    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_INACTIVE);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////// Row Reset Pulse///////////////////////////////////////////////////////////////////////////////
void Row_CLOCK_PULSE(void)
{
    gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
    sleep_us(10);
    gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////// Latch Pulse Send data///////////////////////////////////////////////////////////////////////////////
// void Send_data_latch_pulse_2()
// {

//     int j;
//     //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     // Drive Row clock low
//     gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
//     for(j=0;j<=1;j++)
//     {;}

//     // Drive Strobe active halfway into row clock
//     gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);

//     for(j=0;j<=1;j++)
//     {;}

//     // Drive Strobe inactive halfway into row clock
//     gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);

//     for(j=0;j<=1;j++)
//     {;}
//     // Complete row clock pulse by driving it high
//     gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
//     //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//     /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     /*sleep_us(350);

//                 //irqStatus = save_and_disable_interrupts ();

//                 // Toggle row clock and strobe
//                 // Drive Row clock low
//                 gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
//                 // If it is the 4rth row, drive row reset active
//                 //if (row_count >= 4)
//                     //gpio_put( LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_ACTIVE);

//                 for(j=0;j<=2;j++)
//                 {;}

//                 // If it is the 4rth row, drive row reset inactive
//                 //if (row_count >= 4)
//                 //    gpio_put( LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_INACTIVE);

//                 for(j=0;j<=1;j++)
//                 {;}

//                 // Drive Strobe active halfway into row clock
//                 gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);

//                 for(j=0;j<=1;j++)
//                 {;}

//                 // Drive Strobe inactive halfway into row clock
//                 gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);

//                 for(j=0;j<=2;j++)
//                 {;}
//                 // Complete row clock pulse by driving it high
//                 gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);

//                 //sleep_us(280);
//                 ////////////////////////////////////////////////////////////////////////////////////////////////
//                 ///////////////////////////////////////////////////////////////////////////////////////////////

//                 */
// }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// Power on identification 2 ///////////////////////////////////////////////////////////////
void poweronindication_2(void)
{
    int idx = 0, row_count = 0, row_count1 = 0, loop = 0;

    if (systemInfo.Board_Type == 1)
    {
        memset(displayBuf, 0, sizeof(displayBuf));
        Row_RESET();
    }
    if (systemInfo.Board_Type > 1)
    {
        memset(outputbuffer123, 0, sizeof(outputbuffer123));
    }
    if (systemInfo.Board_Type <= 1)
    {
        displayBuf[0] = 0x80;
        shuffel16RX35C(displayBuf, outputbuffer123);
        for (loop = 0; loop <= 55; loop++)
        {
            {
                spi_write_blocking(spi_default, &outputbuffer123[idx], 72);
                if (row_count == 0)
                {
                    idx += 73;
                }
                if (row_count == 1)
                {
                    idx = 145;
                }
                if (row_count == 2)
                {
                    idx = 217;
                }

                row_count++;

                if (row_count >= 4)
                {
                    row_count = 0;
                    idx = 0;
                    // Row_RESET();
                }
                gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
                sleep_us(5);
                gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);
                sleep_us(10);
                gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
                sleep_us(5);
                gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
                sleep_us(10);
                if (row_count == 1)
                {
                    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_ACTIVE);
                }
                sleep_us(5);

                if (row_count == 1)
                {
                    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE);
                }
                gpio_put(LED_DRIVER_BLANK_SIGNAL, ENABLE_OUTPUT);  // Modified Code Jan 27_2023
                sleep_us(150);                                     // Determines the LED Intensity
                gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT); // Modified Code Jan 27_2023
                sleep_us(50);
            }
        }
    }

    else if (systemInfo.Board_Type == 2 || systemInfo.Board_Type == 3)
    {
        idx = 0;
        // printf("\n System is in poweronled Identification Mode with board");
        if (systemInfo.Board_Type == 2)
        {
            // printf("128X16\n");
        }
        if (systemInfo.Board_Type == 3)
        {
            // printf("96X16\n");
        }
        outputbuffer123[12] = 0x80;
        Row_RESET();
        for (loop = 0; loop <= 35; loop++)
        {

            if (systemInfo.Board_Type == 2)
            {
                spi_write_blocking(spi_default, &outputbuffer123[idx], 64);
            }
            else if (systemInfo.Board_Type == 3)
            {
                spi_write_blocking(spi_default, &outputbuffer123[idx], 48);
            }
            // spi_write_blocking(spi_default,&outputbuffer_power_t[idx],48);
            idx += 64;
            sleep_us(100);
            row_count1++;

            if (row_count1 >= 4)
            {
                row_count1 = 0;
                idx = 0;
                // Row_RESET();
            }
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
            sleep_us(5);
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);
            sleep_us(10);
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
            sleep_us(5);
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
            sleep_us(10);

            if (row_count == 0)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_ACTIVE);
            }

            sleep_us(5);

            if (row_count == 0)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE);
            }
            gpio_put(LED_DRIVER_BLANK_SIGNAL, ENABLE_OUTPUT); // Modified Code Jan 27_2023
            // PwmBrightValue donotes the Intensity of LED Lighting
            // sleep_us(PwmBrightValue);
            sleep_us(250);                                     // Determines the LED Intensity
            gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT); // Modified Code Jan 27_2023
            // Dim value, increase this value to make display dimmer
            // sleep_us(PwmDimValue);
            sleep_us(50);
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////// flashing function ends here ////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////// timer Alarm function ////////////////////////////////////////////////////////////////////////////
static uint64_t get_time(void)
{
    // Reading low latches the high value
    uint32_t lo = timer_hw->timelr;
    uint32_t hi = timer_hw->timehr;
    return ((uint64_t)hi << 32u) | lo;
}

static uint8_t displayState = DISPLAY_STATE_ON;

#ifdef ENABLE_ALARM

#define ALARM_NUM 0
#define ALARM_IRQ TIMER_IRQ_0

// Alarm interrupt handler
static volatile bool alarm_fired;

static void alarm_irq(void)
{
    // Clear the alarm irq
    hw_clear_bits(&timer_hw->intr, 1u << ALARM_NUM);

    // Assume alarm 0 has fired
    alarm_fired = true;
    if (displayState == DISPLAY_STATE_ON)
        gpio_put(LED_DRIVER_BLANK_SIGNAL, ENABLE_OUTPUT); // Modified Code Jan 27_2023
}

static void alarm_in_us(uint32_t delay_us)
{
    // Enable the interrupt for our alarm (the timer outputs 4 alarm irqs)
    hw_set_bits(&timer_hw->inte, 1u << ALARM_NUM);
    // Set irq handler for alarm irq
    irq_set_exclusive_handler(ALARM_IRQ, alarm_irq);
    // Enable the alarm irq
    irq_set_enabled(ALARM_IRQ, true);
    // Enable interrupt in block and at processor

    // Alarm is only 32 bits so if trying to delay more
    // than that need to be careful and keep track of the upper
    // bits
    uint64_t target = timer_hw->timerawl + delay_us;

    // Write the lower 32 bits of the target time to the alarm which
    // will arm it
    timer_hw->alarm[ALARM_NUM] = (uint32_t)target;
}
#endif

void INIT_GPIO_PIN(int pin, bool direction) // direction = 1 then its output if direction = 0 then its input
{
    gpio_init(pin);
    if (direction)
    {
        gpio_set_dir(pin, GPIO_OUT);
    }
    else
    {
        gpio_set_dir(pin, GPIO_IN);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_PICO
void init_led_driver(void)
{
    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE);
    sleep_us(100);
    // Go back to First Group
    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE);
}

unsigned char reverseBits(uint8_t num)
{
    unsigned int NO_OF_BITS = 8;
    unsigned char reverse_num = 0;
    int i;
    for (i = 0; i < NO_OF_BITS; i++)
    {
        if ((num & (1 << i)))
        {
            reverse_num |= 1 << ((NO_OF_BITS - 1) - i);
            // sleep_us(1);
        }
    }
    return reverse_num;
}

static uint8_t ptrinput[64], ptroutput[64];

void fourboard_groupmanupulation(uint8_t *ip, uint8_t *op)
{
    int i;
    for (i = 0; i < 64; i++)
    {
        ptrinput[i] = ip[i];
    }
    {
        // 1 to 4
        //////////////////////////
        ptroutput[12] = (ptrinput[0]); // 1-->0x00
        ptroutput[13] = (ptrinput[1]); // 2-->0x01
        ptroutput[14] = (ptrinput[2]); // 3-->0x02
        ptroutput[15] = (ptrinput[3]); // 4-->0x03
        //////////////////////////
        // 4 to 8
        //////////////////////////
        ptroutput[11] = reverseBits(ptrinput[16]); // 0x04
        ptroutput[10] = reverseBits(ptrinput[17]); // 0x05
        ptroutput[9] = reverseBits(ptrinput[18]);  // 0x06
        ptroutput[8] = reverseBits(ptrinput[19]);  // 0x07
        //////////////////////////
        // 8 to 12
        //////////////////////////
        ptroutput[4] = (ptrinput[32]); // 9-->0x08
        ptroutput[5] = (ptrinput[33]); // 10-->0x09
        ptroutput[6] = (ptrinput[34]); // 11-->0x0A
        ptroutput[7] = (ptrinput[35]); // 12-->-x0B
        //////////////////////////
        // 12 to 16
        //////////////////////////
        ptroutput[3] = reverseBits(ptrinput[48]); // 13 --> 0x0C
        ptroutput[2] = reverseBits(ptrinput[49]); // 14 --> 0x0D
        ptroutput[1] = reverseBits(ptrinput[50]); // 15 --> 0x0E
        ptroutput[0] = reverseBits(ptrinput[51]); // 16 --> 0x0F
        //////////////////////////
        // 17 to 20
        //////////////////////////
        ptroutput[28] = (ptrinput[4]); // 17 --> 0x10
        ptroutput[29] = (ptrinput[5]); // 18 --> 0x11
        ptroutput[30] = (ptrinput[6]); // 19 --> 0x12
        ptroutput[31] = (ptrinput[7]); // 20 --> 0x13
        //////////////////////////
        // 21 to 24
        //////////////////////////
        ptroutput[27] = reverseBits(ptrinput[20]); // 21 --> 0x14
        ptroutput[26] = reverseBits(ptrinput[21]); // 22 --> 0x15
        ptroutput[25] = reverseBits(ptrinput[22]); // 23 --> 0x16
        ptroutput[24] = reverseBits(ptrinput[23]); // 24 --> 0x17
        //////////////////////////
        // 25 to 28
        //////////////////////////
        ptroutput[20] = (ptrinput[36]); // 25 --> 0x18
        ptroutput[21] = (ptrinput[37]); // 26 --> 0x19
        ptroutput[22] = (ptrinput[38]); // 27 --> 0x1A
        ptroutput[23] = (ptrinput[39]); // 28 --> 0x1B
        //////////////////////////
        // 29 to 32
        //////////////////////////
        ptroutput[19] = reverseBits(ptrinput[52]); // 29 --> 0x1C
        ptroutput[18] = reverseBits(ptrinput[53]); // 30 --> 0x1D
        ptroutput[17] = reverseBits(ptrinput[54]); // 31 --> 0x1E
        ptroutput[16] = reverseBits(ptrinput[55]); // 32 --> 0x1F
        //////////////////////////
        // 33 to 36
        //////////////////////////
        ptroutput[44] = (ptrinput[8]);  // 33 --> 0x20
        ptroutput[45] = (ptrinput[9]);  // 34 --> 0x21
        ptroutput[46] = (ptrinput[10]); // 35 --> 0x22
        ptroutput[47] = (ptrinput[11]); // 36 --> 0x23
        // 37 to 40
        //////////////////////////
        ptroutput[43] = reverseBits(ptrinput[24]); // 37 --> 0x24
        ptroutput[42] = reverseBits(ptrinput[25]); // 38 --> 0x25
        ptroutput[41] = reverseBits(ptrinput[26]); // 39 --> 0x26
        ptroutput[40] = reverseBits(ptrinput[27]); // 40 --> 0x27
        //////////////////////////
        // 41 to 44
        //////////////////////////
        ptroutput[36] = (ptrinput[40]); // 41 --> 0x28
        ptroutput[37] = (ptrinput[41]); // 42 --> 0x29
        ptroutput[38] = (ptrinput[42]); // 43 --> 0x2A
        ptroutput[39] = (ptrinput[43]); // 44 --> 0x2B
        //////////////////////////
        // 45 to 48
        //////////////////////////
        ptroutput[35] = reverseBits(ptrinput[56]); // 45 --> 0x2C
        ptroutput[34] = reverseBits(ptrinput[57]); // 46 --> 0x2D
        ptroutput[33] = reverseBits(ptrinput[58]); // 47 --> 0x2E
        ptroutput[32] = reverseBits(ptrinput[59]); // 48 --> 0x2F
        //////////////////////////
        // 49 to 52
        //////////////////////////
        ptroutput[60] = (ptrinput[12]); // 49 --> 0x30
        ptroutput[61] = (ptrinput[13]); // 50 --> 0x31
        ptroutput[62] = (ptrinput[14]); // 51 --> 0x32
        ptroutput[63] = (ptrinput[15]); // 52 --> 0x33
        //////////////////////////
        // 53 to 56
        //////////////////////////
        ptroutput[59] = reverseBits(ptrinput[28]); // 53 --> 0x34
        ptroutput[58] = reverseBits(ptrinput[29]); // 54 --> 0x35
        ptroutput[57] = reverseBits(ptrinput[30]); // 55 --> 0x36
        ptroutput[56] = reverseBits(ptrinput[31]); // 56 --> 0x37
        //////////////////////////
        // 57 to 60
        //////////////////////////
        ptroutput[52] = (ptrinput[44]); // 57 --> 0x38
        ptroutput[53] = (ptrinput[45]); // 58 --> 0x39
        ptroutput[54] = (ptrinput[46]); // 59 --> 0x3A
        ptroutput[55] = (ptrinput[47]); // 60 --> 0x3B
        //////////////////////////
        // 61 to 64
        //////////////////////////
        ptroutput[51] = reverseBits(ptrinput[60]); // 61 --> 0x3C
        ptroutput[50] = reverseBits(ptrinput[61]); // 62 --> 0x3D
        ptroutput[49] = reverseBits(ptrinput[62]); // 63 --> 0x3E
        ptroutput[48] = reverseBits(ptrinput[63]); // 64 --> 0x3F
        //////////////////////////
    }
    for (i = 0; i < 64; i++)
    {
        op[i] = ptroutput[i];
    }
}

static uint8_t ptr1[256], ptr2[256], ptr3[64], ptr_temp[64];

void data4x4(uint8_t *inputbuffer_256, uint8_t *outputbuffer_256)
{
    int n = sizeof(ptr1), i, j;

    // Get the elements of the array into pointer ptr1
    for (i = 0; i < n; ++i)
    {
        ptr1[i] = inputbuffer_256[i];
    }

    for (i = 0; i < 64; ++i)
    {
        ptr3[i] = ptr1[i];
    }
    fourboard_groupmanupulation(ptr3, ptr_temp);
    for (i = 0; i < 64; i++)
    {
        ptr2[i] = ptr_temp[i];
    }
    for (i = 0; i < 64; i++)
    {
        ptr2[i] = ptr_temp[i];
    }

    j = 64;
    for (i = 0; i < 64; ++i)
    {
        ptr3[i] = ptr1[j];
        j = j + 1;
    }
    fourboard_groupmanupulation(ptr3, ptr_temp);
    j = 64;
    for (i = 0; i < 64; i++)
    {
        ptr2[j] = ptr_temp[i];
        j = j + 1;
    }
    j = 128;
    for (i = 0; i < 64; ++i)
    {
        ptr3[i] = ptr1[j];
        j = j + 1;
    }
    fourboard_groupmanupulation(ptr3, ptr_temp);
    j = 128;
    for (i = 0; i < 64; i++)
    {
        ptr2[j] = ptr_temp[i];
        j = j + 1;
    }
    j = 128;
    for (i = 0; i < 64; i++)
    {
        ptr2[j] = ptr_temp[i];
        j = j + 1;
    }
    j = 192;
    for (i = 0; i < 64; ++i)
    {
        ptr3[i] = ptr1[j];
        j = j + 1;
    }
    fourboard_groupmanupulation(ptr3, ptr_temp);
    j = 192;
    for (i = 0; i < 64; i++)
    {
        ptr2[j] = ptr_temp[i];
        j = j + 1;
    }
    for (i = 0; i < n; i++)
    {
        outputbuffer_256[i] = ptr2[i];
    }
}
#endif
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// @param inputbuffer
/// @param sizeofbuffer /
void printbuffer(uint8_t *inputbuffer, int sizeofbuffer)
{
    int i = 0, j = 0, k = 0, sizeofarray = 0;
    switch (sizeofbuffer)
    {
    case 140:
        sizeofarray = 18;
        break;
    case 128:
        sizeofarray = 16;
        break;
    case 96:
        sizeofarray = 16;
        break;
    default:
        sizeofarray = 16;
        break;
    }
    k = 0;
    for (i = 0; i <= 15; i++)
    {
        for (j = 0; j < sizeofarray; j++)
        {
            printf("0x%02X ", inputbuffer[k]);
            k++;
        }
        printf("\n");
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void printhorizontalbuffer(void)
{
    int i = 0, j = 0;
    printf("\n Horizantal Buffer is \n");
    for (i = 0; i <= 15; i++)
    {

        for (j = 0; j <= 23; j++)
        {
            printf("0x%02X ", horizBuffer[i][j]);
        }
        printf("\n");
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void updateHorizOutput()
{
    uint16_t horizBufferLen = ((vertBufferLen) / BITS_PER_BYTE);

    displayBufLen = 0;
    mtpl_memset(displayBuf, 0, sizeof(displayBuf));
    for (int i = 0; i < MAX_ROWS; i++)
    {
        if ((i * horizBufferLen) < sizeof(displayBuf))
        {
            mtpl_memcpy(&displayBuf[displayBufLen], &horizBuffer[i][0], horizBufferLen);
            displayBufLen += horizBufferLen;
        }
    }

    return;
}
void updateScroll()
{
    int scroll_compleated_temp_count = 0;
    // printf("\n displayInfo.modeIndex = %d",displayInfo.modeIndex);
    // previous_scrolling_state = 0;
    // printf("\n scrolling is compleat flag = %d\n",scrolling_is_compleated_flag);
    // printf("\n previous scrolling state = %d\n",previous_scrolling_state);
    for (uint8_t i = 0; i < displayInfo.modeIndex; i++)
    {
        // if (displayInfo.modeData[i].repeatCount && scrollDone(i))
        // printf("\n 123");
        // printf("\n value of scrolling_is_compleated_flag = %d",scrolling_is_compleated_flag);
        if ((scrolling_is_compleated_flag))
        {
            // printf("\n scrolling is compleat flag = %d\n",scrolling_is_compleated_flag);
            // printf("\n previous scrolling state = %d\n",previous_scrolling_state);
            if ((previous_scrolling_state == 0))
            {
                printf("\n Scroll Compleated");
                scroll_compleated_temp_count = 1;
                if(hvrprot_Test_Mode_Message_Flag)
                {
                    hvrprot_Test_Mode_Scroll_Completed_Flag = 1;
                }
                if (displayInfo.Top_Priority_Message_Status == 1)
                {
                    displayInfo.Top_Priority_Message_Status = 0;
                }
                 //printf("\ndecreasing repeatCount current value is %d",displayInfo.modeData[i].repeatCount);
            }
        }
        previous_scrolling_state = scrolling_is_compleated_flag;
        // printf("\ndisplayInfo.modeData[i].repeatCount = %d",displayInfo.modeData[i].repeatCount);
        // printf("\nscrollint is compleated_flag = %d",scrolling_is_compleated_flag);
        // printf("\nscroll_compleated_temp_count = %d",scroll_compleated_temp_count);
        if (displayInfo.modeData[i].repeatCount && scrolling_is_compleated_flag && scroll_compleated_temp_count)
        {
            // printf("\ndecreasing repeatCount current value is %d",displayInfo.modeData[i].repeatCount);
            if (displayInfo.modeData[i].repeatCount > 0)
                displayInfo.modeData[i].repeatCount--;
             //printf("\ndecreasinged repeatCount after decreasing value is %d",displayInfo.modeData[i].repeatCount);    
            if (displayInfo.modeData[i].repeatCount == 0)
            {
                displayInfo.modeData[i].enableScrolling = 0;
            }
            scroll_compleated_temp_count = 0;
        }
    }
    // previous_scrolling_state = 0;   
    //printf("\n previous scrolling state = %d\n",previous_scrolling_state); 
}
uint16_t working_width = 0;
int colOffset = 0;
uint8_t scrollmessage()
{
    uint8_t rc = 0;
    // uint16_t working_width = 0;
    uint8_t scrollBlock = MAX_SCROLL_BLOCKS;
    uint8_t scrollBlock_line2 = 0;
    // int colOffset = 0;
    int colOffset_line2 = 0;
    // printf("\n scrollmessage() function triggered\n");
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////// check for panel size //////////////////////////////////////////////////////////////////
    if (systemInfo.Board_Type == 1)
    {
        DISPLAY_WIDTH_IN_COLUMNS1dc = (35 * 4) + 4;
    }
    else if (systemInfo.Board_Type == 2)
    {
        DISPLAY_WIDTH_IN_COLUMNS1dc = (32 * 4);
    }
    else if (systemInfo.Board_Type == 3)
    {
        DISPLAY_WIDTH_IN_COLUMNS1dc = (32 * 3);
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    for (uint8_t i = 0; i < displayInfo.modeIndex; i++)
    {

        // printf("\n inside for loop displayInfo.modeIndex = %d", displayInfo.modeIndex);
        working_width = (DISPLAY_WIDTH_IN_COLUMNS1dc);
        switch (displayInfo.mode)
        {
        case 0:
            scrollBlock = MAX_SCROLL_BLOCKS;
            colOffset = 0;
            break;
        case 1: // Mode1: Route No followed by 16 rows of text
            working_width = (DISPLAY_WIDTH_IN_COLUMNS1dc - displayInfo.modeData[0].width);
            scrollBlock = MAX_SCROLL_BLOCKS;
            colOffset = displayInfo.modeData[0].width;
            break;
        case 2: // Mode2: Two lines 8 cols each
            if (displayInfo.modeData[i].repeatCount || (displayInfo.modeData[i].enableScrolling))
            {
                if (i == 0) // Top line
                    scrollBlock = TOP_SCROLL_BLOCK;
                else
                {
                    // Bottom line
                    if (TOP_SCROLL_BLOCK == scrollBlock)
                        scrollBlock = MAX_SCROLL_BLOCKS;
                    else
                        scrollBlock = BOTTOM_SCROLL_BLOCK;
                }
            }
            colOffset = 0;
            break;
        case 3:
            if (i)
            {
                working_width = (DISPLAY_WIDTH_IN_COLUMNS1dc - displayInfo.modeData[0].width);

                if (displayInfo.modeData[i].repeatCount || (displayInfo.modeData[i].enableScrolling))
                {
                    if (i == 1) // Top line
                        scrollBlock = TOP_SCROLL_BLOCK;
                    else
                    {
                        // Bottom line
                        if (TOP_SCROLL_BLOCK == scrollBlock)
                            scrollBlock = MAX_SCROLL_BLOCKS;
                        else
                            scrollBlock = BOTTOM_SCROLL_BLOCK;
                    }
                }
                colOffset = displayInfo.modeData[0].width;
#if 0
                    if (i == 1) // Top line
                    {
                        scrollBlock = TOP_SCROLL_BLOCK;
                        colOffset = displayInfo.modeData[0].width;
                        //printf("\nin mode 3 Top line Scrolling Execution\n");
                    }
                    else if (i == 2)// Bottom line
                    {
                        scrollBlock_line2 = BOTTOM_SCROLL_BLOCK;
                        colOffset_line2 = displayInfo.modeData[0].width;
                        //printf("\nin mode 3 Bottom line Scrolling Execution\n");
                    }
#endif
                // colOffset = displayInfo.modeData[0].width;
            }
            break;
        default:
            scrollBlock = MAX_SCROLL_BLOCKS;
            colOffset = 0;
            break;
        }

        // Scroll if repeat is set or number of columns of display area exceeds
        // display width
        ///////////////////////////////////////////////////////////////////////////////////////////
        // if(displayInfo.modeData[i].enableScrolling)
        // {
        //     displayInfo.modeData[i].enableScrolling =1;
        //     //printf("\n enabled scrolling in mode %d",i);
        // }
        // if(!displayInfo.modeData[i].enableScrolling)
        // {
        //     //printf("\n not enabled scrolling in mode %d",i);
        //     displayInfo.modeData[i].enableScrolling =0;
        // }
        ////////////////////////////////////////////////////////////////////////////////////////////
        // printf("\n displayInfo.modeData[%d].width is %d, displayInfo.modeData[i].repeatCount = %d ,working_width = %d",i,displayInfo.modeData[i].width, displayInfo.modeData[i].repeatCount, working_width);
        if (displayInfo.modeData[i].repeatCount || (displayInfo.modeData[i].enableScrolling))
        {
            rc++;
        }
        // printf("\n line 996 temp_Count_scrollmessage_function = %d and i = %d.",temp_Count_scrollmessage_function,i);
        // printf("\n displayInfo.modeIndex = %d",displayInfo.modeIndex);
    }

    if (rc)
    {
        scrollMessageBuf(scrollBlock, colOffset);
        if (scrollBlock_line2 == 1)
        {
            scrollMessageBuf(scrollBlock_line2, colOffset_line2);
            scrollBlock_line2 = 0;
            // scrollBlock_line2=1;
        }
    }

    return rc;
}
#ifdef ENABLE_PICO
bool LDR_Reading_Flag = false;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////// Sub routein for Toggling LDR_Reading_Flag //////////////////////////////////////////////////////////////////
bool toggle_LDR_Flag(struct repeating_timer *t)
{

    LDR_Reading_Flag = true;
    return true;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////// Sub routein for Toggling Debug Led RED //////////////////////////////////////////////////////////////////
bool toggle_led(struct repeating_timer *t)
{
    led_value = 1 - led_value;
    // led_value = ~led_value;
    gpio_put(DEBUG_LED, led_value);
    return true;
}
/*bool increment_work_hour_count(struct repeating_timer *t)
{
    work_hour_count ++;
    pid_dtc.work_hour = work_hour_count;
    printf("\n work_hour_count = %d",work_hour_count);
    //led_value = 1 - led_value;
    // led_value = ~led_value;
    //gpio_put(DEBUG_LED, led_value);
    return true;
}*/
void call_PWM_Functionality(void)
{
    gpio_init(PWM_PIN);
    gpio_set_dir(PWM_PIN, GPIO_OUT);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////// Sub routine for Checking arrival of New Message decision for scrolling etc //////////////////
bool Display_Property_Check(struct repeating_timer *t)
{
    call_LDR_Functionality();
    Re_Identify_The_Board_Type();
    // Power_On_Mode_Check();
    New_Message_Arrival_Check();
    Scroll_Decision_Call();
    Flashing_Decision_Call();

    // printf("dtimes(%d, %d) ms\n", (int)cTime, (int)eTime);
    // printf("procTime = %d ms\n", (int)(eTime - cTime));
    return true;
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
#endif
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef ORG_IMPL
bool display_flashing = 0;
bool toggle_flashing(struct repeating_timer *t)
{
    display_flashing = !display_flashing;

    return true;
}
#endif

#ifndef ENABLE_PICO
void displayMessage(uint8_t *pDisplayBuf, int maxDisplayCols)
{
    uint8_t *cptr;
    for (int ri = 0; ri < MAX_ROWS; ri++)
    {
        cptr = &pDisplayBuf[ri * maxDisplayCols];
        for (int ci = 0; ci < maxDisplayCols; ci++, cptr++)
        {
            uint8_t val = *cptr;
            for (uint8_t bc = 0; bc < BITS_PER_BYTE; bc++)
            {
                if (val & (1 << ((BITS_PER_BYTE - 1) - bc)))
                {
                    mvprintw(ri, ci * BITS_PER_BYTE + bc, "#");
                }
            }
        }
    }
    refresh(); /* Print it on to the real screen */
}

#endif
void process_display()
{
    // #ifdef ENABLE_PICO
    // int idx = 0, row_count = 0;
    // int i = 0, j=0;
    // int ldrs_value=0,tempresult1 = 0,AverageValueofResult = 0;
    // int result = 0;
    // int adc_on_value=170, adc_off_value=86,average_adc_on_value = 0, average_adc_off_value = 0, adc_on_value_final = 255, adc_off_value_final = 0;
    /*int PwmBrightValue = 55, PwmDimValue = 245, current_Dim_Value = 245;*/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////Feb 6 15:00 ///////////////////////////////////////////////////////////////////////////////////
    // int appendingdisplaybufferflag = 0;
    /*int scrolling_count = 0;//scroll_Test_message = 0;*/
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////// Feb 9 14:52  //////////////////////////////////////////////////////////////////////////
    // int Scroll_Direction = SCROLL_LEFT;
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////// Febuary 28 11:26 ////////////////////////////////////////////////////////////////////////
    /*int Display_Buffer_Empty_Flag =0; // for checking whether display buffer is empty or not*/
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////// March 4 16:15////////////////////////////////////////////////////////////////////////////
    // int New_Message_Received_Data_Structure_Updated = 0;
    //  18:35  ///////////////////////////////////////////////////////////////////////////////////////////
    // int First_Time_Flag = 0;
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    // uint slice_num;
    // uint8_t initTestMode = 0;
    // uint8_t adc_reading_count = 0;
#ifdef ORG_IMPL
    uint8_t count_flash = 0;
    struct repeating_timer timer_fl;
#endif
    // #endif
    // int colOffset = 0;
    // static uint8_t all_leds_on = 0;

#ifndef ENABLE_PICO
    initscr();
#endif

#ifdef ENABLE_PICO
    setpwm();
    struct repeating_timer timer;
    add_repeating_timer_ms(1020, toggle_led, NULL, &timer);
    struct repeating_timer timer_LDR_Toggle;
    add_repeating_timer_ms(1, toggle_LDR_Flag, NULL, &timer_LDR_Toggle);
    //struct repeating_timer timer_work_hour_incrementer;
    //add_repeating_timer_ms(10000, increment_work_hour_count, NULL, &timer_work_hour_incrementer);
    //struct repeating_timer timer_Display_Property_Check;
#ifdef ORG_IMPL
    add_repeating_timer_ms(500, toggle_flashing, NULL, &timer_fl); // timer for flashing messages.
    sleep_ms(100);
#endif
#ifdef ENABLE_PWM

    slice_num = pwm_gpio_to_slice_num(LED_DRIVER_BLANK_SIGNAL);
    pwm_set_chan_level(slice_num, PWM_CHAN_A, adc_on_value);
    // Set initial B output high for three cycles before dropping
    pwm_set_chan_level(slice_num, PWM_CHAN_B, adc_off_value);
#endif

    Row_RESET();
    Row_CLOCK_PULSE();
    Row_CLOCK_PULSE();
    Row_CLOCK_PULSE();
    Row_CLOCK_PULSE();
#endif
#ifdef ENABLE_PWM
    slice_num = pwm_gpio_to_slice_num(LED_DRIVER_BLANK_SIGNAL);
#endif

    for (int j_Count = 0; j_Count < 289; j_Count++)
    {
        Test_Sample_289[j_Count] = 0x00;
    }

    printf("Start process display\r\n");
    for (int i = 0; i < 289; i++)
    {
        testModeBuffer_289[i] = ~testModeBuffer_289[i];
        // testModeBuffer_289[i] = 0xFF; // Abhishek Requirement for All lights Switch ON
    }
    //////////////////////// check for panel size ///////////////////////////////////////////////////////
    Re_Identify_The_Board_Type();

    // Power_On_Mode_Check();

    /////////////////////////////////////////////////////////////////////////////////////////////////////
    // add_repeating_timer_ms(25, Display_Property_Check, NULL, &timer_Display_Property_Check);

    if (displayDataChanged)
    {
        memcpy(outputbuffer_289, scrollBuffer, sizeof(outputbuffer_289));
        displayDataChanged = 0;
    }
    static absolute_time_t scrollCheckTime;
    static absolute_time_t cTime;

    cTime = get_absolute_time();
    scrollCheckTime = make_timeout_time_ms(SCROLL_CHECK_TIME);

    while (1)
    {
#ifdef ENABLE_PICO
#ifdef ENABLE_WATCHDOG
        display_watchdog_update();
#endif

        call_LDR_Functionality();
        Re_Identify_The_Board_Type();
        Power_On_Mode_Check();
        call_Test_Mode_Functionality();
        New_Message_Arrival_Check();

        cTime = get_absolute_time();
        if (absolute_time_diff_us(scrollCheckTime, cTime) > 1)
        {
            Scroll_Decision_Call();
            scrollCheckTime = make_timeout_time_ms(SCROLL_CHECK_TIME);
        }
        Flashing_Decision_Call();

        Display_Driving_Loop();
#endif
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Identify_Is_Display_Empty(void) // returns 0 if displaybuffer is Empty or else returns 1
{
    int buffer_limit = 0, i = 0, j = 0, k = 0, arrayshiftvalue = 0, Total_Number_of_Bytes = 0, Top_Line_Scroll_Done = 0, Bottom_Line_Scroll_Done = 0, Number_of_Bytes_in_Line = 0;
    int Mode2_Second_Line_Scroll_Count = 0,Mode3_Scrolling_Count = 0;

    if (Board140X16)
    {
        buffer_limit = 288;
        Number_of_Bytes_in_Line = 18;
        Total_Number_of_Bytes = 288;
    }
    else if ((Board128X16) || (Board96X16))
    {
        buffer_limit = 256;
        Number_of_Bytes_in_Line = 16;
        Total_Number_of_Bytes = 256;
    }
    arrayshiftvalue = colOffset / 8;
    emptyflag = 0;
    /////// only for mode 0
    // printf("\n The current Mode is %d",displayInfo.mode);
    if (displayInfo.mode == 0)
    {
        for (i = 0; i < buffer_limit; i++)
        {
            if (displayBuf[i] != 0x00)
            {
                emptyflag = 1;
                scrolling_is_compleated_flag = 0;
                // printf("\nat j = %d ,break",j);
                break;
            }
            else if (displayBuf[i] == 0x00)
            {
                // printf("\n %d",j);
            }
        }
        // If all the LEDs signals are blank, we are done with one complete scroll
        // If repeat one is desired, stop scrolling
        if (!emptyflag)
        {
            // printf("\n checking rep1 Condition");
            /*if (displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling &&
                (displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount == 1))
            {
                displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling = 0;
                displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
            }*/
            scrolling_is_compleated_flag = 1;
        }
    }
    /////////// only for mode 1
    if (displayInfo.mode == 1)
    {
        for (i = 0; i < MAX_ROWS; i++)
        {
            // printf("\n");
            for (j = ((i * Number_of_Bytes_in_Line) + arrayshiftvalue); j <= (((i * Number_of_Bytes_in_Line) + (Number_of_Bytes_in_Line - 1))); j++)
            {
                // printf("arr[%d]\t",j);
                if (displayBuf[j] != 0x00)
                {
                    emptyflag = 1;
                    scrolling_is_compleated_flag = 0;
                    // printf("\nat j = %d ,break",j);
                    break;
                }
                else if (displayBuf[i] == 0x00)
                {
                    // printf("\n %d",j);
                }
                if (emptyflag)
                {
                    break;
                }
            }
        }
        if (!emptyflag)
        {
            // printf("\n checking rep1 Condition");
            /*if (displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling &&
                (displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount == 1))
            {
                displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling = 0;
                displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
            }*/
            scrolling_is_compleated_flag = 1;
        }
    }
    //////////////// only for mode 2
    if (displayInfo.mode == 2)
    {
        // printf("\n Entered in Mode 2 processing");
        //printf("\n Top_Line_Scrolling_Enabled = %d \n Second_Line_Scrolling_Enabled = %d",displayInfo.modeData[0].enableScrolling,displayInfo.modeData[1].enableScrolling);
        Top_Line_Scroll_Done = 0;
        Bottom_Line_Scroll_Done = 0;
        k = 0;
        if((displayInfo.modeData[0].enableScrolling)&&(displayInfo.modeData[1].enableScrolling))
        {
            for (i = 0; i < buffer_limit; i++)
            {
                if (displayBuf[i] != 0x00)
                {
                    emptyflag = 1;
                    scrolling_is_compleated_flag = 0;
                    // printf("\nat j = %d ,break",j);
                    break;
                }
                else if (displayBuf[i] == 0x00)
                {
                    // printf("\n %d",j);
                }
            }
            // If all the LEDs signals are blank, we are done with one complete scroll
            // If repeat one is desired, stop scrolling
            if (!emptyflag)
            {
                // printf("\n checking rep1 Condition");
                /*if (displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling &&
                    (displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount == 1))
                {
                    displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling = 0;
                    displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
                }*/

                //scrolling_is_compleated_flag = 1;
                Top_Line_Scroll_Done = 1;
                Bottom_Line_Scroll_Done = 1;
            }
        }
        else
        {
            for (i = 0; i < (MAX_ROWS / 2); i++)
            {
                // printf("\n");
                for (j = 0; j < Number_of_Bytes_in_Line; j++)
                {
                    if (displayBuf[k] != 0x00)
                    {
                        scrolling_is_compleated_flag = 0;
                        emptyflag = 1;
                        // printf("\nat j = %d ,break",j);
                        break;
                    }
                    else if (displayBuf[k] == 0x00)
                    {
                        // printf("\n %d",j);
                    }
                    // printf("arr[%d], ",k);
                    k++;
                }
                if (emptyflag)
                {
                    break;
                }
                else
                {
                    //printf("\n Scrolling Compleated in Top Line");
                    if(Top_Line_Scroll_Done == 0)
                    {
                    Top_Line_Scroll_Done = 1;
                    }
                    // if (displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling &&
                    //     (displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount == 1))
                    // {
                    //     displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling = 0;
                    //     displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
                    // }
                }
                // printf("\nin top line check");
            }
            emptyflag = 0;
            Bottom_Line_Scroll_Done = 0;
            // printf("\n First Top line Compleated\n\n");
            k = Total_Number_of_Bytes / 2;
            for (i = 0; i < (MAX_ROWS / 2); i++)
            {
                // printf("\n");
                for (j = 0; j < Number_of_Bytes_in_Line; j++)
                {
                    if (displayBuf[k] != 0x00)
                    {
                        emptyflag = 1;
                        Mode2_Second_Line_Scroll_Count = 0;
                        // printf("\nat j = %d ,break",j);
                        break;
                    }
                    else if (displayBuf[k] == 0x00)
                    {
                        // printf("\n %d",j);
                    }

                    // printf("arr[%d], ",k);
                    k++;
                }
                if (emptyflag)
                {
                    break;
                }
                else
                {
                    //printf("\n Scrolling Compleated in Bottom Line in Mode 2 Scroll Count = %d",Mode2_Second_Line_Scroll_Count);
                    Mode2_Second_Line_Scroll_Count ++;
                    if(Mode2_Second_Line_Scroll_Count>=6)
                    {
                        if(Bottom_Line_Scroll_Done == 0)
                        {
                        Bottom_Line_Scroll_Done = 1;
                        //printf("\n Mode 2 Second line Scroll compleated");
                        }
                    }
                    // if (displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling &&
                    //     (displayInfo.modeData[BOTTOM_SCROLL_BLOCK].repeatCount == 1))
                    // {
                    //     displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling = 0;
                    //     displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
                    // }
                }
                // printf("\nin bottom line check");
            }
        }
        // printf("\n\n");
        // printbuffer(displayBuf,sizeof(displayBuf));
        // printf("\n\n");
        // condition when Top Line and Bottom Line Scrolling Not Compleated
        if ((Top_Line_Scroll_Done == 0) && (Bottom_Line_Scroll_Done == 0))
        {
            emptyflag = 2;
            //printf("\n Top Line & Bottom Line Scrolling Not Compleated");
        }
        // condition when Top Line Scrolling Compleated and Bottom Line Scrolling Not Compleated
        else if ((Top_Line_Scroll_Done == 0) && (Bottom_Line_Scroll_Done == 1))
        {
            scrolling_is_compleated_flag = 1;
            emptyflag = 3;
            // printf("\n in Mode 2 Top Line Scrolling compleated Bottom Line Scrolling Not Compleated\nTop_Line_Scroll_Done_Status = %d\nSecond Line Scrolling_Done_Status = %d\n",Top_Line_Scroll_Done,Bottom_Line_Scroll_Done);
            //printf("\n mode 2 Second Line Scroll Compleated");
        }
        // condition when Top Line Scrolling Not Compleated and Bottom Line Scrolling Compleated
        else if ((Top_Line_Scroll_Done == 1) && (Bottom_Line_Scroll_Done == 0))
        {
            scrolling_is_compleated_flag = 1;
            emptyflag = 4;
            //printf("\nin Mode 2 Top Line Scrolling Compleated Bottom Line Static Scrolling Not Compleated\nTop_Line_Scroll_Done_Status = %d\nSecond Line Scrolling_Done_Status = %d\n",Top_Line_Scroll_Done,Bottom_Line_Scroll_Done);
        }
        // condition when Top Line Scrolling Compleated and Bottom Line Scrolling Compleated
        else if ((Top_Line_Scroll_Done == 1) && (Bottom_Line_Scroll_Done == 1))
        {
            scrolling_is_compleated_flag = 1;
            emptyflag = 5;
            //printf("\n In Mode 2 Top Line Scrolling Bottom Line Scrolling Compleated");
        }
        // printf("\n Second Bottom line Compleated\n\n");
    }
    if (displayInfo.mode == 3)
    {
        Top_Line_Scroll_Done = 0;
        k = 0;
        emptyflag = 0;
        scrolling_is_compleated_flag = 0;
        // printf("\n");
        // printbuffer(displayBuf,sizeof(displayBuf));
        // printf("\n");
        for (i = 0; i < (MAX_ROWS / 2); i++)
        {
            // printf("\n");
            for (j = ((i * Number_of_Bytes_in_Line) + arrayshiftvalue); j <= (((i * Number_of_Bytes_in_Line) + (Number_of_Bytes_in_Line - 1))); j++)
            {
                if (displayBuf[j] != 0x00)
                {
                    emptyflag = 1;
                    break;
                }
                else if (displayBuf[j] == 0x00)
                {
                    // printf("\n %d",j);
                }
                // printf("arr[%d], ",k);
                k++;
            }
            if (emptyflag)
            {
                break;
            }
            else
            {
                //printf("\n Scrolling Compleated in Top Line in mode 3 and count is %d",Mode3_Scrolling_Count);
                Mode3_Scrolling_Count ++;
                if(Mode3_Scrolling_Count>=6)
                {
                Top_Line_Scroll_Done = 1;
                }
                if (!emptyflag)
                {
                    // printf("\n checking rep1 Condition");
                    if (displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling &&
                        (displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount == 1))
                    {
                        displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling = 0;
                        displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
                    }
                }
            }
        }
        emptyflag = 0;
        Bottom_Line_Scroll_Done = 0;
        k = Total_Number_of_Bytes / 2;
        // printf("\n");
        // printbuffer(displayBuf,sizeof(displayBuf));
        // printf("\n");
        for (i = 0; i < (MAX_ROWS / 2); i++)
        {
            for (j = ((i * Number_of_Bytes_in_Line) + arrayshiftvalue); j <= (((i * Number_of_Bytes_in_Line) + (Number_of_Bytes_in_Line - 1))); j++)
            {
                if (displayBuf[j + k] != 0x00)
                {
                    emptyflag = 1;
                    // printf("\nat j = %d ,break",j);
                    break;
                }
                else if (displayBuf[j + k] == 0x00)
                {
                    // printf("\n %d",j);
                }
            }
            if (emptyflag)
            {
                break;
            }
            else
            {
                //printf("\n Scrolling Compleated in Bottom Line in Mode 3 count is %d",Mode3_Scrolling_Count);
                Mode3_Scrolling_Count ++;
                if(Mode3_Scrolling_Count>=6)
                {
                Bottom_Line_Scroll_Done = 1;
                }
                // if (!emptyflag)
                // {
                //     // printf("\n checking rep1 Condition");
                //     if (displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling &&
                //         (displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount == 1))
                //     {
                //         displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling = 0;
                //         displayInfo.modeData[TOP_SCROLL_BLOCK].repeatCount = 0;
                //     }
                // }
            }
        }
        // condition when Top Line and Bottom Line Scrolling Not Compleated
        if ((Top_Line_Scroll_Done == 0) && (Bottom_Line_Scroll_Done == 0))
        {
            emptyflag = 2;
            //printf("\n In Mode 3 Top Line Scrolling Bottom Line Scrolling Not Compleated");
        }
        // condition when Top Line Scrolling Not Compleated and Bottom Line Scrolling Compleated
        // Mode 3 Top Static Bottom Scrolling
        else if ((Top_Line_Scroll_Done == 0) && (Bottom_Line_Scroll_Done == 1))
        {
            emptyflag = 3;
            scrolling_is_compleated_flag = 1;
            // printf("\n In Mode 3 Top Line Scrolling Compleated Bottom Line Scrolling Not Compleated");
        }
        // condition when Top Line Scrolling Compleated and Bottom Line Scrolling Not Compleated
        // Mode 3 Top Scrolling Bottom Static
        else if ((Top_Line_Scroll_Done == 1) && (Bottom_Line_Scroll_Done == 0))
        {
            emptyflag = 4;
            scrolling_is_compleated_flag = 1;
            //printf("\n In Mode 3 Top Line Scrolling Not Compleated Bottom Line Scrolling Compleated");
        }
        // condition when Top Line Scrolling Compleated and Bottom Line Scrolling Compleated
        else if ((Top_Line_Scroll_Done == 1) && (Bottom_Line_Scroll_Done == 1))
        {
            //scrolling_is_compleated_flag = 1;
            emptyflag = 5;
            scrolling_is_compleated_flag = 1;
            //printf("\n In Mode 3 Top Line Scrolling Bottom Line Scrolling Compleated");
        }
        // printf("\n Second Bottom line Compleated\n\n");
    }
    // if(!emptyflag)
    // {
    //     printf("\n Scroll Compleated in Mode %d",displayInfo.mode);
    // }
    return emptyflag;
}
//////////////////////////// Call Test Mode Functionality /////////////////////////////////////////////////////////////////////////////
uint8_t initTestMode = 0;    // variable for TestMode initialization for the first time
int scroll_Test_message = 0; // variable for TestMode scroll_Test_message
uint8_t call_Test_Mode_Functionality(void)
{
    // uint8_t initTestMode = 0;
    // int scroll_Test_message = 0;
    int j = 0;
    int scrolling_count = 0, appendingdisplaybufferflag = 0;

    // while (systemInfo.testMode)
    if (systemInfo.testMode)
    {
        loop_iteration_count_Test_Mode = loop_iteration_count_Test_Mode + 1;
        messageInfo.mode = 0;      // select Mode 0 Single Line No Route Nothing
        messageInfo.modeIndex = 0; // for Mode 0 Mode Index will always be zer0
        // printf("\nIn test mode functionality");
        //  Enters into this condition only for once at the beginnig
        if (!initTestMode && (loop_started == 0))
        {
            // printf("\n 2.   The control is in Test Mode");
            printf("\nEntered In Test Mode");

            if (Board140X16)
            {
                printf("\n Identified board type is 140X16");
            }
            else if (Board128X16)
            {
                printf("\n Identified board type is 128X16");
            }
            else if (Board96X16)
            {
                printf("\n Identified board type is 96X16");
            }
            initTestMode = 1;

            if (Board140X16)
            {
                if (loop_started == 0)
                {
                    mtpl_memcpy(displayBuf, testModeBuffer_289, sizeof(testModeBuffer_289));
                    displayBufLen = sizeof(testModeBuffer_289);
                    printf("\n loop_started is 0");
                    // all_leds_on = 1;
                }
                else if (loop_started == 1)
                {
                    printf("\n loop_started became 1");
                }
                displayBufLen = sizeof(Test_Sample_289);
            }
            else if (Board96X16 || Board128X16)
            {
                // all_leds_on = 1;
                mtpl_memcpy(displayBuf, testModeBuffer_256, sizeof(testModeBuffer_256));
                displayBufLen = sizeof(testModeBuffer_256);
            }

            topBufferLen = displayBufLen / 2;
            bottomBufferLen = displayBufLen / 2;
            colOffset = 0;
            scrollMessageBufInit(displayBuf, topBufferLen, bottomBufferLen,
                                 MAX_ROWS, SCROLL_LEFT, DISPLAY_WIDTH_IN_COLUMNS1dc, colOffset);
        }
        else
        {
            if (Board140X16)
            {
                colOffset = 0;
                printf("\n In Test Mode For 140X16");
                if ((loop_started == 0) && (loop_iteration_count_Test_Mode < 143))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 0");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 300) && (emptyflag != 0) && (loop_iteration_count_Test_Mode < 447))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 1");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 600) && (loop_iteration_count_Test_Mode < 744) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 2");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 900) && (loop_iteration_count_Test_Mode < 1047) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 3");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 1206) && (loop_iteration_count_Test_Mode < 1350) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 4");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 1755) && (loop_iteration_count_Test_Mode < 1902) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 5");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 2560) && (loop_iteration_count_Test_Mode < 2716) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 6");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 2760)) //&&(loop_iteration_count_Test_Mode < 2706)&&(emptyflag!=0))
                {
                    // scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 7");
                    sleep_us(10000);
                }
                // if (Board128X16 || Board96X16)
                {
                    copyScrolledBuffer(displayBuf);
                }
            }
            if (Board128X16 || Board96X16)
            {
                colOffset = 0;
                // printf("\n IN Test Mode_For 128X16|96X16");
                // printf("\n loop_iteration_count_Test_Mode = %d\n",loop_iteration_count_Test_Mode);
                if ((loop_started == 0) && (loop_iteration_count_Test_Mode < 129))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 0");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 300) && (emptyflag != 0) && (loop_iteration_count_Test_Mode < 429))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 1");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 600) && (loop_iteration_count_Test_Mode < 729) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 2");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 900) && (loop_iteration_count_Test_Mode < 1029) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 3");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 1200) && (loop_iteration_count_Test_Mode < 1329) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 4");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 1700) && (loop_iteration_count_Test_Mode < 1829) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 5");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 2500) && (loop_iteration_count_Test_Mode < 2629) && (emptyflag != 0))
                {
                    scrollMessageBuf(MAX_SCROLL_BLOCKS, colOffset);
                    printf(" 6");
                    sleep_us(1000);
                }
                if ((loop_iteration_count_Test_Mode > 2760)) //&&(loop_iteration_count_Test_Mode < 2706)&&(emptyflag!=0))
                {
                    printf(" 7");
                    sleep_us(1000);
                }
                if (Board128X16 || Board96X16)
                {
                    copyScrolledBuffer(displayBuf);
                }
            }
#ifdef ENABLE_PICO
            if (Board128X16 || Board96X16)
            {
                data4x4(displayBuf, outputbuffer_256);
                emptyflag = 0;
                for (j = 0; j < 256; j++)
                {
                    if (displayBuf[j] != 0x00)
                    {
                        emptyflag = 1;
                        break;
                    }
                    else if (displayBuf[j] == 0x00)
                    {
                        // printf("\n %d",j);
                    }
                }
                if (emptyflag == 0)
                {
                    loop_started = 1;
                    if ((scroll_Test_message == 1))
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        for (int count_i = 0; count_i < 256; count_i++)
                        {
                            displayBuf[count_i] = 0xAA;
                        }
                    }
                    if ((scroll_Test_message == 2))
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        for (int count_i = 0; count_i < 256; count_i++)
                        {
                            displayBuf[count_i] = 0x55;
                        }
                    }
                    if ((scroll_Test_message == 3))
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        for (int count_i = 0; count_i < 64; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 128; count_i < 192; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                    }
                    if ((scroll_Test_message == 4))
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        for (int count_i = 64; count_i < 128; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 192; count_i < 257; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                    }
                    if (scroll_Test_message == 5)
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        for (int count_i = 0; count_i < 16; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                            messageInfo.modeData->enableScrolling = 1;
                        }
                        for (int count_i = 32; count_i < 48; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 64; count_i < 80; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 96; count_i < 112; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 128; count_i < 144; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 160; count_i < 176; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 192; count_i < 208; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 224; count_i < 240; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                    }
                    if (scroll_Test_message == 6)
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        for (int count_i = 16; count_i < 32; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                            messageInfo.modeData->enableScrolling = 1;
                        }
                        for (int count_i = 48; count_i < 64; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 80; count_i < 96; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 112; count_i < 128; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 144; count_i < 160; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 176; count_i < 192; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 208; count_i < 224; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                        for (int count_i = 240; count_i < 256; count_i++)
                        {
                            displayBuf[count_i] = 0xFF;
                        }
                    }
                    if (scroll_Test_message == 7)
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        loop_iteration_count_Test_Mode = 0;
                        initTestMode = 0;
                        scroll_Test_message = 0;
                    }
                    topBufferLen = bottomBufferLen = displayBufLen / 2;
                    scrollMessageBufInit(displayBuf, topBufferLen, bottomBufferLen,
                                         MAX_ROWS, SCROLL_LEFT, DISPLAY_WIDTH_IN_COLUMNS1dc, colOffset);
                    scroll_Test_message++;
                    printf("\n Data Updated");
                }
            }
            else if (Board140X16)
            {
                // memset(outputbuffer_289, 0, sizeof(outputbuffer_289));
                shuffel16RX35C(displayBuf, outputbuffer_289);
                emptyflag = 0;
                for (j = 0; j < 288; j++)
                {
                    if (displayBuf[j] != 0x00)
                    {
                        emptyflag = 1;
                        // printf("\nat j = %d ,break",j);
                        break;
                    }
                    else if (displayBuf[j] == 0x00)
                    {
                        // printf("\n %d",j);
                    }
                }
                if (emptyflag == 0)
                {
                    scrolling_count = 0;
                    if (appendingdisplaybufferflag == 0)
                    {
                        memset(displayBuf, 0, sizeof(displayBuf));
                        if ((scroll_Test_message == 1))
                        {
                            memset(displayBuf, 0, sizeof(displayBuf));
                            for (int count_i = 0; count_i < 289; count_i++)
                            {
                                displayBuf[count_i] = 0xAA;
                            }
                        }
                        if ((scroll_Test_message == 2))
                        {
                            memset(displayBuf, 0, sizeof(displayBuf));
                            for (int count_i = 0; count_i < 289; count_i++)
                            {
                                displayBuf[count_i] = 0xAA;
                            }
                        }
                        if ((scroll_Test_message == 3))
                        {
                            memset(displayBuf, 0, sizeof(displayBuf));
                            for (int count_i = 0; count_i < 72; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 144; count_i < 216; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            /*for (int count_i = 162; count_i < 180; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 180; count_i < 198; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 198; count_i < 216; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 216; count_i < 289; count_i++)
                            {
                                displayBuf[count_i] = 0xAA;
                            }*/
                        }
                        if (scroll_Test_message == 4)
                        {
                            memset(displayBuf, 0, sizeof(displayBuf));
                            for (int count_i = 72; count_i < 144; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                                messageInfo.modeData->enableScrolling = 1;
                            }
                            for (int count_i = 216; count_i < 289; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                        }
                        if (scroll_Test_message == 5)
                        {
                            memset(displayBuf, 0, sizeof(displayBuf));
                            for (int count_i = 0; count_i < 18; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                                messageInfo.modeData->enableScrolling = 1;
                            }
                            for (int count_i = 36; count_i < 54; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 72; count_i < 90; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 108; count_i < 126; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 144; count_i < 162; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 180; count_i < 198; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 216; count_i < 234; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 252; count_i < 270; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                        }
                        if (scroll_Test_message == 6)
                        {
                            memset(displayBuf, 0, sizeof(displayBuf));
                            for (int count_i = 18; count_i < 36; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                                messageInfo.modeData->enableScrolling = 1;
                            }
                            for (int count_i = 54; count_i < 72; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 90; count_i < 108; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 126; count_i < 144; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 162; count_i < 180; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 198; count_i < 216; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 234; count_i < 252; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                            for (int count_i = 270; count_i < 289; count_i++)
                            {
                                displayBuf[count_i] = 0xFF;
                            }
                        }
                        if (scroll_Test_message == 7)
                        {
                            loop_iteration_count_Test_Mode = 0;
                            memset(displayBuf, 0, sizeof(displayBuf));
                            initTestMode = 0; // comment this if you want MASSTRANS to print on the Display only Once.
                            scroll_Test_message = 0;
                            loop_started = 1;
                        }
                        topBufferLen = bottomBufferLen = displayBufLen / 2;
                        scrollMessageBufInit(displayBuf, topBufferLen, bottomBufferLen,
                                             MAX_ROWS, SCROLL_LEFT, DISPLAY_WIDTH_IN_COLUMNS1dc, colOffset);
                        scroll_Test_message++;
                    }
                }
            }
#endif
        }
        scrolling_count++;
    }

    return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void call_LDR_Functionality(void)
{
    //printf("\n in LDR Subroutine");
    static int ldrs_value = 0, tempresult1 = 0, AverageValueofResult = 0;
    static uint8_t adc_reading_count = 0;
    int brightness_in_percentage = 0;
    char percentage = '%';

    if (!displayInfo.modeData->flashPeriod)
    {
        if (LDR_Reading_Flag == true)
        {
            ldrs_value = getLdrValue();
            tempresult1 = ldrs_value;
            // sleep_us(1);
            AverageValueofResult = AverageValueofResult + tempresult1;
            if (adc_reading_count >= 80)
            {
                AverageValueofResult = AverageValueofResult / 80;
                result = AverageValueofResult;
                AverageValueofResult = 0;
                adc_reading_count = 0;
                static int old_result = 0;

                if (old_result != result)
                {
                    // printf("on time %d, off time %d", PwmBrightValue, PwmDimValue);
                    old_result = result;
                }

                //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                //if(systemInfo.Board_Type == 1 || systemInfo.Board_Type == 2)
                {
                    PwmBrightValue = map(result, 150, 3500, 10, 400);
                    //set Lower Limit assure that the LED Intensity Value doese not fall bellow XX% 33% of total cycle
                    if (PwmBrightValue < 115)
                        PwmBrightValue = 115;
                    PwmDimValue = 400 - PwmBrightValue;
                    if (current_Dim_Value < PwmDimValue)
                    {
                        current_Dim_Value = current_Dim_Value + 2;
                    }
                    else if (current_Dim_Value > PwmDimValue)
                    {
                        current_Dim_Value = current_Dim_Value - 2;
                    }
                    else if (current_Dim_Value == PwmDimValue)
                    {
                        current_Dim_Value = current_Dim_Value;
                    }
                    //printf("\ncurrent_Dim_value = %d, pwmDimvalue = %d, pwmbrightvlaue = %d",current_Dim_Value,PwmDimValue,PwmBrightValue);
                    // set Upper Limit assure that the LED Intensity Value doese not exceed above XX% 33% of total cycle
                    // decreasing current_Dim_Value increased the upper limit of LED Maximum Intensity
                    if (current_Dim_Value < 35)
                    { 
                        current_Dim_Value = 35;
                    }
                    brightness_in_percentage = ((PwmBrightValue*100)/400);
                    //printf("\n Brightness in percentage is %d%c\nPWMBrightValue = %d\nPWMDimValue = %d\n current_Dim_Value = %d",brightness_in_percentage,percentage,PwmBrightValue,PwmDimValue,current_Dim_Value);
                }
                /*else if( systemInfo.Board_Type == 3)
                {
                    PwmBrightValue = map(result, 150, 3500, 10, 400);
                    //set Lower Limit assure that the LED Intensity Value doese not fall bellow XX% 33% of total cycle
                    if (PwmBrightValue < 115)
                        PwmBrightValue = 115;
                    PwmDimValue = 400 - PwmBrightValue;
                    if (current_Dim_Value < PwmDimValue)
                    {
                        current_Dim_Value = current_Dim_Value + 2;
                    }
                    else if (current_Dim_Value > PwmDimValue)
                    {
                        current_Dim_Value = current_Dim_Value - 2;
                    }
                    else if (current_Dim_Value == PwmDimValue)
                    {
                        current_Dim_Value = current_Dim_Value;
                    }
                    //printf("\ncurrent_Dim_value = %d, pwmDimvalue = %d, pwmbrightvlaue = %d",current_Dim_Value,PwmDimValue,PwmBrightValue);
                    // set Upper Limit assure that the LED Intensity Value doese not exceed above XX% 33% of total cycle
                    // decreasing current_Dim_Value increased the upper limit of LED Maximum Intensity
                    if (current_Dim_Value < 35)
                    { 
                        current_Dim_Value = 35;
                    }
                    brightness_in_percentage = ((PwmBrightValue*100)/400);
                    printf("\n Brightness in percentage is %d%c\nPWMBrightValue = %d\nPWMDimValue = %d\n current_Dim_Value = %d",brightness_in_percentage,percentage,PwmBrightValue,PwmDimValue,current_Dim_Value);
                }*/
                //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // if (systemInfo.Board_Type == 1)
                // {
                //     PwmBrightValue = map(result, 150, 3500, 60, 300);
                //     if (PwmBrightValue < 20)
                //         PwmBrightValue = 20;
                //     else if (PwmBrightValue > 300)
                //         PwmBrightValue = 300;

                //     PwmDimValue = 400 - PwmBrightValue;
                //     if (current_Dim_Value < PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value + 2;
                //     }
                //     else if (current_Dim_Value > PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value - 2;
                //     }
                //     else if (current_Dim_Value == PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value;
                //     }
                //     if (current_Dim_Value > 350)
                //         current_Dim_Value = 350;

                // }
                // else if (systemInfo.Board_Type == 2 /*|| systemInfo.Board_Type == 3*/)
                // {
                //     PwmBrightValue = map(result, 150, 3500, 10, 400);
                //     //set Lower Limit assure that the LED Intensity Value doese not fall bellow 33% of total cycle
                //     if(PwmBrightValue < 40)
                //     {
                //         PwmBrightValue = 40;                    
                //     }
                //     PwmDimValue = 400 - PwmBrightValue;
                //     if (current_Dim_Value < PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value + 2;
                //     }
                //     else if (current_Dim_Value > PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value - 2;
                //     }
                //     else if (current_Dim_Value == PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value;
                //     }
                //         //printf("\ncurrent_Dim_value = %d, pwmDimvalue = %d, pwmbrightvlaue = %d",current_Dim_Value,PwmDimValue,PwmBrightValue);
                //     // set Upper Limit assure that the LED Intensity Value doese not exceed above 33% of total cycle
                //     // decreasing current_Dim_Value increased the upper limit of LED Maximum Intensity
                //     if (current_Dim_Value < 35)
                //     {
                //         current_Dim_Value = 35;
                //     }
                //         brightness_in_percentage = ((PwmBrightValue*100)/400);
                //         //printf("\n Brightness in percentage is %d%c\nPWMBrightValue = %d\nPWMDimValue = %d\n current_Dim_Value = %d",brightness_in_percentage,percentage,PwmBrightValue,PwmDimValue,current_Dim_Value);
                // }
                // else if (/*systemInfo.Board_Type == 2 ||*/ systemInfo.Board_Type == 3)
                // {
                //     PwmBrightValue = map(result, 150, 3500, 60, 350);
                //     //set Lower Limit assure that the LED Intensity Value doese not fall bellow 33% of total cycle
                //     if(PwmBrightValue<115)
                //     {
                //         PwmBrightValue = 115;                    
                //     }
                //     PwmDimValue = 400 - PwmBrightValue;
                //     if (current_Dim_Value < PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value + 2;
                //     }
                //     else if (current_Dim_Value > PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value - 2;
                //     }
                //     else if (current_Dim_Value == PwmDimValue)
                //     {
                //         current_Dim_Value = current_Dim_Value;
                //     }
                //     //  printf("\ncurrent_Dim_value = %d, pwmDimvalue = %d, pwmbrightvlaue = %d",current_Dim_Value,PwmDimValue,PwmBrightValue);
                //     if (current_Dim_Value > 350)
                //     {
                //         current_Dim_Value = 350;
                //     }
                //         brightness_in_percentage = ((PwmBrightValue*100)/400);
                //         //printf("\n Brightness in percentage is %d%c\nPWMBrightValue = %d\nPWMDimValue = %d\n current_Dim_Value = %d",brightness_in_percentage,percentage,PwmBrightValue,PwmDimValue,current_Dim_Value);
                // }
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                
            }
            ///////////////////////////////////////////////////////////////////////////////////////////
            adc_reading_count = adc_reading_count + 1;
            LDR_Reading_Flag = false;
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Power_On_Mode_Check(void)
{
    //printf("\n in power on check subroutine");
    if ((systemInfo.testMode == 0) && (!displayInfo.mode) && (!Powerflag))
    {
        // printf("\r\n Firmware Version is %s format", FIRMWARE_VERSION);
        printf("\r\n ===== Waiting for data ======\r\n");
        while (!pUart->state && !Powerflag)
        {
#ifdef ENABLE_WATCHDOG
            display_watchdog_update();
#endif
            poweronindication_2();
        }
        Powerflag = 1;
        poweronindication_2();
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void New_Message_Arrival_Check(void)
{
    //printf("\nin New_Message_Arrival_Check subroutine");
    if (messageInfo.messageChanged && !systemInfo.testMode)
    {
        // printf("\ncontrol came inside message changed condition and Top Priority Message status in messageinfo.data structure is %d",messageInfo.Top_Priority_Message_Status);
        // printf("\ncontrol came inside message changed condition and Top Priority Message Status in displayinfo.data structure is = %d\n", displayInfo.Top_Priority_Message_Status);
        if ((messageInfo.Top_Priority_Message_Status == 1) || (!First_Time_Flag))
        {
            New_Message_Received_Data_Structure_Updated = 1;
            // printf("\n Top Priority Message recieved\n");
            // printf("Inside Top Priority Message section\n");
            First_Time_Flag = 1;
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (((displayInfo.mode == 0 || displayInfo.mode == 1 || (!First_Time_Flag))) && (messageInfo.Top_Priority_Message_Status == 0))
        {
            // printf("\n Inside mode 0 mode 1 section  and waiting for scroll completion \n");
            if (displayInfo.modeData[0].enableScrolling || displayInfo.modeData[1].enableScrolling)
            {
                if (scrolling_is_compleated_flag || (!First_Time_Flag))
                {
                    scrolling_is_compleated_flag = 0;
                    New_Message_Received_Data_Structure_Updated = 1;
                    First_Time_Flag = 1;
                }
            }
            else
            {
                New_Message_Received_Data_Structure_Updated = 1;
                First_Time_Flag = 1;
            }
        }
        else if (((displayInfo.mode == 2 || displayInfo.mode == 3)) && (messageInfo.Top_Priority_Message_Status == 0))
        {
            // printf("\n Inside Mode 2 and Mode 3 Section");
            //printf("\n scrolling_is_compleated_flag = %d", scrolling_is_compleated_flag);
           // printf("\n scrolling status in mode 2 is displayInfo.modeData[0].enableScrolling = %d", displayInfo.modeData[0].enableScrolling);
            //printf("\n scrolling status in mode 2 is displayInfo.modeData[1].enableScrolling = %d", displayInfo.modeData[1].enableScrolling);
            //printf("\n displayIn");
            if(displayInfo.mode == 2)
            {
                if (scrolling_is_compleated_flag || ((displayInfo.modeData[TOP_SCROLL_BLOCK].enableScrolling == 0) && (displayInfo.modeData[BOTTOM_SCROLL_BLOCK].enableScrolling == 0)))
                {
                    scrolling_is_compleated_flag = 0;
                    printf("\n inside mode 2 section\n");
                    New_Message_Received_Data_Structure_Updated = 1;
                }
            }
            if(displayInfo.mode == 3)
            {
                if (scrolling_is_compleated_flag || ((displayInfo.modeData[TOP_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 0) && (displayInfo.modeData[BOTTOM_SCROLL_BLOCK_FOR_MODE_3].enableScrolling == 0)))
                {
                    scrolling_is_compleated_flag = 0;
                    printf("\n inside mode 3 section\n");
                    New_Message_Received_Data_Structure_Updated = 1;
                }
            }
        }
        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        // This code is for message updating
        if (New_Message_Received_Data_Structure_Updated)
        {
            // Copy relevant fields from messageInfo to displayInfo to prevent
            // simultaneous access of common data structure
            // printf("New Message Received and Data Structure Updated\n");
            // printf("Bright value %d, Dim value %d & Current Dim = %d\n", PwmBrightValue, PwmDimValue, current_Dim_Value);
            copyDisplayInfo();
            updateHorizOutput();
            colOffset = 0;
            switch (displayInfo.mode)
            {
            case 0: // Single line
                break;
            case 1: // Route No and 16 row text
                colOffset = displayInfo.modeData[0].width;
                break;
            case 2: // 2 lines of 8 rows each
                break;
            case 3: // Route No and 2 lines of 8 rows
                colOffset = displayInfo.modeData[0].width;
            default:
                break;
            }
            /////////////////////////////////////////////////////////////////////////////////////////////////////////
            if ((displayInfo.modeData[displayInfo.modeIndex - 1].shiftRight == 1) && (displayInfo.modeData[displayInfo.modeIndex - 1].shiftLeft == 0))
            {
                Scroll_Direction = SCROLL_RIGHT;
                scrollMessageBufInit(displayBuf, topBufferLen,
                                     bottomBufferLen, MAX_ROWS, Scroll_Direction, DISPLAY_WIDTH_IN_COLUMNS1dc, colOffset);
                printf("\n Scroll Right Received");
            }
            else // if((displayInfo.modeData[displayInfo.modeIndex-1].shiftRight == 0)&&(displayInfo.modeData[displayInfo.modeIndex-1].shiftLeft == 1))
            {
                Scroll_Direction = SCROLL_LEFT;
                // Scroll_Direction = SCROLL_RIGHT;
                scrollMessageBufInit(displayBuf, topBufferLen,
                                     bottomBufferLen, MAX_ROWS, Scroll_Direction, DISPLAY_WIDTH_IN_COLUMNS1dc, colOffset);
                // printf("\n Scroll Left Received");
            }
            // printf("\n displayInfo.modeData[%d].shiftLeft == %d",displayInfo.modeIndex-1,displayInfo.modeData[displayInfo.modeIndex-1].shiftLeft);
            ////////////////////////////////////////////////////////////////////////////////////////////////////////
            messageInfo.messageChanged = 0;
            mtpl_memset(&messageInfo, 0, sizeof(messageInfo));
            displayc_Scroll_Count = 0;
            New_Message_Received_Data_Structure_Updated = 0;
            if (displayState == DISPLAY_STATE_OFF)
            {
                displayState = DISPLAY_STATE_ON;
            }
            // displayInfo.Top_Priority_Message_Status = 0;
            if (Board128X16 || Board96X16)
            {
                copyScrolledBuffer(displayBuf);
            }
            else if (Board140X16)
            {
                copyScrolledBuffer(displayBuf);
            }
            // #ifndef ENABLE_35X16
            if (Board128X16 || Board96X16)
            {
                data4x4(displayBuf, outputbuffer_256);
            }
            else if (Board140X16)
            {
                shuffel16RX35C(displayBuf, scrollBuffer);
                displayDataChanged = 1;
            }
            printf("\ndata copied in scroll buffer\n");
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Scroll_Decision_Call(void)
{
    if (displayBufLen && topBufferLen && bottomBufferLen)
    {
#ifdef ENABLE_LOOP_DEBUG
        if (!dispRun2)
        {
            printf("Disp run2 %d\r\n", dispRun2);
        }
        if (dispRun2++ > 100)
            dispRun2 = 0;
#endif

        if (scrollmessage())
        {
#ifdef ENABLE_PICO
            // This Condition is True when scrolling is enabled
            if (Board128X16 || Board96X16)
            {
                copyScrolledBuffer(displayBuf);
            }
            if (Board140X16)
            {
                copyScrolledBuffer(displayBuf);
                // printbuffer(displayBuf,140);
            }
            // #ifndef ENABLE_35X16
            if (Board128X16 || Board96X16)
            {
                data4x4(displayBuf, outputbuffer_256);
                Display_Buffer_Empty_Flag = Identify_Is_Display_Empty();
            }
            else if (Board140X16)
            {
                shuffel16RX35C(displayBuf, scrollBuffer);
                Display_Buffer_Empty_Flag = Identify_Is_Display_Empty();
                // if(First_Count==false)
                // {
                //     sleep_ms(10000);
                // }
                displayDataChanged = 1;
            }
#else
            copyScrolledBuffer(displayBuf);
#endif

            updateScroll();
            scrolling_count++;
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            /*if ((scrolling_count >) && (First_Count))
            {
                printbuffer(displayBuf, 140);
                // copyDisplayInfo();
                copyScrolledBuffer(displayBuf);
                updateScroll();
                updateHorizOutput();
                printhorizontalbuffer();

                Scroll_Direction = SCROLL_LEFT;
                scrollMessageBufInit(displayBuf, topBufferLen,
                                     bottomBufferLen, MAX_ROWS, Scroll_Direction, DISPLAY_WIDTH_IN_COLUMNS1dc, colOffset);
                printf("\n Display_Width_in_columns1dc = %d", DISPLAY_WIDTH_IN_COLUMNS1dc);
                printf("\n coloffset = %d", colOffset);

                // copyScrolledBuffer(displayBuf);
                // shuffel16RX35C(displayBuf, scrollBuffer);
                printf("\n scrolling direction change triggered");
                First_Count = false;
            }*/
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        }
#ifdef ENABLE_PICO
        else
        {
#if 0                
                if(Board128X16||Board96X16)
                {
                    copyScrolledBuffer(displayBuf);
                }
                else if(Board140X16)
                {
                    copyScrolledBuffer(displayBuf);
                }
                //#ifndef ENABLE_35X16
                if(Board128X16||Board96X16)
                {
                    data4x4(displayBuf, outputbuffer_256);
                }
                else if(Board140X16)
                {
                    shuffel16RX35C(displayBuf, outputbuffer_289);
                }
#endif
        }
        // printf("\n Display_Buffer_Empty_Flag = %d",Display_Buffer_Empty_Flag);
        if ((Display_Buffer_Empty_Flag == 0))
        {
            // printf("\n Scrolling Compleated in Mode %d",displayInfo.mode);
            scrolling_is_compleated_flag = 1;
            Display_Buffer_Empty_Flag = 1;
            scrolling_count = 0;
        }

        else if ((displayInfo.mode == 2) && (Display_Buffer_Empty_Flag))
        {
            if (Display_Buffer_Empty_Flag == 2)
            {
                ;
            }
            if (Display_Buffer_Empty_Flag == 3)
            {
                // printf("\n Bottom Line Scrolling Compleated in Mode 2");
            }
            if (Display_Buffer_Empty_Flag == 4)
            {
                // printf("\n TOP Line Scrolling Compleated in Mode 2");;
            }
            if (Display_Buffer_Empty_Flag == 5)
            {
                // printf("\n Top Line and Bottom Line Scrolling Compleated in Mode 2");;
            }
        }
        else if ((displayInfo.mode == 3) && (Display_Buffer_Empty_Flag))
        {
            if (Display_Buffer_Empty_Flag == 2)
            {
                ;
            }
            if (Display_Buffer_Empty_Flag == 3)
            {
                // printf("\n Bottom Line Scrolling Compleated in Mode 3");
                ;
            }
            if (Display_Buffer_Empty_Flag == 4)
            {
                // printf("\n TOP Line Scrolling Compleated in Mode 3");
                ;
            }
            if (Display_Buffer_Empty_Flag == 5)
            {
                // printf("\n Top Line and Bottom Line Scrolling Compleated in Mode 3");
                ;
            }
        }
#endif
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Flashing_Decision_Call(void)
{
    //printf("\n in Flashing_Decision_Call subroutine");
    if (displayBufLen && topBufferLen && bottomBufferLen)
    {
        // static absolute_time_t onTimeEnd;
        // static absolute_time_t offTimeEnd;
        // static absolute_time_t currTime;
#ifdef ENABLE_WATCHDOG
        display_watchdog_update();
#endif

        if (displayInfo.modeData->flashPeriod)
        {
            currTime = get_absolute_time();
            if (!displayInfo.flashStartTime)
            {
                displayInfo.flashStartTime = 1;
#ifdef ENABLE_FLASH_PRINT
                printf("Flash period %d secs\r\n", displayInfo.modeData->flashPeriod);
                printf("Turning ON PWM for %d ms\r\n", displayInfo.modeData->flashOnTime);
#endif
                onTimeEnd = make_timeout_time_ms(displayInfo.modeData->flashOnTime);

                // Turn ON PWM
#ifdef ENABLE_PWM
                pwm_set_chan_level(slice_num, PWM_CHAN_A, adc_on_value_final);
                pwm_set_chan_level(slice_num, PWM_CHAN_B, adc_off_value_final);
#else
                // gpio_put(LED_DRIVER_BLANK_SIGNAL, ENABLE_OUTPUT);//Modified Code Jan 27_2023
                // printf("\nPWM ON\n");
#endif
                displayState = DISPLAY_STATE_ON;
            }

            // Is it time for turning off the display
            if (displayState == DISPLAY_STATE_ON)
            {
                if (absolute_time_diff_us(onTimeEnd, currTime) > 1)
                {
#ifdef ENABLE_FLASH_PRINT
                    printf("Turning OFF PWM for %d ms\r\n", displayInfo.modeData->flashOffTime);
#endif

                    offTimeEnd = make_timeout_time_ms(displayInfo.modeData->flashOffTime);

                    // Turn OFF PWM
#ifdef ENABLE_PWM
                    pwm_set_chan_level(slice_num, PWM_CHAN_A, 0);
                    pwm_set_chan_level(slice_num, PWM_CHAN_B, 255);
#else
                    // gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT);//Modified Code Jan 27_2023
                    // printf("\n PWM OFF\n");
#endif

                    displayState = DISPLAY_STATE_OFF;
                }
            }

            if (displayState == DISPLAY_STATE_OFF)
            {
                // Is it time for turning ON PWM
                if (absolute_time_diff_us(offTimeEnd, currTime) > 1)
                {
#ifdef ENABLE_FLASH_PRINT
                    printf("Turning ON PWM for %d ms, period %d secs\r\n", displayInfo.modeData->flashOnTime,
                           displayInfo.modeData->flashPeriod);
#endif
                    onTimeEnd = make_timeout_time_ms(displayInfo.modeData->flashOnTime);

                    // Turn ON PWM
#ifdef ENABLE_PWM
                    pwm_set_chan_level(slice_num, PWM_CHAN_A, adc_on_value_final);
                    pwm_set_chan_level(slice_num, PWM_CHAN_B, adc_off_value_final);
#else
                    // gpio_put(LED_DRIVER_BLANK_SIGNAL, ENABLE_OUTPUT);//Modified Code Jan 27_2023
                    // printf("\nPWM ON\n");
#endif

                    displayState = DISPLAY_STATE_ON;

                    // One cycle of ON-OFF is done, decrement period
                    if (displayInfo.modeData->flashPeriod)
                        displayInfo.modeData->flashPeriod--;

                    if (!displayInfo.modeData->flashPeriod)
                    {
                        // Clear state for future messages
                        displayInfo.flashStartTime = 0;
                        displayState = DISPLAY_STATE_ON;
                    }
                }
            }
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Re_Identify_The_Board_Type(void)
{
    //printf("\n in Board Re_Identification subroutine");
    if (systemInfo.Board_Type == 1)
    {
        DISPLAY_WIDTH_IN_COLUMNS1dc = (35 * 4) + 4;
        Board140X16 = 1;
        Board128X16 = 0;
        Board96X16 = 0;
        // printf("\n Identified board is 140X16\n");
    }
    else if (systemInfo.Board_Type == 2)
    {
        DISPLAY_WIDTH_IN_COLUMNS1dc = (32 * 4);
        Board140X16 = 0;
        Board128X16 = 1;
        Board96X16 = 0;
        // printf("\n Identified board is  128X16\n");
    }
    else if (systemInfo.Board_Type == 3)
    {
        DISPLAY_WIDTH_IN_COLUMNS1dc = (32 * 4);
        Board140X16 = 0;
        Board128X16 = 0;
        Board96X16 = 1;
        // printf("\n Identified board is 96X16\n");
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Display_Driving_Loop(void)
{
    int i = 0, j = 0, scroll_speed = 8;

#ifdef ENABLE_PICO
    //printf("\n in display driving loop");
    if (Board140X16)
    {
        row_count = 0;
        idx = 0;
        if (systemInfo.testMode)
        {
            scroll_speed = 40;
        }
        for (i = 0; i < scroll_speed; i++)
        // while(1)
        {
#ifdef ENABLE_ALARM
            alarm_fired = false;
            alarm_in_us(current_Dim_Value);
#endif
#ifdef ENABLE_WATCHDOG
            display_watchdog_update();
#endif
            spi_write_blocking(spi_default, &outputbuffer_289[idx], 72);
            sleep_us(1);
            if (row_count == 0)
            {
                idx += 73;
            }
            if (row_count == 1)
            {
                idx = 145;
            }
            if (row_count == 2)
            {
                idx = 217;
            }
            sleep_us(250);
            gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT); // Modified Code Jan 27_2023
            sleep_us(6);
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
            sleep_us(5);
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);
            row_count++;
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            if (row_count == 4)
            {
                row_count = 0;
                idx = 0;

                if (displayDataChanged)
                {
                    memcpy(outputbuffer_289, scrollBuffer, sizeof(outputbuffer_289));
                    displayDataChanged = 0;
                }
            }
            for (j = 0; j <= 2; j++)
            {
                ;
            }
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
            for (j = 0; j <= 2; j++)
            {
                ;
            }

            if (row_count == 1)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_ACTIVE);
            }
            sleep_us(5);
            if (row_count == 1)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE);
            }

            if (!displayInfo.modeData->flashPeriod)
            {
                gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT); // Modified Code Jan 27_2023
            }
            sleep_us(10);
        }
    }
#if 0
    else if (Board128X16 || Board96X16)
    {
        // uint32_t irqStatus;
        row_count = 0;
        idx = 0;
        for (i = 0; i <= 12; i++)
        {
#ifdef ENABLE_ALARM
            alarm_fired = false;
            alarm_in_us(current_Dim_Value);
#endif
            ///////////////////////////////////////////////////////////////
            /////Kicking Watch dog timer functionality added on Jan 28 Morning
#ifdef ENABLE_WATCHDOG
            display_watchdog_update();
#endif
            ////////////////////////////////////////
            if ((Board128X16) && (Board96X16 == 0))
            {
                spi_write_blocking(spi_default, &outputbuffer_256[idx], 64);
                // printf("\n The controle is at spi_write_blocking to 128X16 line 2802");
            }
            else if ((Board96X16) && (Board128X16 == 0))
            {
                spi_write_blocking(spi_default, &outputbuffer_256[idx], 48);
                // printf("\n The controle is at spi_write_blocking to 96X16");
            }
            // Strobe after 350 usecs
            sleep_us(270);
            
            // If it is the 4rth row, drive row reset active
            if (row_count >= 4)
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_ACTIVE);
            sleep_us(2);
            // If it is the 4rth row, drive row reset inactive
            if (row_count >= 4)
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_INACTIVE);
            sleep_us(2);
            gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT); // Modified Code Jan 27_2023
            // Toggle row clock and strobe
            sleep_us(5);
            // Drive Row clock low
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
            // Drive Strobe active halfway into row clock
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            // Drive Strobe inactive halfway into row clock
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            // Complete row clock pulse by driving it high
            // restore_interrupts (irqStatus);
            idx += 64;
            if (row_count == 0)
            {
                //Row_RESET();
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_ACTIVE);
                sleep_us(4);
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_INACTIVE);

            }
            // Drive PWM active now that we are done with strobing data
            row_count++;
            if (row_count >= 4)
            {
                row_count = 0;
                idx = 0;
            }
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
            if (row_count >= 4)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_ACTIVE);
                sleep_us(5);
            }
            if (row_count >= 4)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_CLK_INACTIVE);
                sleep_us(10);
            }
        }
    }
#else
    else if (Board128X16 || Board96X16)
    {
        // uint32_t irqStatus;
        row_count = 0;
        idx = 0;
        if (systemInfo.testMode)
        {
            scroll_speed = 40;
        }
        for (i = 0; i < scroll_speed; i++)
        {
#ifdef ENABLE_ALARM
            alarm_fired = false;
            alarm_in_us(current_Dim_Value);
#endif
            ///////////////////////////////////////////////////////////////
            /////Kicking Watch dog timer functionality added on Jan 28 Morning
#ifdef ENABLE_WATCHDOG
            display_watchdog_update();
#endif
            ////////////////////////////////////////
            if ((Board128X16) && (Board96X16 == 0))
            {
                spi_write_blocking(spi_default, &outputbuffer_256[idx], 64);
                // printf("\n The controle is at spi_write_blocking to 128X16 line 2802");
                idx += 64;
            }
            else if ((Board96X16) && (Board128X16 == 0))
            {
                spi_write_blocking(spi_default, &outputbuffer_256[idx], 48);
                // printf("\n The controle is at spi_write_blocking to 96X16");
                idx += 64;
            }
            sleep_us(250);
            gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT); // Modified Code Jan 27_2023
            sleep_us(6);
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);
            sleep_us(5);
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);
            row_count++;
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
            for (j = 0; j <= 4; j++)
            {
                ;
            }
            if (row_count == 4)
            {
                row_count = 0;
                idx = 0;

                if (displayDataChanged)
                {
                    memcpy(outputbuffer_256, scrollBuffer, sizeof(outputbuffer_256));
                    displayDataChanged = 0;
                }
            }
            for (j = 0; j <= 2; j++)
            {
                ;
            }
            gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_ACTIVE);
            for (j = 0; j <= 2; j++)
            {
                ;
            }

            if (row_count == 1)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_ACTIVE);
            }
            sleep_us(5);
            if (row_count == 1)
            {
                gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE);
            }
        }
    }
#endif

#endif
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int map(int x, int in_min, int in_max, int out_min, int out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}