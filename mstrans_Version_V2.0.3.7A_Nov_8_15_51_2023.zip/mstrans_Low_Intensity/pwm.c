//
// pwm.c This file implements functions for managing intensity of LEDs of the display
//
#include <stdio.h>
#include <string.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/pwm.h"
#else
#include <stdint.h>
#endif
#include "main.h"
#include "init.h"
#include "pwm.h"

void setpwm()
{
    void init_gpio();// This is the function of PWM Inetialization
#ifdef ENABLE_PICO
    // uint slice_num;

    // gpio_set_function(LED_DRIVER_BLANK_SIGNAL, GPIO_FUNC_PWM);
    // slice_num = pwm_gpio_to_slice_num(LED_DRIVER_BLANK_SIGNAL);

    // // Set period of 4 cycles (0 to 3 inclusive)
    // pwm_set_wrap(slice_num, 256);

    // // Set channel A output high for one cycle before dropping
    // pwm_set_chan_level(slice_num, PWM_CHAN_A, 150);

    // // Set initial B output high for three cycles before dropping
    // pwm_set_chan_level(slice_num, PWM_CHAN_B, 106);

    // // Set the PWM running
    // pwm_set_enabled(slice_num, true); 
#endif
}
