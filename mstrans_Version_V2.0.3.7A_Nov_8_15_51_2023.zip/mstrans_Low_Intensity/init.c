//
// This file implements functions for initializing hardware
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "hardware/pwm.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#include "hardware/structs/clocks.h"
#endif
#include "init.h"
#include "proc-card.h"

void init_gpio(void)
{
#ifdef ENABLE_PICO
    // Init I/O lines
    gpio_init(PICO_LED_PIN);
    gpio_init(RS485_DIR);
    gpio_init(TEST_MODE);
    gpio_init(DEBUG_LED);
    gpio_init(ASW0v);
    gpio_init(ASW1v);
    gpio_init(ASW2v);
    gpio_init(ASW3v);
    gpio_init(LED_DRIVER_BLANK_SIGNAL); // Code added on Jan 25_2023 at 20:36

    // Set direction
    gpio_set_dir(DEBUG_LED, GPIO_OUT);
    gpio_set_dir(TEST_MODE, GPIO_IN);
    gpio_set_dir(PICO_LED_PIN, GPIO_OUT);
    gpio_set_dir(RS485_DIR, GPIO_OUT); // configure RS485_Direction pin as output
    gpio_set_dir(ASW0v, GPIO_IN);
    gpio_set_dir(ASW1v, GPIO_IN);
    gpio_set_dir(ASW2v, GPIO_IN);
    gpio_set_dir(ASW3v, GPIO_IN);
    gpio_set_dir(LED_DRIVER_BLANK_SIGNAL, GPIO_OUT);// Code added on Jan 25_2023 at 20:38
    //gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT);


    gpio_put(DEBUG_LED, LOW);
    gpio_put(PICO_LED_PIN, HIGH);
    gpio_put(LED_DRIVER_BLANK_SIGNAL,HIGH); // OUTPUT Enable Disable (High Disable and LOW Enable) Code added on April 27_2023 
#endif
}

#ifdef ENABLE_PICO
void init_uart(void)
{
    gpio_set_function(UART_TX, GPIO_FUNC_UART);
    gpio_set_function(UART_RX, GPIO_FUNC_UART);

    // Configure RS485_Direction pin as input
    gpio_put(RS485_DIR, LOW);
    uart_init(uart0, UART_BAUD_RATE);
}
#endif

void init_adc(void)
{
#ifdef ENABLE_PICO
    adc_init();

    // Make sure GPIO is high-impedance, no pullups etc
    adc_gpio_init(ADC_LDR);

    // Select ADC input 0 (GPIO26)
    adc_select_input(ADC_LDR_INPUT);
#endif
}

void init_spi()
{
#ifdef ENABLE_PICO
    // This example will use SPI0 at 4MHz.
    spi_init(spi_default, 4000 * 1000);
    gpio_set_function(LED_DRIVER_MOSI_SIGNAL, GPIO_FUNC_SPI);
    gpio_set_function(LED_DRIVER_MISO_SIGNAL, GPIO_FUNC_SPI);
    gpio_set_function(LED_DRIVER_SCLK_SIGNAL, GPIO_FUNC_SPI);

    // Make the SPI pins available to picotool
    //bi_decl(bi_3pins_with_func(LED_DRIVER_MOSI_SIGNAL, LED_DRIVER_MISO_SIGNAL, LED_DRIVER_SCLK_SIGNAL, GPIO_FUNC_SPI));
#endif
}

void init_manual_spi(void)
{
    gpio_init(LED_DRIVER_SCLK_SIGNAL);
    gpio_init(LED_DRIVER_MOSI_SIGNAL);
    gpio_init(LED_DRIVER_MISO_SIGNAL);
    
    gpio_set_dir(LED_DRIVER_MISO_SIGNAL, GPIO_OUT);
    gpio_set_dir(LED_DRIVER_MOSI_SIGNAL, GPIO_OUT);
    gpio_set_dir(LED_DRIVER_SCLK_SIGNAL, GPIO_OUT);
}

void init_spi_6000()
{
#ifdef ENABLE_PICO
    // This example will use SPI0 at 6MHz.
    spi_init(spi_default, 6000 * 1000);
    gpio_set_function(LED_DRIVER_MOSI_SIGNAL, GPIO_FUNC_SPI);
    gpio_set_function(LED_DRIVER_MISO_SIGNAL, GPIO_FUNC_SPI);
    gpio_set_function(LED_DRIVER_SCLK_SIGNAL, GPIO_FUNC_SPI);

    // Make the SPI pins available to picotool
    //bi_decl(bi_3pins_with_func(LED_DRIVER_MOSI_SIGNAL, LED_DRIVER_MISO_SIGNAL, LED_DRIVER_SCLK_SIGNAL, GPIO_FUNC_SPI));
#endif
}
void init_pwm(void)
{
#ifdef ENABLE_PICO
#ifdef ENABLE_PWM
    uint slice_num;

    gpio_set_function(LED_DRIVER_BLANK_SIGNAL, GPIO_FUNC_PWM);
    slice_num = pwm_gpio_to_slice_num(LED_DRIVER_BLANK_SIGNAL);

    // Set period of 4 cycles (0 to 3 inclusive)
     pwm_set_wrap(slice_num, 256);

    // Set channel A output high for one cycle before dropping
    pwm_set_chan_level(slice_num, PWM_CHAN_A, 25);

    // Set initial B output high for three cycles before dropping
    pwm_set_chan_level(slice_num, PWM_CHAN_B, 231);

    // Set the PWM running
    pwm_set_enabled(slice_num, true); 
#else
    gpio_init(LED_DRIVER_BLANK_SIGNAL);
    gpio_set_dir(LED_DRIVER_BLANK_SIGNAL, GPIO_OUT);
    gpio_put(LED_DRIVER_BLANK_SIGNAL,DISABLE_OUTPUT); // OUTPUT Enable Disable (High Disable and LOW Enable) Code added on April 27_2023 

#endif

    // Setup other 
    gpio_init(LED_DRIVER_STROBE_SIGNAL);
    gpio_set_dir(LED_DRIVER_STROBE_SIGNAL, GPIO_OUT);

    gpio_init(LED_DRIVER_ROW_RESET_SIGNAL);
    gpio_set_dir(LED_DRIVER_ROW_RESET_SIGNAL, GPIO_OUT);

    gpio_init(LED_DRIVER_ROW_CLK_SIGNAL);
    gpio_set_dir(LED_DRIVER_ROW_CLK_SIGNAL, GPIO_OUT);

#endif
}

void init_led_driver_signals(void)
{
#ifdef ENABLE_PICO
    gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_ACTIVE);
    sleep_us(100);
    gpio_put(LED_DRIVER_ROW_RESET_SIGNAL, ROW_RST_INACTIVE); 
    gpio_put(LED_DRIVER_ROW_CLK_SIGNAL, ROW_CLK_INACTIVE);

#ifndef ENABLE_PWM
    gpio_put(LED_DRIVER_BLANK_SIGNAL, DISABLE_OUTPUT);
#endif

#endif
}

void init_temperature_sensor()
{
    adc_init();
    adc_set_temp_sensor_enabled(true);
}

int read_cpu_temperature() 
{
    /* 12-bit conversion, assume max value == ADC_VREF == 3.3 V */
    const float conversionFactor = 3.3f / (1 << 12);

    adc_set_temp_sensor_enabled(true);
    adc_select_input(4);
    float adc = (float)adc_read() * conversionFactor;
    float tempC = 27.0f - (adc - 0.706f) / 0.001721f;

    adc_select_input(0);

    return (int)tempC;
}