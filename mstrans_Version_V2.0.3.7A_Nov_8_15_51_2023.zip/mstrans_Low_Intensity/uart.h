#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Wait time for UART
#define UART_WAIT_TIME_IN_USEC  1000

#define MAX_UART_BUFFER         4096

#define UART_FRAMING_INIT         0
#define UART_SOF_RECEIVED         1
#define UART_EOF_RECEIVED         2
#define UART_CMD                  3
#define UART_ID                   4
#define UART_DATA                 5
#define UART_CHECKSUM_MSB         6
#define UART_CHECKSUM_LSB         7
#define UART_CMD_RECEIVED         8
#define UART_FRAMING_DONE         9

#define HANOVER_PROT_MASTER_SOF          0x02
#define HANOVER_PROT_MASTER_EOF          0x03

#define HANOVER_PROT_SLAVE_SOF          0x01
#define HANOVER_PROT_SLAVE_EOF          0x04

#define MIN_VALID_FRAME_SIZE        10  // Frames less than this payload size will be dropped

typedef struct {
    uint8_t framing_buffer[MAX_UART_BUFFER];
    uint16_t framing_buffer_index;
    uint16_t framing_buffer_len;
    uint8_t csumBuf[2];
    uint8_t csum;
    uint8_t cmd;
    uint8_t destId; 
    uint8_t state;
    uint8_t flashingflag;
    uint8_t showDisplayInfo;
} UART_FRAME;

typedef struct{
    uint8_t flashingflag2;
    uint8_t flashingstring2[50];
}UART_FRAME_1;

extern UART_FRAME   *pUart;

#ifndef ENABLE_PICO
uint8_t init_uart(char *fname);
#else
uint8_t init_uart();
#endif
uint8_t send_frame(uint8_t *pBuf, uint16_t bufLen);
uint8_t recv_byte(uint8_t *pCh);
uint8_t deinit_uart();
uint8_t build_hanover_frame(uint8_t ch);
uint8_t validate_hanover_frame();
void clear_hanover_frame();
void send_byte(uint8_t ch);
