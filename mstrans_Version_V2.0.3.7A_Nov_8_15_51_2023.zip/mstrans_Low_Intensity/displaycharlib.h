#ifndef  __LIB__


#define   __LIB__
typedef struct {
        char *font;     
} FONT_TABLE;

extern FONT_TABLE CapitalFontTable8x8[];
extern FONT_TABLE SmallFontTable8x8[];
extern FONT_TABLE NumberFontTable8x8[];

extern FONT_TABLE CapitalFontTable8x16[];
extern FONT_TABLE SmallFontTable8x16[];
extern FONT_TABLE NumberFontTable8x16[];
extern FONT_TABLE SpecialChar8x16set1[];
extern FONT_TABLE SpecialChar8x16set2[];
extern FONT_TABLE SpecialChar8x16set3[];
extern FONT_TABLE SpecialChar8x16set4[];
extern FONT_TABLE SpecialChar8x8set1[];
extern FONT_TABLE SpecialChar8x8set2[];
extern FONT_TABLE SpecialChar8x8set3[];
extern FONT_TABLE SpecialChar8x8set4[];
int display_string(char *charptr, uint8_t *outputbuffer);

#endif
