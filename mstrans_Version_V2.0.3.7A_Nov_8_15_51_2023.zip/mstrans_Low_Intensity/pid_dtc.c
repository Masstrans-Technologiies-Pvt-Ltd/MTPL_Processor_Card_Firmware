#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "pico/unique_id.h"
#include "main.h"
#include "init.h"
#include "flashchip.h"
#include "lastmsg.h"
#include "pid_dtc.h"
#include "rcerr.h"
#include "uart.h"
#include "hardware/adc.h"

//#ifdef ENABLE_PID_DTC

uint32_t curr_reset_block_offset = 0;
RESET_BLOCK_INFO saved_reset_block_info = {0};
RESET_BLOCK_INFO reset_block_info = {0};
PID_DTC_INFO pid_dtc = {0};
PID_DTC_RESP_HDR resp_hdr = {0};
PID_DTC_RESP_PAYLOAD resp_payload = {0};
PID_DTC_RESP_TRAILER resp_trailer = {0};
char Flash_Memory_Buffer[256] = {0};
char readbuf[256] = {0};
/*
   pid_dtc.c: This file implements functions to handle requests for PID / DTC information from
   PIS controller
   */
/* Updates temperature and battery voltage into pid_dtc_info structure */
uint8_t update_sensor_info(void)
{
    uint8_t rc = RC_SUCCESS;

    /* Todo: Read CPU temperature */

    /* Todo: Read Battery voltage */
    pid_dtc.curr_batt = Read_Voltage_Sensor();
    if(pid_dtc.curr_batt>pid_dtc.max_batt)
    {
        pid_dtc.over_voltage_flag = true;
        pid_dtc.under_voltage_flag = false;
    }
    else if(pid_dtc.curr_batt<pid_dtc.min_batt)
    {
        pid_dtc.under_voltage_flag = true;
        pid_dtc.over_voltage_flag = false;
    }
    else
    {
        pid_dtc.over_voltage_flag = false;
        pid_dtc.under_voltage_flag = false;
    }
    //printf("\nCurrent Voltage Reading is = %d",pid_dtc.curr_batt);
    return rc;
}

/* Returns 1 if the input value is a pid/dtc group command */
uint8_t is_pid_dtc_cmd(uint8_t val)
{
    int rc = 0;

    if (PID_DTC_GRP_CMD == val)
        rc = 1;

    return rc;
}

static void prepare_hdr(uint8_t cmd)
{
    printf("\n in prepar_hdr function cmd = %d",cmd);
    resp_hdr.soh = RESP_SOH;
    if(pUart->cmd == PID_DTC_GRP_CMD)
    resp_hdr.cmd = PID_DTC_GRP_CMD + '0';
    if(pUart->cmd == PID_DTC_SET_REQUEST)
    resp_hdr.cmd = PID_DTC_SET_REQUEST + '7';
    //resp_hdr.cmd = PID_DTC_SET_REQUEST + '7';
    resp_hdr.addr = systemInfo.deviceId + '0';
    resp_hdr.grp = cmd;
    printf("\nresp_hdr.grp = %d",resp_hdr.grp);
    printf("\nresp_hdr.grp = %c",(char)resp_hdr.grp);
    printf("\nresp_hdr.grp = %02X",resp_hdr.grp);
    return;
}
//////////////////////////////////////////////////////////////////////

static void prepare_trailer()
{
    resp_trailer.eot = RESP_EOT;
    printf("\n in prepare_trailer function");

    // Todo: Compute the checksum
    //printf("\r\n prepare_trailer function()\n");
    for (int i = 0; i < resp_payload.resp_len; i++)
    {
        //printf("%c", resp_payload.pid_dtc_resp[i]);
        //sleep_ms(10);
    }
    calculate_checksum_pid_dtc();
    //resp_trailer.csum[0] = 0xbe;
    //resp_trailer.csum[1] = 0xef;
}

/* Get production information
   serialno
   proddate
   testdate
   hw_ver
   */
static void prepare_prod_info()
{
    int len = sizeof(resp_payload.pid_dtc_resp);
    int offset = 0;

    pico_get_unique_board_id_string (Flash_Memory_Buffer,sizeof(Flash_Memory_Buffer));
    printf("\n serial Number is %s",Flash_Memory_Buffer);
    Load_Product_Info_From_Flash();
    memcpy(pid_dtc.serial_no,Flash_Memory_Buffer,sizeof(pid_dtc.serial_no));
    printf("Processing Production Information in Get Product Information Function\r\n");
    memset(resp_payload.pid_dtc_resp, 0, sizeof(resp_payload.pid_dtc_resp));
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, "SN:%s", pid_dtc.serial_no);
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%s", pid_dtc.serial_no);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
             pid_dtc.fw_flash_date);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
             pid_dtc.test_date);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",HW:%s",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
             pid_dtc.hw_ver);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    printf("\n pid_dtc.fw_update_status = %s",pid_dtc.fw_update_status);

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",FUS:%s",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
            pid_dtc.fw_update_status);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    printf("\n pid_dtc.article_no_sign_lev = %s",pid_dtc.art_no_sign_lev);
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",ANSL:%s",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
            pid_dtc.art_no_sign_lev);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;
    
    printf("\n pid_dtc.Meta_data = %s",pid_dtc.meta_dat_ver);
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",MTDT:%s",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
            pid_dtc.meta_dat_ver);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;
}

/* Firmware version and CPU info
 */
static void prepare_firmware_cpu_info()
{
    int len = sizeof(resp_payload.pid_dtc_resp);
    int offset = 0;

    memset(resp_payload.pid_dtc_resp, 0, sizeof(resp_payload.pid_dtc_resp));
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%s", pid_dtc.fw_ver);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
             pid_dtc.bootloader_ver);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
             pid_dtc.font_library_ver);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s",
             pid_dtc.fw_build_date);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",CPU_PN:RP2040",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",RP2040",
             pid_dtc.hw_ver);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",CPU_Qualification:000");
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",000");
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",CPU_temp_range:40-85");
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",40-85");
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;
}

static void prepare_runtime_info()
{
    int len = sizeof(resp_payload.pid_dtc_resp);
    int offset = 0;

    update_sensor_info();
    memset(resp_payload.pid_dtc_resp, 0, sizeof(resp_payload.pid_dtc_resp));
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, "BT:%02d", pid_dtc.curr_temp);
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%02d", pid_dtc.curr_temp);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",CT:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.curr_temp);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",CM:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.min_temp);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",CX:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.max_temp);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",BM:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.min_temp);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",BX:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.max_temp);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",VM:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.min_batt);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",VX:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.max_batt);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",VC:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
             pid_dtc.curr_batt);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",WH:%02d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%02d",
            pid_dtc.work_hour);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;
    //printf("\n work_hour_count in pid_dtc function = %d", pid_dtc.work_hour);

    get_last_reset_count(&pid_dtc.reset_count);
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",NR:%04d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%04d",
             pid_dtc.reset_count);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",OV:%d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%d",
            pid_dtc.over_voltage_flag);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",UV:%d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%d",
            pid_dtc.under_voltage_flag);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    if(pid_dtc.curr_temp > pid_dtc.max_temp)
    {
        pid_dtc.over_Temperature_flag = true;
        //printf("\n In over temperature condition \n");
    }
    else if(pid_dtc.curr_temp < pid_dtc.max_temp)
    {
        //printf("\n in Normal temperature  condition \n");
        pid_dtc.over_Temperature_flag = false;
    }
    printf("\nboard temperature = %d \n cpu temperature = %d \n max temperature = %d \n min temperature = %d",pid_dtc.curr_temp,pid_dtc.curr_temp,pid_dtc.max_temp,pid_dtc.min_temp);
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",OT:%d",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%d",
            pid_dtc.over_Temperature_flag);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;
}

static void prepare_customer_info()
{
    int len = sizeof(resp_payload.pid_dtc_resp);
    int offset = 0;
    
    Load_Customer_Info_From_Flash();
    memset(resp_payload.pid_dtc_resp, 0, sizeof(resp_payload.pid_dtc_resp));
    //snprintf(&resp_payload.pid_dtc_resp[offset], len, "Customer_Name:%s", pid_dtc.cust_name);
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%s", pid_dtc.cust_name);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, ",Order_Number:%s,",
    snprintf(&resp_payload.pid_dtc_resp[offset], len, ",%s,",
             pid_dtc.order_no);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, "Bus_Type:%s,", pid_dtc.bus_type);
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%s,", pid_dtc.bus_type);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, "Bus_Build:%s,", pid_dtc.bus_build);
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%s,", pid_dtc.bus_build);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;

    //snprintf(&resp_payload.pid_dtc_resp[offset], len, "Language:%s", pid_dtc.language);
    snprintf(&resp_payload.pid_dtc_resp[offset], len, "%s", pid_dtc.language);
    offset = strlen(resp_payload.pid_dtc_resp);
    len = sizeof(resp_payload.pid_dtc_resp) - offset;
}

/* Identifies the pid_dtc command and prepares appropriate response using
   information from the pid_dtc_info structure
   */
uint8_t  process_pid_dtc_command(uint8_t cmd)
{
    uint8_t rc = RC_SUCCESS;

    pid_dtc.curr_temp = read_cpu_temperature();
    /*if (pid_dtc.max_temp < pid_dtc.curr_temp)
        pid_dtc.max_temp = pid_dtc.curr_temp;

    if (pid_dtc.min_temp > pid_dtc.curr_temp)
        pid_dtc.min_temp = pid_dtc.curr_temp;*/

    printf("CPU Temperature = %d/%d/%d\n", pid_dtc.min_temp,
           pid_dtc.curr_temp, pid_dtc.max_temp);

    prepare_hdr(cmd);
    printf("\n cmd = %d\n",cmd);
    switch (cmd)
    {
    case PID_DTC_GRP1:
        prepare_prod_info();
        break;

    case PID_DTC_GRP2:
        prepare_firmware_cpu_info();
        break;

    case PID_DTC_GRP3:
        prepare_runtime_info();
        break;

    case PID_DTC_GRP4:
        prepare_customer_info();
        break;

    default:
        rc = RC_INVALID_PARAMETER;
        printf("Invalid PID_DTC_Group %d\n", (int)cmd);
        break;
    }

    if (RC_SUCCESS == rc)
    {
        resp_payload.resp_len = strlen(resp_payload.pid_dtc_resp);
        prepare_trailer();
    }

    return rc;
}


///////////////////////////////////////////////////////////////////////////////////////
/* Identifies the pid_dtc command and sets the memory according to the information received and 
    prepares appropriate response using prepares appropriate response using
   information from the pid_dtc_info structure
   */
uint8_t  process_pid_dtc_set_command(uint8_t cmd)
{
    uint8_t rc = RC_SUCCESS;
    char *token1[15],temp_flash_buffer[256]={0};
    int i = 0,offset = 0,len = 256;
    prepare_hdr(cmd);
    switch (cmd)
    {
    case PID_DTC_GRP1:
        // Command to Set Product Information
        printf("\nreceived command in set request 0x%02X",PID_DTC_GRP1);
        printf("\n Product Information");
        printf("\n");
        i=1;
        while(pUart->framing_buffer[i])
        {
            //printf("%c",pUart->framing_buffer[i]);
            Flash_Memory_Buffer[i-1]=pUart->framing_buffer[i];
            i++;
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // printf("\n data to be written into the flash is =\n%s",Flash_Memory_Buffer);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        // printf("\n ----------------------------------------------------------------------------------------");
        token1[0] = strtok(Flash_Memory_Buffer, ",");
        // printf("\n data in Serial Number Field is %s",token1[0]);
        // printf("\n the length of Serial_Number_Field is = %d",strlen(token1[0]));
        if(strlen(token1[0])>=17)
        {
            // printf("\n Serial_Number_field exceeds its limit");
            i=16;
            while(token1[0][i])
            {
                token1[0][i] = 0;
                i++;
            }

        }
        // printf("\n data in customer_name_field is %s",token1[0]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        i=1;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=7)
        {
            // printf("\n Production_Date_field exceeds its limit");
            i=6;
            while(token1[1][i])
            {
                token1[1][i] = 0;
                i++;
            }
        }
        // printf("\n data in Production_Date_field is %s",token1[1]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        i=2;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=7)
        {
            // printf("\n Test_Date_field exceeds its limit");
            i=6;
            while(token1[2][i])
            {
                token1[2][i] = 0;
                i++;
            }
        }
        // printf("\n data in Test_Date_field is %s",token1[2]);
        // printf("\n ----------------------------------------------------------------------------------------");
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        i=3;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=6)
        {
            // printf("\n Hardware_Version_field exceeds its limit");
            i=5;
            while(token1[3][i])
            {
                token1[3][i] = 0;
                i++;
            }
        }
        // printf("\n data in Hardware_Version_field is %s",token1[3]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        i=4;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=4)
        {
            // printf("\n Flash_Update_Status_field exceeds its limit");
            i=3;
            while(token1[4][i])
            {
                token1[4][i] = 0;
                i++;
            }
        }
        // printf("\n data in Flash_Update_Status_field is %s",token1[4]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        i=5;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=4)
        {
            // printf("\n Article_Number_Sign_Level_field exceeds its limit");
            i=3;
            while(token1[5][i])
            {
                token1[5][i] = 0;
                i++;
            }
        }
        // printf("\n data in Article_Number_Sign_Level_field is %s",token1[5]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        i=6;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=5)
        {
            // printf("\n Meta_Data_Version_field exceeds its limit");
            i=4;
            while(token1[6][i])
            {
                token1[6][i] = 0;
                i++;
            }
        }
        // printf("\n data in Meta_Data_Version_field is %s",token1[6]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // while((i<5))
        // {
        //     token1[i] = strtok(NULL,",");
        //     printf("\n token1[%d] is %s",i,token1[i]);
        //     printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        //     printf("\nx-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x\n");
        //     i++;
        // }
        /////////////////////////////////////////////////////////////////////////////////////////////////
        // printf("\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        //snprintf(temp_flash_buffer,)
        offset = 0;
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[0]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[1]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[2]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[3]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[4]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[5]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s", token1[6]);
        offset = strlen(temp_flash_buffer);
        // printf("\n----------------------------------------------------------------------------------");
        // printf("\n New string is \n %s",temp_flash_buffer);
        // printf("\n----------------------------------------------------------------------------------");
        /*while(pUart->framing_buffer[i])
        {
            // printf("%c",pUart->framing_buffer[i]);
            i++;
        }*/
        //printf("\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        // printf("\n data in flash Memory_Buffer before writing into the flash is ");
        // printf("\n %s",Flash_Memory_Buffer);
        // printf("\n data in temp_flash_Buffer before writing into the flash is ");
        // printf("\n %s",temp_flash_buffer);
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        //printf("\n%s\n",Flash_Memory_Buffer);
        //printf("\n writing data into flash memory at PRODUCT_INFO_ADDR_LOCATION ");
        //Write_data_Into_Flash((uint8_t *) &Flash_Memory_Buffer,PRODUCT_INFO_ADDR_LOCATION,strlen(Flash_Memory_Buffer));
        Write_data_Into_Flash((uint8_t *) &temp_flash_buffer,PRODUCT_INFO_ADDR_LOCATION,strlen(temp_flash_buffer));
        //printf("\n size of char buffer is %d",sizeof(Flash_Memory_Buffer));
        //printf("\n Load Product_Info_From_Flash in Set Product Information Function");
        Load_Product_Info_From_Flash();
        memset(resp_payload.pid_dtc_resp,0,sizeof(resp_payload.pid_dtc_resp));
        resp_payload.pid_dtc_resp[0] = 0x31;
        resp_payload.resp_len = 1;
        rc = RC_SUCCESS;
        break;

    case PID_DTC_GRP2:
        // command to set Firmware Cpu information
        printf("\nreceived command in set request 0x%02X",PID_DTC_GRP2);
        printf("\n Firmware & Cpu Information");
        printf("\n");
        i=0;
        while(pUart->framing_buffer[i])
        {
            printf("%c",pUart->framing_buffer[i]);
            i++;
        }
         
        //prepare_firmware_cpu_info();
        resp_payload.pid_dtc_resp[0] = 0x31;
        resp_payload.resp_len = 1;
        rc = RC_SUCCESS;
        break;

    case PID_DTC_GRP3:
        // command to set Runtime information
        printf("\nreceived command in set request 0x%02X",PID_DTC_GRP3);
        printf("\n Runtime Information");
        printf("\n");
        i=0;
        while(pUart->framing_buffer[i])
        {
            printf("%c",pUart->framing_buffer[i]);
            i++;
        }
        //prepare_runtime_info();
        resp_payload.pid_dtc_resp[0] = 0x31;
        resp_payload.resp_len = 1;
        rc = RC_SUCCESS;
        break;

    case PID_DTC_GRP4:
        // command to set customer information
        printf("\nreceived command in set request 0x%02X",PID_DTC_GRP4);
        printf("\n Customer Information");
        printf("\n");
        printf("\n");
        i=1;
        // printf("\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        while(pUart->framing_buffer[i])
        {
            // printf("%c",pUart->framing_buffer[i]);
            Flash_Memory_Buffer[i-1]=pUart->framing_buffer[i];
            i++;
        }
        // printf("\n data to be written into the flash is =\n%s",Flash_Memory_Buffer);
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        // printf("\n ----------------------------------------------------------------------------------------");
        token1[0] = strtok(Flash_Memory_Buffer, ",");
        // printf("\n data in customer_name_field is %s",token1[0]);
        // printf("\n the length of customer_name_filed is = %d",strlen(token1[0]));
        if(strlen(token1[0])>=9)
        {
            // printf("\n customer name field exceeds its limit");
            i=8;
            while(token1[0][i])
            {
                token1[0][i] = 0;
                i++;
            }

        }
        // printf("\n data in customer_name_field is %s",token1[0]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        i=1;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=9)
        {
            // printf("\n ORDER Number field exceeds its limit");
            i=8;
            while(token1[1][i])
            {
                token1[1][i] = 0;
                i++;
            }
        }
        // printf("\n data in ORDER Number field is %s",token1[1]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        i=2;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=6)
        {
            // printf("\n Bus Type field exceeds its limit");
            i=5;
            while(token1[2][i])
            {
                token1[2][i] = 0;
                i++;
            }
        }
        // printf("\n data in Bus_Type_field is %s",token1[2]);
        // printf("\n ----------------------------------------------------------------------------------------");
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        i=3;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=6)
        {
            // printf("\n Bus Build field exceeds its limit");
            i=5;
            while(token1[3][i])
            {
                token1[3][i] = 0;
                i++;
            }
        }
        // printf("\n data in Bus_Build_field is %s",token1[3]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        i=4;
        token1[i] = strtok(NULL,",");
        // printf("\n token1[%d] is %s",i,token1[i]);
        // printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        if(strlen(token1[i])>=4)
        {
            // printf("\n Language field exceeds its limit");
            i=3;
            while(token1[4][i])
            {
                token1[4][i] = 0;
                i++;
            }
        }
        // printf("\n data in Language_field is %s",token1[4]);
        // printf("\n ----------------------------------------------------------------------------------------");
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // while((i<5))
        // {
        //     token1[i] = strtok(NULL,",");
        //     printf("\n token1[%d] is %s",i,token1[i]);
        //     printf("\n the length of token1[%d] is = %d",i,strlen(token1[i]));
        //     printf("\nx-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x\n");
        //     i++;
        // }
        /////////////////////////////////////////////////////////////////////////////////////////////////
        // printf("\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        i=1;
        //snprintf(temp_flash_buffer,)
        offset = 0;
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[0]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[1]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[2]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s,", token1[3]);
        offset = strlen(temp_flash_buffer);
        snprintf(&temp_flash_buffer[offset], len, "%s", token1[4]);
        offset = strlen(temp_flash_buffer);
        // printf("\n----------------------------------------------------------------------------------");
        // printf("\n New string is \n %s",temp_flash_buffer);
        // printf("\n----------------------------------------------------------------------------------");
        /*while(pUart->framing_buffer[i])
        {
            // printf("%c",pUart->framing_buffer[i]);
            i++;
        }*/
        //printf("\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        // printf("\n data in flash Memory_Buffer before writing into the flash is ");
        // printf("\n %s",Flash_Memory_Buffer);
        // printf("\n data in temp_flash_Buffer before writing into the flash is ");
        // printf("\n %s",temp_flash_buffer);
        //Write_data_Into_Flash((uint8_t *) &Flash_Memory_Buffer,CUSTOMER_INFO_ADDR_LOCATION,strlen(Flash_Memory_Buffer));
        Write_data_Into_Flash((uint8_t *) &temp_flash_buffer,CUSTOMER_INFO_ADDR_LOCATION,strlen(temp_flash_buffer));
        // printf("\n Load Customer info in Set Customer Information Function");
        Load_Customer_Info_From_Flash();
        printf("\n Successfully Set Customer Information");
        //prepare_customer_info();
        memset(resp_payload.pid_dtc_resp,0,sizeof(resp_payload.pid_dtc_resp));
        resp_payload.pid_dtc_resp[0] = 0x31;
        resp_payload.resp_len = 1;
        rc = RC_SUCCESS;
        break;

    case PID_DTC_GRP5:
        // command to set Run HOURE and Number of Resets information
        printf("\nreceived command in set request 0x%02X",PID_DTC_GRP5);
        printf("\n RUN HOURE COMMAND");
        printf("\n");
        i=1;
        while(pUart->framing_buffer[i])
        {
            printf("%c",pUart->framing_buffer[i]);
            Flash_Memory_Buffer[i-1]=pUart->framing_buffer[i];
            i++;
        }
        /*while(pUart->framing_buffer[i])
        {
            //printf("%c",pUart->framing_buffer[i]);
            Flash_Memory_Buffer[i]=pUart->framing_buffer[i];
            i++;
        }*/
        token1[0]=NULL;
        //memcpy(temp_buffer,pUart->framing_buffer,pUart->framing_buffer_index);
        token1[0] = strtok(Flash_Memory_Buffer, ",");
        printf("\n data in temp work hour field is %s",token1[0]);
        i=1;
        while((token1[i] != NULL)&&(i<3))
        {
            token1[i] = strtok(NULL,",");
            //printf("\n the data in tempbuf after copying work hour number token1[%d]is %s",i,token1[i]);
            i++;
        }
        //printf("\n data in temp work hour field is %s",token1[1]);
        printf("\n data in Number_of_Resets = %s",token1[1]);
        // token1[3]=strtok(token1[2],":");
        // token1[4]=strtok(NULL,":");
        //printf("\n Header For Number_of_Resets Field = %s",token1[3]);
        // printf("\n Extracting Number_of_Resets Field = %s",token1[1]);
        // printf("\n And");
        // printf("\n Extracting Number_of_Work_Hours_Field = %s",token1[0]);
        // printf("\n data is %c and %c",token1[1][0],token1[1][1]);
        uint32_t set_reset_count = 0;
        set_reset_count = (((token1[1][0] - '0')*10)+((token1[1][1] - '0')));
        // printf("\n set_reset_count = %d",set_reset_count);
        update_reset_count(set_reset_count);
        resp_payload.pid_dtc_resp[0] = 0x31;
        resp_payload.resp_len = 1;
        rc = RC_SUCCESS;
        break;

    default:
        rc = RC_INVALID_PARAMETER;
        printf("Invalid PID_DTC_Set_Group %d\n", (int)cmd);
        resp_payload.pid_dtc_resp[0] = 0x30;
        resp_payload.resp_len = 1;
        break;
    }
    printf("\n rc = %d", rc);
    if (RC_SUCCESS == rc)
    {
        printf("RC_SUCCESS ");
        prepare_trailer();
    }
    else 
    {
        printf("RC_FAILURE ");
        prepare_trailer();
    }
    return rc;
}
///////////////////////////////////////////////////////////////////////////////////////

/* Prepares Hanover header alongwith checksum and transmits response to PID controller
   Transmitting frame should follow the sequence below
   Enable XMIT line
   Transmit frame
   Disable XMIT line, go back to RECV mode
   */
uint8_t transmit_pid_dtc_response(void)
{
    uint8_t rc = RC_SUCCESS;
    uint32_t i = 0;

    printf("\nin error response transmit function\n");
    printf("resp_hdr.soh = %d\n",resp_hdr.soh);
    printf("resp_hdr.cmd = %d\n",resp_hdr.cmd);
    printf("resp_hdr.addr = %d\n",resp_hdr.addr);
    printf("resp_hdr.grp = %d",resp_hdr.grp);
    printf("\nTransmitting %d bytes of PID-DTC\r\n", resp_payload.resp_len);
    //printf("Transmitting %d bytes of PID-DTC\r\n", resp_payload.resp_len);

    /* Change to Xmit mode */
    gpio_put(RS485_DIR, HIGH);

    /* Transmit header */
    send_byte(resp_hdr.soh);
    sleep_ms(1);
    send_byte(resp_hdr.cmd);
    sleep_ms(1);
    send_byte(resp_hdr.addr);
    sleep_ms(1);
    send_byte(resp_hdr.grp);
    sleep_ms(1);

    printf("\r\n");
    /* Transmit payload */
    for (i = 0; i < resp_payload.resp_len; i++)
    {
        send_byte(resp_payload.pid_dtc_resp[i]);
        sleep_ms(10);
    }
    printf("\r\n Information Requested is \r\n");
    /*for (i = 0; i < resp_payload.resp_len; i++)
    {
        printf("%c", resp_payload.pid_dtc_resp[i]);
        sleep_ms(5);
    }*/
    //get_last_reset_count(&Reset_Count_Current);
    sleep_ms(5);
    printf("\r\n");
    /* Transmit trailer */
    sleep_ms(1);
    send_byte(resp_trailer.eot);
    sleep_ms(1);
    send_byte(resp_trailer.csum[0]);
    sleep_ms(1);
    send_byte(resp_trailer.csum[1]);
    sleep_ms(4);
    /* Change to Recv mode */
    gpio_put(RS485_DIR, LOW);

    return rc;
}
///////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////

/* Prepares Hanover header alongwith checksum and transmits response to PID controller
   Transmitting frame should follow the sequence below
   Enable XMIT line
   Transmit frame
   Disable XMIT line, go back to RECV mode
   */
uint8_t Transmit_pid_dtc_Error_Response(void)
{
    uint8_t rc = RC_SUCCESS;
    uint32_t i = 0;

    //memset(resp_payload.pid_dtc_resp,0,sizeof(resp_payload.pid_dtc_resp));
    
    printf("\nin error response transmit function\n");
    printf("resp_hdr.soh = %d\n",resp_hdr.soh);
    printf("resp_hdr.cmd = %d\n",resp_hdr.cmd);
    printf("resp_hdr.addr = %d\n",resp_hdr.addr);
    printf("resp_hdr.grp = %d",resp_hdr.grp);
    printf("\nTransmitting %d bytes of PID-DTC\r\n", resp_payload.resp_len);

    /* Change to Xmit mode */
    gpio_put(RS485_DIR, HIGH);

    /* Transmit header */
    send_byte(resp_hdr.soh);
    sleep_ms(1);
    send_byte(resp_hdr.cmd);
    sleep_ms(1);
    send_byte(resp_hdr.addr);
    sleep_ms(1);
    send_byte(resp_hdr.grp);
    sleep_ms(1);

    printf("\r\n");
    //memset(resp_payload.pid_dtc_resp,0,sizeof(resp_payload.pid_dtc_resp));
    for(i = 0;i < sizeof(resp_payload.pid_dtc_resp);i++)
    {
        resp_payload.pid_dtc_resp[i] = 0;
    }
    i=0;
    resp_payload.pid_dtc_resp[i] = '0'; //Send Error as Output
    resp_payload.resp_len = 1;
    /* Transmit payload */
    for (i = 0; i < resp_payload.resp_len; i++)
    {
        send_byte(resp_payload.pid_dtc_resp[i]);
        sleep_ms(10);
    }
    /*for (i = 0; i < resp_payload.resp_len; i++)
    {
        printf("%c", resp_payload.pid_dtc_resp[i]);
        sleep_ms(5);
    }*/
    //get_last_reset_count(&Reset_Count_Current);
    sleep_ms(5);
    printf("\r\n");
    prepare_trailer();
    /* Transmit trailer */
    sleep_ms(1);
    send_byte(resp_trailer.eot);
    sleep_ms(1);
    send_byte(resp_trailer.csum[0]);
    sleep_ms(1);
    send_byte(resp_trailer.csum[1]);

    sleep_ms(5);
    /* Change to Recv mode */
    gpio_put(RS485_DIR, LOW);

    return rc;
}
/* Initialize pid_dtc_info structure with default values */
uint8_t init_pid_dtc(void)
{
    uint8_t rc = RC_SUCCESS;

    memset(&pid_dtc, 0, sizeof(pid_dtc));

    memcpy(pid_dtc.cust_name, DEFAULT_CUST_NAME, strlen(DEFAULT_CUST_NAME));
    memcpy(pid_dtc.order_no, DEFAULT_ORDER_NO, strlen(DEFAULT_ORDER_NO));
    memcpy(pid_dtc.bus_type, DEFAULT_BUS_TYPE, strlen(DEFAULT_BUS_TYPE));
    memcpy(pid_dtc.bus_build, DEFAULT_BUS_BUILD, strlen(DEFAULT_BUS_BUILD));
    memcpy(pid_dtc.language, DEFAULT_LANG, strlen(DEFAULT_LANG));
    pid_dtc.max_temp = 85;
    pid_dtc.min_temp = 22;
    pid_dtc.curr_temp = 39;
    pid_dtc.max_batt = 26;
    pid_dtc.min_batt = 18;
    pid_dtc.curr_batt = 24;
    pid_dtc.reset_count = 0;

    memcpy(pid_dtc.fw_ver, DEFAULT_FW_VER, strlen(DEFAULT_FW_VER));
    memcpy(pid_dtc.bootloader_ver, DEFAULT_BOOTLOADER_VER, strlen(DEFAULT_BOOTLOADER_VER));
    memcpy(pid_dtc.hw_ver, DEFAULT_HW_VER, strlen(DEFAULT_HW_VER));
    memcpy(pid_dtc.fw_flash_date, DEFAULT_FW_FLASH_DATE, strlen(DEFAULT_FW_FLASH_DATE));
    memcpy(pid_dtc.fw_build_date, DEFAULT_FW_BUILD_DATE, strlen(DEFAULT_FW_BUILD_DATE));
    memcpy(pid_dtc.serial_no, DEFAULT_SERIAL_NO, strlen(DEFAULT_SERIAL_NO));
    ///////////////////////////////////////////////////////////////////////////////////////
    memcpy(pid_dtc.fw_update_status, DEFAULT_FIRMWARE_UPDATE_STATUS, strlen(DEFAULT_FIRMWARE_UPDATE_STATUS));
    memcpy(pid_dtc.art_no_sign_lev, DEFAULT_ARTICLE_NUMBER_SIGN_LEVEL, strlen(DEFAULT_ARTICLE_NUMBER_SIGN_LEVEL));
    memcpy(pid_dtc.meta_dat_ver, DEFAULT_META_DATA_VERSION, strlen(DEFAULT_META_DATA_VERSION));
    memcpy(pid_dtc.test_date, DEFAULT_TEST_DATE, strlen(DEFAULT_TEST_DATE));
    memcpy(pid_dtc.font_library_ver,DEFAULT_FONT_LIBRARY_VERSION,strlen(DEFAULT_FONT_LIBRARY_VERSION));
    //////////////////////////////////////////////////////////////////////////////////////////

    /* Get serial no from hardware and firmware version from file */
    pico_get_unique_board_id_string(pid_dtc.serial_no,
                                    sizeof(pid_dtc.serial_no) - 1);
    // printf("Serial no: %s\r\n", pid_dtc.serial_no);
    memcpy(pid_dtc.fw_ver, FIRMWARE_VERSION, strlen(FIRMWARE_VERSION));

    // Init temperature sensor
    init_temperature_sensor();

    // printf("CPU temperature = %d\n", read_cpu_temperature());

    return rc;
}

/*
 * read_reset_block(): Issues single sector read
 *
 */
static uint8_t read_reset_block(RESET_BLOCK_INFO *pBlock, uint32_t offset)
{
    uint8_t rc = RC_SUCCESS;

    if (!pBlock || offset > (MAX_RESET_BLOCKS * MAX_RESET_BLOCK_SIZE))
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    offset += START_RESET_BLOCK_ADDR;
    readFlash(offset, (uint8_t *)pBlock, sizeof(*pBlock));

    return rc;
}

uint32_t  get_last_reset_count(uint32_t *pResetCount)
{
    uint8_t rc = RC_NO_DATA;
    int i;

    if (!pResetCount)
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    saved_reset_block_info.in_use = BLOCK_FREE;
    saved_reset_block_info.reset_count = 0;

    for (i = 0; i < MAX_RESET_BLOCKS; i++, curr_reset_block_offset += MAX_RESET_BLOCK_SIZE)
    {
        reset_block_info.in_use = BLOCK_FREE;
        reset_block_info.reset_count = 0;
        /* Read current flash block */
        if (read_reset_block(&reset_block_info, curr_reset_block_offset) == RC_SUCCESS)
        {
            if (reset_block_info.in_use == VALID_BLOCK_SIGNATURE)
            {
                memcpy(&saved_reset_block_info, &reset_block_info,
                       sizeof(saved_reset_block_info));
            }
            else if (reset_block_info.in_use == BLOCK_FREE)
                break;
        }
        else
        {
            rc = RC_FLASH_READ_ERROR;
            printf("Error reading reset block\n");
            break;
        }
    }

    if (i >= MAX_RESET_BLOCKS)
    {
        // Erase flash
        printf("Erasing reset block ...\n");
        uint32_t erase_address = START_RESET_BLOCK_ADDR;

        blockErase32k(erase_address);

        // Wait for operation to complete
        while (!chipready())
        {
            sleep_ms(1);
        }
        printf("Reset block erasing complete !\n");
        curr_reset_block_offset = 0;
    }

    if (saved_reset_block_info.in_use == VALID_BLOCK_SIGNATURE)
    {
        *pResetCount = saved_reset_block_info.reset_count;
        printf("\n saved_reset_block_info.reset_count = %d",saved_reset_block_info.reset_count);
        printf("\n saved_reset_block_info.reset_count in use = %d\n",saved_reset_block_info.in_use);
    }

    return rc;
}

/*
 * write_reset_block(): Issues multiple sector write
 *
 */
static uint8_t write_reset_block(RESET_BLOCK_INFO *pBlock, uint32_t offset)
{
    uint8_t rc = RC_SUCCESS;

    if (!pBlock || offset > (MAX_RESET_BLOCKS * MAX_RESET_BLOCK_SIZE))
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    offset += START_RESET_BLOCK_ADDR;

    writeFlash(offset, (uint8_t *)pBlock, sizeof(*pBlock));

    return rc;
}

/* Called on startup to increment reset count using wear leveling
   Reads current count from the flash, updates the local and stored count
   and writes it back to flash
   */



uint8_t update_reset_count(uint32_t reset_count)
{
    uint8_t rc = RC_SUCCESS;
    //uint32_t reset_count = 0;

    //printf("\nreset_count before get_last_reset_count() is %d",reset_count);

    // Get last reset count, increment it and write back
    get_last_reset_count(&reset_count);
    //printf("\nPrevious reset_count after get_last_reset_count () is %d",reset_count);
    ++reset_count;
    //printf("\n curr_reset_block_offset = %d",curr_reset_block_offset);
    if ((curr_reset_block_offset >= (MAX_RESET_BLOCKS * MAX_RESET_BLOCK_SIZE)))
    {
        // Erase flash
        printf("Erasing reset flash block ...\n");

        // Erase flash
        uint32_t erase_address = START_RESET_BLOCK_ADDR;

        blockErase32k(erase_address);

        // Wait for operation to complete
        while (!chipready())
        {
            sleep_ms(1);
        }
        printf("Reset block erasing complete !\n");
        curr_reset_block_offset = 0;
    } // erase flash
    
    if ((rc = read_reset_block(&reset_block_info, curr_reset_block_offset)) == RC_SUCCESS)
    {
         printf("Reading block at offset %d !\n", curr_reset_block_offset);
        //  Sanity check
        if (reset_block_info.in_use == BLOCK_FREE)
        {
            reset_block_info.in_use = VALID_BLOCK_SIGNATURE;
            reset_block_info.reset_count = reset_count;

            // Update
            if ((rc = write_reset_block(&reset_block_info, curr_reset_block_offset)) == RC_SUCCESS)
            {
                curr_reset_block_offset += MAX_RESET_BLOCK_SIZE;

                /*printf("Update successful, curr_reset_block_offset %d, msgLen = %d\n", curr_reset_block_offset,
                  saved_reset_block_info.msg_len);*/
                pid_dtc.reset_count = reset_count;
                rc = RC_SUCCESS;
            }
            else
            {
                printf("Reset block write failed\n");
            }
        } // block is free
    }     // read block successful
    else
        printf("Failed to read reset block at offset %d !\n", curr_reset_block_offset);

    return rc;
}

uint8_t calculate_checksum_pid_dtc(void)
{
    uint8_t rc = RC_SUCCESS;
    int i = 0;
    uint16_t checksumfinalvalueleft1 = 0, checksumfinalvalueright2 = 0;
    uint8_t Validate_checksum = 0;
    int checksum = 0;

    printf("\n In calculating Checksum function\n");
    // printf("\nDevice Id in Hex is = 0x%02X and Device Id in char is = %c\n",pUart->destId,((pUart->destId)+48));
    // printf("\nCommand Received in Hex is =0X%02X =%c\n",pUart->cmd);
    //checksum += pUart->destId + 48;
    //checksum += pUart->cmd + 48;
    /*resp_hdr.soh = RESP_SOH;
    resp_hdr.cmd = PID_DTC_GRP_CMD + '0';
    resp_hdr.addr = systemInfo.deviceId + '0';
    resp_hdr.grp = cmd;*/
    checksum += resp_hdr.cmd;
    //printf("\n value of %c is %d",resp_hdr.cmd,resp_hdr.cmd);
    checksum += resp_hdr.addr;
    //printf("\n value of %c is %d", resp_hdr.addr,resp_hdr.addr);
    checksum += resp_hdr.grp;
    //printf("\n value of %c is %d",resp_hdr.grp,resp_hdr.grp);
    i = 0;
    // printf("Buffer length = %d\n",  pUart->framing_buffer_index);
    for(int i = 0; i<resp_payload.resp_len; i++)
    {
        printf("%c",resp_payload.pid_dtc_resp[i]);
        sleep_ms(1);
    }
    i = 0;
    //printf("\n Initial Value of checksum is %d",checksum);
    while ((resp_payload.pid_dtc_resp[i])&&(i<resp_payload.resp_len))
    {
        checksum +=resp_payload.pid_dtc_resp[i];
        //checksum += pUart->framing_buffer[i];
        //printf("\n checksum after adding %c is %d",resp_payload.pid_dtc_resp[i],checksum);
        i = i + 1;
        sleep_ms(10);
    }
    // printf("Updated Buffer length = %d\n",  i);
    checksum += RESP_EOT;
    checksum = checksum % 256;
    Validate_checksum = (uint8_t)(0 - checksum);
    //printf("\n The Checksum after calculating 0-checksum from above in decimal is = %d",Validate_checksum);
    //printf("\n The Checksum after calculating 0-checksum from above in Hex is = 0x%02X",Validate_checksum);
    //printf("\nValue of checksum before dividing first value and second value is 0X%02X\n\n", Validate_checksum);
    checksumfinalvalueleft1 = Validate_checksum & 240; // bitwise OR operato
    checksumfinalvalueleft1 = checksumfinalvalueleft1 >> 4;
    if (checksumfinalvalueleft1 < 10)
    {
        checksumfinalvalueleft1 = (int)checksumfinalvalueleft1 + 48;
    }
    else if (checksumfinalvalueleft1 >= 10)
    {
        checksumfinalvalueleft1 = (int)checksumfinalvalueleft1 + 55;
    }
    checksumfinalvalueright2 = Validate_checksum & 15;
    if (checksumfinalvalueright2 < 10)
    {
        checksumfinalvalueright2 = (int)checksumfinalvalueright2 + 48;
    }
    else if (checksumfinalvalueright2 >= 10)
    {
        checksumfinalvalueright2 = (int)checksumfinalvalueright2 + 55;
    }

    //printf("\n XXThe Received value of Checksum is %c%c XX",pUart->csumBuf[0],pUart->csumBuf[1]);
    //printf("\n XXThe calculated value of checksum is %d and the Received value of checksum is %dXX",Validate_checksum,pUart->csum);
    //printf("\n XXLeftvlaue of checksum is %c and The Rightvalue of checksum is %cXX",(char)checksumfinalvalueleft1,(char)checksumfinalvalueright2);
    resp_trailer.csum[0] = checksumfinalvalueleft1;
    resp_trailer.csum[1] = checksumfinalvalueright2;
    // ToDo, verify checksum
    //if(pUart->csumBuf[0]==)

    return rc;
}

uint32_t Read_Voltage_Sensor(void)
{
    uint32_t result = 0;//result_in_uint32 = 0;
    //float result_in_float = 0;
    //float voltage_value = 0;
    int voltage = 15;
    /* 12-bit conversion, assume max value == ADC_VREF == 3.3 V */
    //const float conversionFactor = 3.3f / (1 << 12);

    //adc_set_temp_sensor_enabled(true);
    //adc_select_input(4);
    adc_gpio_init(27);
    adc_select_input(1);
    //float adc = (float)adc_read() * conversionFactor;
    //float result = 27.0f - (adc - 0.706f) / 0.001721f;
    
    //result_in_float = (float) adc_read();// read adc value form the sensor and assign the value to result of type 16 bit unsigned integer
    //result_in_uint32 = (uint32_t) adc_read();
    result = adc_read();
    if(result > 236 && result <= 241 )
    {
        voltage = 15;
    }
    else if(result > 241 && result <= 245)
    {
        voltage = 16;
    }
    else if(result > 245 && result <= 250)
    {
        voltage = 17;
    }
    else if(result > 250 && result <= 255)
    {
        voltage = 18;
    }
    else if(result > 255 && result <= 261)
    {
        voltage = 19;
    }
    else if(result>261&&result<=262)
    {
        voltage = 20;
    }
    else if((result>262) && (result <= 269))
    {
        voltage = 21;
    }
    else if((result>269) && (result <= 274))
    {
        voltage = 22;
    }
    else if((result>274) && (result <=279))
    {
        voltage = 23;
    }
    else if((result>279) && (result <= 283))
    {
        voltage = 24;
    }
    else if((result>283) && (result <= 289))
    {
        voltage = 25;
    }
    else if((result>289) && (result <= 291))
    {
        voltage = 26;
    }
    else if((result>291) && (result <= 297))
    {
        voltage = 27;
    }
    else if((result>297) && (result <= 302))
    {
        voltage = 28;
    }
    else if((result>302) && (result <= 306))
    {
        voltage = 29;
    }
    else if((result>306) && (result <= 310))
    {
        voltage = 30;
    }
    else if((result>310) && (result <= 315))
    {
        voltage = 31;
    }
    else if((result>315) && (result <= 321))
    {
        voltage = 32;
    }
    else if((result>321) && (result <= 324))
    {
        voltage = 33;
    }
    else if((result>324) && (result <= 330))
    {
        voltage = 34;
    }
    else if((result>330) && (result <= 334))
    {
        voltage = 35;
    }
    else if((result>334) && (result <= 339))
    {
        voltage = 36;
    }
    else if((result>239) && (result <= 344))
    {
        voltage = 37;
    }
    else if((result>344) && (result <= 348))
    {
        voltage = 38;
    }
    else if((result>348) && (result <= 353))
    {
        voltage = 39;
    }
    else if((result>353) && (result <= 357))
    {
        voltage = 40;
    }
    else if((result>357))
    {
        voltage = 41;
    }
    printf("\n result is %d", result);
    //printf("\nVoltage reading in float = %f, convertion factor = %f",result_in_float,conversionFactor);
    //printf("\nVoltage reading in uint32 is %d",result_in_uint32);
    //voltage_value = (result*conversionFactor)*100;
    //printf("\nVoltage value = %f",voltage_value);
    printf("\nvoltage is %d",voltage);
    return voltage;
}

uint32_t Write_data_Into_Flash(uint8_t *Input_Buffer, uint32_t Flash_Address_Location, uint32_t Data_Length)
{
    
    while (!chipready())
    {
        // Wait for chip to be ready
        ;
    }
    sectorErase(Flash_Address_Location);
    while (!chipready())
    {
        // Wait for chip to be ready
        ;
    }
    writeFlash(Flash_Address_Location, (uint8_t *)Input_Buffer, Data_Length);
    while (!chipready())
    {
        // Wait for chip to be ready
        ;
    }
    return RC_SUCCESS;
}
uint32_t Read_data_From_Flash(uint8_t *  Destination_Buffer, uint32_t Flash_Address_Location, uint32_t Data_Length)
{
   
    memset(readbuf,0,sizeof(readbuf));
    //printf("\n Data_Length is %d",Data_Length);
    //printf("\n FLASH_ADDRESS_LOCATION = %d", Flash_Address_Location);
    //printf("\n *Destination_Buffer = %d",Destination_Buffer);
    while (!chipready())
    {
        // Wait for chip to be ready
        ;
    }
    readFlash(Flash_Address_Location, (uint8_t *)&readbuf, Data_Length);
    //printf("\nreadbuf pointer is %d",&readbuf);
    Destination_Buffer =(uint8_t *) &readbuf;
    //printf("\n Destination_buffer_pointer is %d",Destination_Buffer);
    //printf("\n &Destination_buffer_pointer is %d",&Destination_Buffer);
    while (!chipready())
    {
        // Wait for chip to be ready
        ;
    }
    //readFlash(Flash_Address_Location, (uint8_t *)Destination_Buffer, Data_Length);
    /*printf("\ndata from flash in Destinatio buffer is \n%s\n ",Destination_Buffer);
    printf("\ndata from flash in readbuf is \n%s\n ",readbuf);
    printf("\n&data from flash in readbuf is \n%s\n ",&readbuf);
    printf("\n readbuf[0] = %c",readbuf[0]);
    printf("\n readbuf[58] = %c",readbuf[58]);
    printf("\n readbuf[57] = %c",readbuf[57]);
    printf("\n readbuf[58] in int is = %d",(int) readbuf[58]);
*/
    return RC_SUCCESS;
}


uint32_t Load_Product_Info_From_Flash(void)
{
    int i = 0 , return_value = 0;
    char temp_buffer_Product_Info[256] = {0};
    char *token1[11] = {0};
    {
        Read_data_From_Flash((uint8_t *)readbuf,PRODUCT_INFO_ADDR_LOCATION,sizeof(Flash_Memory_Buffer));
        //printf("\n charptr after read_data_From_Flash is %d",&readbuf);
        // printf("\n Read_data_From_Flash XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n %s\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",readbuf);
        i=0;
        while((readbuf[i]!=0xFF)&&(i < 255))
        {
            i++;
        }
        //printf("\n i= %d",i);
        //printf("\n value = %c",readbuf[i]);
        memcpy(temp_buffer_Product_Info,readbuf,i);
        // printf("\n Extracted data in temp buffer is \n%s",temp_buffer_Product_Info);
        token1[0] = strtok(temp_buffer_Product_Info, ",");
        // printf("\n data in token1[0] is %s",token1[0]);
        i = 1;
        while(i<7)
        {
            token1[i] = strtok(NULL, ",");
            // printf("\n data in token1[%d] is %s",i,token1[i]);
            i++;
        }
        // token1[7] = strtok(token1[0], ":");
        // token1[7] = strtok(NULL, ":");
        // //printf("\n token1[7] = %s", token1[7]);
        // token1[8] = strtok(token1[3], ":");
        // token1[8] = strtok(NULL, ":");
        // //printf("\n token1[8] = %s", token1[8]);
        // token1[9] = strtok(token1[4], ":");
        // token1[9] = strtok(NULL, ":");
        // //printf("\n token1[9] = %s", token1[9]);
        // token1[10] = strtok(token1[5], ":");
        // token1[10] = strtok(NULL, ":");
        // //printf("\n token1[10] = %s", token1[10]);
        // token1[11] = strtok(token1[6], ":");
        // token1[11] = strtok(NULL, ":");
        // printf("\n token1[11] = %s", token1[11]);
        // printf("\n data in Serial Number Field is token1[7] is = %s",token1[7]);
        // printf("\n data in Production Date Field token1[1] is = %s",token1[1]);
        // printf("\n data in Test Date Field token1[2] is = %s",token1[2]);
        // printf("\n data in Hardware Version Field token1[8] is = %s",token1[8]);
        // printf("\n data in Flash Update Status Field token1[9] is = %s",token1[9]);
        // printf("\n data in Article Number Sign Level Field token1[10] is = %s",token1[10]);
        // printf("\n data in Meta Data Field token1[11] is = %s",token1[11]);
        // memcpy(temp_buffer_Product_Info,token1[0],strlen(token1[0]));
        memcpy(pid_dtc.serial_no,token1[0],strlen(token1[0]));
        //printf("\n Set Seiral_Number_Field is %s",pid_dtc.serial_no);
        memcpy(pid_dtc.fw_flash_date,token1[1],strlen(token1[1]));
        //printf("\n Set fw_flash_date is %s",pid_dtc.fw_flash_date);
        memcpy(pid_dtc.test_date,token1[2],strlen(token1[2]));
        //printf("\n data in pid_dtc test date is %s",pid_dtc.test_date);
        memcpy(pid_dtc.hw_ver,token1[3],strlen(token1[3]));
        //printf("\n Set hw_ver is %s",pid_dtc.hw_ver);
        memcpy(pid_dtc.fw_update_status,token1[4],strlen(token1[4]));
        //printf("\n Set Flash_Update_Status Field is %s",pid_dtc.fw_update_status);
        memcpy(pid_dtc.art_no_sign_lev,token1[5],strlen(token1[5]));
        //printf("\n Set Article_Number_Sign_Level Field is %s",pid_dtc.art_no_sign_lev);
        memcpy(pid_dtc.meta_dat_ver,token1[6],strlen(token1[6]));
        //printf("\n Set Meta_dat_ver data structure is %s",pid_dtc.meta_dat_ver);
        /*printf("\n data printed XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX3");
        printf("\n data in pid_dtc Seiral_Number_Field is %s",pid_dtc.serial_no);
        printf("\n data in pid_dtc fw_flash_date is %s",pid_dtc.fw_flash_date);
        printf("\n data in pid_dtc test date is %s",pid_dtc.test_date);
        printf("\n data in pid_dtc.hw_ver is %s",pid_dtc.hw_ver);
        printf("\n data in pid_dtc Flash_Update_Status Field is %s",pid_dtc.fw_update_status);
        printf("\n data in pid_dtc Article_Number_Sign_Level Field is %s",pid_dtc.art_no_sign_lev);
        printf("\nMeta data version in pid_dtc.Meta_dat_ver data structure is %s",pid_dtc.meta_dat_ver);
        printf("\n data printed XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");*/
        return_value = RC_SUCCESS;
    }
        if(return_value == RC_SUCCESS)
        {
            i = 0;
            //printf("\r\n");
            while(resp_payload.pid_dtc_resp[i])
            {
                printf("%c",resp_payload.pid_dtc_resp[i]);
                i++;
            }
            printf("\n%d is i end of data",i);
            resp_payload.pid_dtc_resp[0] = 0x31;
        }
        else
        {
            return_value = RC_PID_DTC_WRITE_PRODUCT_ERROR;
            printf("NOT SUCCESS");
            resp_payload.pid_dtc_resp[0] = 0x30;
        }
        *token1 = NULL;
        return return_value;
}

uint32_t Load_Customer_Info_From_Flash(void)
{
    int i = 0,return_value = 0;
    char temp_buffer_Customer_Info[256] = {0};
    char *token1[10] = {0};
    Read_data_From_Flash((uint8_t *)readbuf,CUSTOMER_INFO_ADDR_LOCATION,sizeof(Flash_Memory_Buffer));
        printf("\n Read_data_From_Flash \n %s\n",readbuf);
        i=0;
        while((readbuf[i]!=0xFF)&&(i < 255))
        {
            i++;
        }
        memcpy(temp_buffer_Customer_Info,readbuf,i);
        printf("\n Extracted data in temp_buffer_Customer_Info = \n%s\n", temp_buffer_Customer_Info);
        /*for(i=0;i<=256;i++)
        {
            readbuf[i]= '\0';
        }*/
        sleep_ms(100);
        //printf("\n size of temp buf = %d",sizeof(temp_buffer_Customer_Info));
        memcpy(readbuf,temp_buffer_Customer_Info,sizeof(temp_buffer_Customer_Info));
        //printf("\n read buf = %s",readbuf);
        //memset(temp_buffer_Customer_Info,0,sizeof(temp_buffer_Customer_Info)); // first clear temp buffer
        token1[0] = strtok(temp_buffer_Customer_Info, ",");
        /*token1[1] = strtok(NULL,",");
        token1[2] = strtok(NULL,",");
        token1[3] = strtok(NULL,",");
        token1[4] = strtok(NULL,",");*/
        //token1[0] = readbuf;
        //printf("\n token1[0] = %s",token1[0]);
        //memset(temp_buffer_Customer_Info,0,sizeof(temp_buffer_Customer_Info)); // first clear temp buffer
        //token1[0] = readbuf;
        //printf("\n token1[0] = %s",token1[0]);
        //printf("\n read buf = %s",readbuf);
        //printf("\n temp_buffer_Customer_Info = %s",temp_buffer_Customer_Info);
        //printf("\n token1[0] is = %s",token1[0]);
        i=1;
        while((i<5))
        {
        token1[i] = strtok(NULL, ",");
        //printf("\n token1[%d] is = %s",i,token1[i]);
        i++;
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        //memset(temp_buffer_Customer_Info,0,sizeof(temp_buffer_Customer_Info)); // first clear temp buffer
        printf("\n");
        memcpy(pid_dtc.cust_name,token1[0],strlen(token1[0]));
        memcpy(pid_dtc.order_no,token1[1],strlen(token1[1]));
        memcpy(pid_dtc.bus_type,token1[2],strlen(token1[2]));
        memcpy(pid_dtc.bus_build,token1[3],strlen(token1[3]));
        memcpy(pid_dtc.language,token1[4],strlen(token1[4]));
        // token1[5] = strtok(token1[0],":");
        // token1[5] = strtok(NULL,":");
        //printf("\n token1[5] = %s", token1[5]);
        // memcpy(pid_dtc.cust_name,token1[5],strlen(token1[5]));
        //printf("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n data in pid_dtc Customer_Name_Field is %s",pid_dtc.cust_name);
        // token1[6]=strtok(token1[1],":");
        // token1[6]=strtok(NULL,":");
        //printf("\n token1[6] = %s",token1[6]);
        // memcpy(pid_dtc.order_no,token1[6],strlen(token1[6]));
        //printf("\n data in pid_dtc Order_Number_Field is %s",pid_dtc.order_no);
        // token1[7]=strtok(token1[2],":");
        // token1[7]=strtok(NULL,":");
        //printf("\n token1[8] = %s",token1[7]);
        // memcpy(pid_dtc.bus_type,token1[7],strlen(token1[7]));
        //printf("\n data in pid_dtc bus_Type_Field is %s", pid_dtc.bus_type);
        // token1[8]=strtok(token1[3],":");
        // token1[8]=strtok(NULL,":");
        // memcpy(pid_dtc.bus_build,token1[8],strlen(token1[8]));
        //printf("\n data in pid_dtc bus_build_Field is %s",pid_dtc.bus_build);
        // token1[11]=strtok(token1[4],":");
        // token1[11]=strtok(NULL,":");
        // memcpy(pid_dtc.language,token1[11],strlen(token1[11]));
        //printf("\n data in pid_dtc Language_Field is %s\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",pid_dtc.language);
        //printf("\n Successfully Set Customer Information\n");
       
        return_value = RC_SUCCESS;
        if(return_value == RC_SUCCESS)
        {
            i = 0;
            printf("\r\n");
            while(resp_payload.pid_dtc_resp[i])
            {
                printf("%c",resp_payload.pid_dtc_resp[i]);
                i++;
            }
            printf("\n%d is i end of data",i);
            resp_payload.pid_dtc_resp[0] = 0x31;
        }
        else
        {
            return_value = RC_PID_DTC_WRITE_CUSTOMER_ERROR;
            printf("NOT SUCCESS");
            resp_payload.pid_dtc_resp[0] = 0x30;
        }
        *token1 = NULL;
        //prepare_customer_info();
        return return_value;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t process_pid_dtc_error_command(uint8_t cmd)
{
    uint8_t rc = RC_PID_DTC_SET_REQUEST_ERROR;
    prepare_hdr(cmd);
    return rc;
}
//#endif /* ENABLE_PID_DTC */
