//
// This file implements functions for reading LDR
//
#include <stdio.h>
#include <string.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/pwm.h"
#include "hardware/adc.h"
#else
#include <stdint.h>
#endif
#include "main.h"
#include "init.h"
#include "ldr.h"

int getLdrValue()
{
    int16_t result=0;

#ifdef ENABLE_PICO
    adc_init();
    adc_gpio_init(26);
    
    // Select ADC input 0 (GPIO26)
    adc_select_input(0);
    result = adc_read();
#endif
    
    return result;
}
