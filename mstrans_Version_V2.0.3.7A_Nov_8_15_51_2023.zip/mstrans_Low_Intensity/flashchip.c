#include "proc-card.h"
#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "flashchip.h"

#define SPI_FLASH_CLOCK_SPEED (2000 * 1000)

#define SPI_FLASH_MOSI_SIGNAL   11 // GPIO 11 SPI1 TX PIN 15
#define SPI_FLASH_MISO_SIGNAL   12 // GPIO 12 SPI1 RX PIN Number 16
#define SPI_FLASH_SCLK_SIGNAL   10 // GPIO 10 SPI1 CLK PIN 14
#define SPI_FLASH_CS_SIGNAL     5 // GPIO 5 SPI 0 Chip Select PIN 7
#define SPI_FLASH_HOLD_SIGNAL   6 // GPIO 6 SPI0 SCLK PIN 9

void init_flash_chip()
{
    spi_init(spi1, SPI_FLASH_CLOCK_SPEED);

    gpio_set_function(SPI_FLASH_MOSI_SIGNAL, GPIO_FUNC_SPI);
    gpio_set_function(SPI_FLASH_MISO_SIGNAL, GPIO_FUNC_SPI);
    gpio_set_function(SPI_FLASH_SCLK_SIGNAL, GPIO_FUNC_SPI);

    gpio_init(SPI_FLASH_CS_SIGNAL);
    gpio_set_dir(SPI_FLASH_CS_SIGNAL, GPIO_OUT);

    gpio_init(SPI_FLASH_HOLD_SIGNAL);
    gpio_set_dir(SPI_FLASH_HOLD_SIGNAL, GPIO_OUT);

    // Deselect HOLD line
    gpio_put(SPI_FLASH_HOLD_SIGNAL, 1);
}

void chipwakeup()
{
    uint8_t devInfo[1] = {0};
    uint8_t cmdBuf[4] = {POWER_UP, 0x00, 0x00, 0x00};

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Get device id    
    spi_read_blocking (spi1, POWER_UP, devInfo, sizeof(devInfo));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
}

uint8_t chipready()
{
    uint8_t rc = 0;
    uint8_t devInfo[1] = {0};
    uint8_t cmdBuf[] = {READ_STATUS};

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Get chip status data copied in scroll buffer
    spi_read_blocking (spi1, READ_STATUS, devInfo, sizeof(devInfo));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);

    rc = !(devInfo[0] & 0x01);

    return rc;
}

void get_chipinfo(uint8_t *pManufacturer, 
    uint8_t *pDeviceId)
{
    uint8_t devInfo[2] = {0};
    uint8_t cmdBuf[4] = {READ_DEVINFO, 0x00, 0x00, 0x00};

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Get Manufacturer id and device id    
    spi_read_blocking (spi1, 0x00, devInfo, sizeof(devInfo));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);

    if (pManufacturer)
        *pManufacturer = devInfo[0];
    
    if (pDeviceId)
        *pDeviceId = devInfo[1];

    return;
}


uint8_t readStatus()
{
    uint8_t readStatus = READ_STATUS;
    uint8_t status = 0;
   
    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, &readStatus, sizeof(readStatus));
    spi_read_blocking (spi1, READ_STATUS, &status, sizeof(status));
 
    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);

    return status;
}

void writeEnable()
{
    uint8_t writeOp = WRITE_ENABLE;

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    // Enable write operation
    spi_write_blocking(spi1, &writeOp, sizeof(writeOp));
   
    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);


}

void writeDisable()
{
    uint8_t writeOp = WRITE_DISABLE;

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    // Disable write operation
    spi_write_blocking(spi1, &writeOp, sizeof(writeOp));
    
    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
}

void chipErase()
{
    uint8_t cmdBuf[1] = {CHIP_ERASE};

    while (!chipready())
        ;

    // Enable write operation on flash
    writeEnable();

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
    
    // Disable write operation on flash
    writeDisable();
}

void blockErase32k(uint32_t address)
{
    uint8_t cmdBuf[4] = {BLOCK_ERASE_32K, 0x00, 0x00, 0x00};

    cmdBuf[1] = ((address >> 16) & 0xff);
    cmdBuf[2] = ((address >> 8) & 0xff);
    cmdBuf[3] = (address & 0xff);

    while (!chipready())
        ;

    // Enable write operation on flash
    writeEnable();

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
    
    // Disable write operation on flash
    writeDisable();
}

void blockErase64k(uint32_t address)
{
    uint8_t cmdBuf[4] = {BLOCK_ERASE_64K, 0x00, 0x00, 0x00};

    cmdBuf[1] = ((address >> 16) & 0xff);
    cmdBuf[2] = ((address >> 8) & 0xff);
    cmdBuf[3] = (address & 0xff);

    while (!chipready())
        ;

    // Enable write operation on flash
    writeEnable();

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
    
    // Disable write operation on flash
    writeDisable();
}

void sectorErase(uint32_t address)
{
    uint8_t cmdBuf[4] = {SECTOR_ERASE, 0x00, 0x00, 0x00};

    cmdBuf[1] = ((address >> 16) & 0xff);
    cmdBuf[2] = ((address >> 8) & 0xff);
    cmdBuf[3] = (address & 0xff);

    while (!chipready())
        ;

    // Enable write operation on flash
    writeEnable();

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
    
    // Disable write operation on flash
    writeDisable();
}

void readFlash(uint32_t address, uint8_t *pBuf, uint32_t len)
{
    uint8_t cmdBuf[4] = {READ_DATA, 0x00, 0x00, 0x00};

    cmdBuf[1] = ((address >> 16) & 0xff);
    cmdBuf[2] = ((address >> 8) & 0xff);
    cmdBuf[3] = (address & 0xff);

    while (!chipready())
        ;

    // Select chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 0);

    spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

    spi_read_blocking(spi1, 0x00, pBuf, len);

    // Deselect chip
    gpio_put(SPI_FLASH_CS_SIGNAL, 1);
}

void writeFlash(uint32_t address, uint8_t *pBuf, uint32_t buflen)
{
    uint8_t cmdBuf[4] = {WRITE_PAGEPROGRAM, 0x00, 0x00, 0x00};
    uint32_t offset = 0;
    uint32_t len;

    // Wait for previous operation to complete
    while (!chipready())
        ;

    while (buflen)
    {
        len = (buflen > MAX_PAGE_SIZE) ? MAX_PAGE_SIZE : buflen;

        cmdBuf[1] = ((address >> 16) & 0xff);
        cmdBuf[2] = ((address >> 8) & 0xff);
        cmdBuf[3] = (address & 0xff);

        // Enable write operation on flash
        writeEnable();

        // Select chip
        gpio_put(SPI_FLASH_CS_SIGNAL, 0);

        // Perform write
        spi_write_blocking(spi1, cmdBuf, sizeof(cmdBuf));

        spi_write_blocking(spi1, &pBuf[offset], len);

        // Deselect chip
        gpio_put(SPI_FLASH_CS_SIGNAL, 1);

        writeDisable();

        // Wait for write operation to complete
        while (!chipready())
            ;

        buflen -= len;
        offset += len;
        address += len;
    }
}
