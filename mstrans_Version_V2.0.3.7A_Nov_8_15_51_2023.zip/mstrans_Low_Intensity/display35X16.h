//
// This file has function prototypes for Display processing functions
//

#ifndef __DISPLAY35X16__
#define __DISPLAY35X16__

//#ifdef ENABLE_35X16
//#define MAX_BOARDS      4
//#define DISPLAY_WIDTH_IN_COLUMNS ((35 * MAX_BOARDS) + 4)  //144
void init_led_driver(void);
void process_display();
//#endif 
#endif // __UART__