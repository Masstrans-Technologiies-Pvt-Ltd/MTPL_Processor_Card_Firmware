//
// This file has function prototypes for Display processing functions
//

#ifndef __DISPLAY__
#define __DISPLAY__

#define MAX_BOARDS      4
#define DISPLAY_WIDTH_IN_COLUMNS ((32 * MAX_BOARDS) + 4)

#define SCROLL_CHECK_TIME 20 // In msec  

void init_led_driver(void);
void process_display();

#endif // __UART__
