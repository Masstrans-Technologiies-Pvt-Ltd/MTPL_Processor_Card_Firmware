#include <stdio.h>
#include <string.h>
#ifdef ENABLE_PICO
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/structs/spi.h"
#include "hardware/spi.h"
#include "hardware/pwm.h"
#include "hardware/uart.h"
#include "hardware/adc.h"
#include "pico/multicore.h"
#ifdef ENABLE_WATCHDOG
#include "hardware/watchdog.h"
#endif
#else
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <stdint.h>
#include <ncurses.h>
#endif
#include "hvrprot.h"
#include "display.h"
#include "main.h"
#include "uart.h"
#include "init.h"
#include "deviceid.h"
#include "proc-card.h"
#ifdef ENABLE_PID_DTC
#include "pid_dtc.h"
#endif

SYSTEM_INFO systemInfo = {0};

#define FLAG_VALUE 0xfeed
#define BOARD_TYPE 0
//extern int BOARD_TYPE =0;
//extern uint8_t Board140X16 = 1, Board128X16 = 0, Board96X16 = 0;
//int Chip_Chipone_Configuration_To_Max_Intensity(uint8_t board_type);
 
#ifndef ENABLE_PICO
int quitTime = 0;
uint8_t *fptr = NULL;
pthread_t uart_thread = 0;
#endif

#ifdef ENABLE_WATCHDOG
//
// Each thread tracks the other's progress
// Only if both are moving will the watchdog be updated
//
volatile uint32_t display_currWatchCount = 0;
volatile uint32_t display_prevWatchCount = 0;
volatile uint32_t uart_currWatchCount = 0;
volatile uint32_t uart_prevWatchCount = 0;

#endif

#ifndef ENABLE_PICO
void *uart_thread_function( void *ptr )
{
    process_uart();

    return NULL;
}

uint8_t *getInputFile(char *fname)
{
    FILE *fp;
    int fsize;
    uint8_t *ptr = NULL;
    int maxRows, maxCols;

    if ((fp = fopen(fname, "rb")))
    {
        (void)fseek(fp, 0L, SEEK_END);
        fsize = ftell(fp);
        (void)fseek(fp, 0L, SEEK_SET);
        
        ptr = (uint8_t *)malloc(fsize);
        if (ptr)
        {
            maxRows = MAX_ROWS;
            maxCols = fsize / MAX_ROWS;

            printf("Max rows = %d, Max Columns = %d\n", maxRows, maxCols*8);

            if (fread(ptr, 1, fsize, fp) != fsize)
            {
                printf("Error %d reading file %s\n", errno, fname);
            }
        }

        fclose(fp);
    }

    return ptr;
}

#endif

// UART Runs on CORE1
void uart_core_entry()
{
#ifdef ENABLE_PICO
    multicore_fifo_push_blocking(FLAG_VALUE);
 
    uint32_t g = multicore_fifo_pop_blocking();
 
    if (g == FLAG_VALUE)
        process_uart();
#else
    pthread_create( &uart_thread, NULL, uart_thread_function, (void*) NULL);
#endif
}
// Run Repeating timer for working hour count
/*variable*/
uint32_t work_hour_count = 0;
extern PID_DTC_INFO pid_dtc;
bool increment_work_hour_count(struct repeating_timer *t)
{
    work_hour_count ++;
    if(work_hour_count == 60)
    {
    pid_dtc.work_hour = pid_dtc.work_hour + 1;
    work_hour_count = 0;
    if(pid_dtc.work_hour == 100)
    {
    pid_dtc.work_hour = 0;
    }
    }
    //printf("\n work_hour_count = %d",work_hour_count);
    //led_value = 1 - led_value;
    // led_value = ~led_value;
    //gpio_put(DEBUG_LED, led_value);
    return true;
}
// Display runs on CORE0 
void run_cores() 
{
#ifdef ENABLE_PICO
    multicore_launch_core1(uart_core_entry);
 
    // Wait for it to start up
    uint32_t g = multicore_fifo_pop_blocking();
 
    if (g == FLAG_VALUE)
    {
        multicore_fifo_push_blocking(FLAG_VALUE);

        process_display();
    }
#else
    // Start thread to handle UART
    uart_core_entry();

    process_display();
#endif
 
    return;
}

void flash_debug_led()
{
    while (1)
    {
#ifdef ENABLE_PICO
        gpio_put(DEBUG_LED, HIGH);
        sleep_ms(500);
        
        gpio_put(DEBUG_LED, LOW);
        sleep_ms(500);        
#else
        printf(".");
        fflush(stdout);
        usleep(55000);
#endif
    }
}

#ifdef ENABLE_WATCHDOG
void display_watchdog_update()
{
    display_currWatchCount++;
    if (uart_currWatchCount != display_prevWatchCount)
    {
        //printf("DWD\r\n");
        watchdog_update();
        display_prevWatchCount = uart_currWatchCount;
    }
}

void uart_watchdog_update()
{
    uart_currWatchCount++;
    if (display_currWatchCount != uart_prevWatchCount)
    {
        //printf("UWD\r\n");
        watchdog_update();
        uart_prevWatchCount = display_currWatchCount;
    }
}
#endif
#ifdef ENABLE_PICO
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// This Function Identifies the board Type and returns the board number after Identifying /////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* Returns 0 when no board is identified
    Retuens 1 when 140X16 is identified
    Returns 2 when 128X16 is identified
    Returns 3 when 96X16 is identified */
void spi_empty_channel_with(uint8_t wrData_1)
{
    int i = 0;
    for(i=0;i<550;i++)
    {
        spi_write_blocking(spi_default,&wrData_1,1);
        sleep_us(1000);
    }
}
uint8_t Identify_Board_Type(void)
{
        uint8_t rxData =0x00, wrData = 0x00,Temp_Buf_Devid[100] = {0};
        int i = 0,capture_flag = 0;
            //code block for 140X16 128X16 and 96X16 board type identification
            sleep_ms(100);
            for(i=0;i<550;i++)
            {
                spi_write_blocking(spi_default,&wrData,1);
                sleep_us(1000);
            }
            for(i=0;i<=50;i++)
        {
        //-----------XXXXXXXXXXXXXXX-------------------XXXXXXXXXXXXXX--------------------/////////////
            rxData = 0xFF;
            if (spi_read_blocking(spi_default, 0x55, &rxData, 1) == 1)
            {
                //printf("Read value 0x%02X , at i = %d \n",rxData, i);
                if (rxData == 0x55)
                {
                    printf("Display cleared after %d counts....\n", i);
                    //done = 1;
                    break;
                }
                if((rxData == 0xaa)&&(i==6)&&(rxData < 0xFF))
                {
                    //printf("\r Value of i is %d rxData Loading in rxData6",i);

                    printf("\r The Connected board is 140X16");
                    return (1);
                    break;
                }
            }
        }
            init_spi_manually();
            manual_spi_write_register1(0xc007, 9, 4);
            //manual_spi_write_register1(0x0000, 9, 4);
            init_spi_6000();
            for(i=0;i<=100;i++)
            {
                //-----------XXXXXXXXXXXXXXX-------------------XXXXXXXXXXXXXX--------------------/////////////
                rxData = 0xFF;
                if (spi_read_blocking(spi_default, 0x55, &rxData, 1) == 1)
                {
                    //printf("Read value 0x%02X , at i = %d \n",rxData, i);
                    Temp_Buf_Devid[i] = rxData;

                }
            }
            for(i=0; i < 99; i++)
            {
                if(Temp_Buf_Devid[i] != Temp_Buf_Devid[i+1])
                {
                    capture_flag = i;
                }
            }
        //printf("\n XXXXXXXXXXXXXXXXXXXXXXX capture_flag= %d XXXXXXXXXXXXXXXXXXXXXX",capture_flag);
        sleep_ms(500);
        // exact capture_flag value = 58
        if((capture_flag >= 56)&&(capture_flag <= 62))
        {
            printf("\n The Connected Board is 128X16");
            return(2);
        }
        // exact capture_flag value = 42 for some boards and 43 for someother
        else if((capture_flag >= 40)&&(capture_flag <= 45))
        {
            printf("\n The Connected Board is 96X16");
            return(3);
        }
        else if((capture_flag == 0))
        {
            printf("\r Unable to read signals from Board Please check the connections");
            sleep_ms(500);
            return(0);
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        //sleep_ms(500);    
        return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////// Board Identification Code Compleats here   ///////////////////////////////////////////////////////////////////////

#endif

#ifdef ENABLE_PICO
#define MAX_PROGRAMMING_CLOCKS 256

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void manual_spi_write_register1(uint16_t config, int num_chips, int num_boards)
{
    uint16_t state, shift_count = 0;
    uint16_t ch;
    int strobe_limit = 0;
    int clock_count = num_chips*num_boards*16;
    int set_count = 0;
    int max_sets = 1, loop_count;

    // printf("input clock_count = %d\r\n", clock_count);

    gpio_put(LED_DRIVER_BLANK_SIGNAL, 1); // First make OE High as per the ICND8390 Datasheep for Register 1 write
    gpio_put(LED_DRIVER_STROBE_SIGNAL, 0); // Trigger strobe pulse Make Low*/

    for (set_count = 0; set_count < max_sets; set_count++)
    {
        // Send Write enable before writing register value
        sent_register_write_Enable_Command();

        sleep_us(1);

        shift_count = 0;
        /*
        loop_count = (clock_count >= MAX_PROGRAMMING_CLOCKS) ? MAX_PROGRAMMING_CLOCKS/16 :
            clock_count/16;

        strobe_limit = (clock_count >= MAX_PROGRAMMING_CLOCKS) ? (MAX_PROGRAMMING_CLOCKS - 4) :
            (clock_count-4);
        */
       loop_count = num_chips*num_boards;
       strobe_limit = clock_count - 4;

        // printf("Loop count %d, Strobe limit %d\r\n", loop_count, strobe_limit);

        for (int k = 0; k < loop_count; k++)
        {
            ch = config;
            sleep_us(5);
            for (uint8_t bit = 0; bit <= 15; bit++)
            {
                if (ch & (0x8000 >> bit))
                {
                    // High data bit
                    state = 1;
                }
                else
                {
                    // Low data bit
                    state = 0;
                }

                // sending the state data to SIN PIN and giving a clock pulse
                gpio_put(LED_DRIVER_MOSI_SIGNAL, state);
                //sleep_us(1);
                for (int j = 0; j < 5; j++)
                    ;
                gpio_put(LED_DRIVER_SCLK_SIGNAL, 1);
                //sleep_us(1);
                for (int j = 0; j < 5; j++)
                    ;
                gpio_put(LED_DRIVER_SCLK_SIGNAL, 0);
                //sleep_us(1);
                for (int j = 0; j < 5; j++)
                    ;
                shift_count = shift_count + 1;
                if(shift_count == strobe_limit)
                {
                    //sleep_us(170);
                    gpio_put(LED_DRIVER_STROBE_SIGNAL, 1); // Trigger strobe pulse make High
                }
            }
        }
        
        clock_count -= MAX_PROGRAMMING_CLOCKS;

        gpio_put(LED_DRIVER_STROBE_SIGNAL, 0); // Trigger strobe pulse Make Low*/
        gpio_put(LED_DRIVER_SCLK_SIGNAL, 0);
    }
    //sleep_us(100);
    gpio_put(LED_DRIVER_MOSI_SIGNAL, 0);

    //sleep_us(100);
//    gpio_put(LED_DRIVER_BLANK_SIGNAL, 0); // again make OE BLANK _SIGNAL LOW

}

int main() 
#else
int main(int argc, char **argv) 
#endif
{
#ifndef ENABLE_PICO
    char *fname = NULL;
#ifdef DISPLAY_ONLY_OPTION
    uint8_t displayOnly = 0;
#endif

    switch (argc)
    {
        case 1:
            fname = "banner.txt";
            break;

        case 2:
            fname = argv[1];
            break;

        default:
#ifdef DISPLAY_ONLY_OPTION
        case 3:
            if (!strncmp(argv[2], "-d", 2) || !strncmp(argv[2], "-D", 2))
                displayOnly = 1;
            fname = argv[1];
#else
            fname = argv[1];
#endif
            break;
    }

    printf("Using %s as the input file\n", fname);

    // UART is simulated by reading input from a file
    init_uart(fname);

    fptr = getInputFile(fname);

	initscr();			/* Start curses mode 		  */

#else
    uint8_t BoardType=0;
    int Iteration = 0,Board_Type_Identified_Value[3] = {0,0,0};


    stdio_init_all();
    init_gpio();
    init_uart();
    init_adc();
    init_spi();
    init_pwm();
    sleep_ms(1000);
    init_led_driver();
    init_led_driver_signals();
    sleep_ms(5000);
    for(Iteration=0;Iteration < Identification_Iteration; Iteration++)
    {
        //BoardType = Identify_Board_Type(); // board type is identified here
        Board_Type_Identified_Value[Iteration] = Identify_Board_Type(); // board type is identified here
        sleep_ms(10);
        printf("\n %d times\n\n",Iteration);
    }
    printf("\n values = %d ,%d, %d",Board_Type_Identified_Value[0],Board_Type_Identified_Value[1],Board_Type_Identified_Value[2]);

    if((Board_Type_Identified_Value[0] == Board_Type_Identified_Value[1]) && (Board_Type_Identified_Value[1] == Board_Type_Identified_Value[2]))
    {
        BoardType = Board_Type_Identified_Value[2];
    }
    else
    {
        BoardType = 0;
    }
    switch (BoardType)
    {
        case 0:
        printf("\nno board is Identified");
        systemInfo.Board_Type = 0;
        break;
        case 1:
        printf("\nboard Identified is 140X16");
        systemInfo.Board_Type = 1;
        sleep_ms(100);
        init_spi();
        spi_empty_channel_with(0x00);
        init_spi_manually();
        manual_spi_write_register1(0xC03F, 9, 4);  
        break;
        case 2:
        printf("\nboard Identified is 128X16");
        systemInfo.Board_Type = 2;
        sleep_ms(100);
        init_spi();
        spi_empty_channel_with(0x00);
        init_spi_manually();
        manual_spi_write_register1(0xC007, 8, 4);
        break;
        case 3:
        printf("\nboard Identified is 96X16");
        systemInfo.Board_Type = 3;
        sleep_ms(100);
        init_spi();
        spi_empty_channel_with(0x00);
        init_spi_manually();
        manual_spi_write_register1(0xC01F, 8, 3);
        break;
        default:
        printf("\n default");
        systemInfo.Board_Type = 0;
        break;
    }
    if(systemInfo.Board_Type == 0)
    {
        exit(0);
    }
    //init_spi_manually();
    //manual_spi_write_register1(0xc03f, 9, 4);
    //manual_spi_write_register1(0xc03f, 8, 4);
    //manual_spi_write_register1(0xc007, 8, 4);
    //sleep_ms(500);
    init_spi();    
#endif
    systemInfo.deviceId = updateDeviceId();
    // printf("The current Device ID is %d\n",systemInfo.deviceId);
#ifdef ENABLE_PICO
    systemInfo.testMode = !gpio_get(TEST_MODE);

#ifdef ENABLE_PID_DTC
    init_pid_dtc();
    //update_reset_count();
#endif

#ifdef ENABLE_WATCHDOG
    watchdog_start_tick(12);
    watchdog_enable(WATCHDOG_TIMEOUT, 1);
#endif
#endif

    //start work hour timer
    struct repeating_timer timer_work_hour_incrementer;
    add_repeating_timer_ms(60000,increment_work_hour_count, NULL, &timer_work_hour_incrementer);
    // printf("\n after adding repeating timer for work hour\n");
    run_cores();
    
    

#ifndef ENABLE_PICO
	refresh();			/* Print it on to the real screen */
	getch();			/* Wait for user input */
	endwin();			/* End curses mode		  */
#endif
    // Should never get here
    flash_debug_led();
}

#if 0
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int Chip_Chipone_Configuration_To_Max_Intensity(uint8_t board_type)
{
    int Chip_Count = 0, Board_Count = 0, loop1_count = 0, loop2_count = 0, i = 0;
    /////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////////////////////////////////
    uint16_t config[9] = {
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
    };
   uint16_t config_value = 0xC03F;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////
    gpio_put(LED_DRIVER_BLANK_SIGNAL, HIGH); // Disable PWM*/
    switch(board_type)
    {
        case 1:
        Chip_Count = 9;
        Board_Count = 4;
        break;
        case 2:
        Chip_Count = 8;
        Board_Count = 4;
        break;
        case 3:
        Chip_Count = 8;
        Board_Count = 3;
        break;
        default :
        Chip_Count = 8;
        Board_Count = 3;
        break;

    }

        for(loop1_count = 0; loop1_count < Board_Count ; loop1_count++)
        {
            for(loop2_count=0;loop2_count<Chip_Count;loop2_count++)
            {
                config[i] = config_value;
            }
                manula_spi_write_register1(&config,Chip_Count);
        }
    
    return 0;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void manula_spi_write_register1(uint16_t *pBuf, int len)
{
        int bc;
    uint8_t state, shift_count = 0;
    uint16_t ch;
    gpio_put(LED_DRIVER_BLANK_SIGNAL, 1); // First make OE High as per the ICND8390 Datasheep for Register 1 write
    sent_register_write_Enable_Command();
    gpio_put(LED_DRIVER_BLANK_SIGNAL, 0); // Then make OE LOW as per the ICND8390 Datasheep for Register 1 write
    sleep_us(1);
    gpio_put(LED_DRIVER_STROBE_SIGNAL, 0); // Trigger strobe pulse Make Low*/
      for (bc = 0; bc <= len; bc++)
    {
                ch = pBuf[bc];
                //printf("\r\nlocation ch configBuf[%d] = 0x%02X",bc,pBuf[bc]);
                sleep_us(5);
            for (uint8_t bit = 0; bit <= 15; bit++)
            {
                    if (ch & (0x8000 >> bit))
                            {
                                // High data bit
                                state = 1;
                            }
                            else
                            {
                                // Low data bit
                                state = 0;
                            }
                            // sending the state data to SIN PIN and giving a clock pulse
                            gpio_put(LED_DRIVER_MOSI_SIGNAL, state);
                            sleep_us(5);
                            gpio_put(LED_DRIVER_SCLK_SIGNAL, 1);
                            sleep_us(5);
                            gpio_put(LED_DRIVER_SCLK_SIGNAL, 0);
                            sleep_us(2);
                            shift_count=shift_count+1;
            //if(shift_count == 140)
            if(shift_count == 140)
            {
                sleep_us(170);
                gpio_put(LED_DRIVER_STROBE_SIGNAL, 1); // Trigger strobe pulse make High
                //sleep_ms(5000);
                //break;
            }
            }
    }
}
#endif

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void sent_register_write_Enable_Command(void)
{
    
        int Enable_Count =0;
        gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
        sleep_us(1);
         gpio_put(LED_DRIVER_STROBE_SIGNAL, 1);
        sleep_us(5);
        //Make SIN Serial In Low
        gpio_put(LED_DRIVER_MOSI_SIGNAL, 0);
        // Send Clock Pulse of 12 Clocks
        sleep_us(2);
    for(Enable_Count =0;Enable_Count<=11;Enable_Count++)
    {
       gpio_put(LED_DRIVER_SCLK_SIGNAL , 1);
       sleep_us(1);
       gpio_put(LED_DRIVER_SCLK_SIGNAL, 0);
       sleep_us(1);
       if(Enable_Count==11)
       {
            //Make LE LOW -> LE is renamed and reffered to as strobe
            sleep_us(1);
            gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
            sleep_us(1);
       }
        
    }
    //gpio_put(LED_DRIVER_SCLK_SIGNAL, 0);
    //Make LE High -> LE is renamed and reffered to as strobe
    gpio_put(LED_DRIVER_STROBE_SIGNAL, 0);
    sleep_us(2);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
void init_spi_manually(void)
{
    gpio_init(LED_DRIVER_SCLK_SIGNAL);
    gpio_init(LED_DRIVER_MOSI_SIGNAL);
    gpio_init(LED_DRIVER_MISO_SIGNAL);
    
    gpio_set_dir(LED_DRIVER_MISO_SIGNAL, GPIO_OUT);
    gpio_set_dir(LED_DRIVER_MOSI_SIGNAL, GPIO_OUT);
    gpio_set_dir(LED_DRIVER_SCLK_SIGNAL, GPIO_OUT);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void manual_spi_Write_Data(uint8_t *Dataptr, int len)
{

  int i=0;
  unsigned char SPICount;                                       // Counter used to clock out the data

  uint8_t SPIData;                                        // Define a data structure for the SPI data

  //gpio_put(SPI_CS,1);//SPI_CS = 1;                                        		// Make sure we start with active-low CS high
  gpio_put(LED_DRIVER_SCLK_SIGNAL,0);//SPI_CLK = 0;                                        		// and CK low

  //SPIData = regAddr;                                            // Preload the data to be sent with Address
  //gpio_put(SPI_CS,0); //SPI_CS = 0;                                                   // Set active-low CS low to start the SPI cycle 
                                                                // Although SPIData could be implemented as an "int", 
                                                                // resulting in one
                                                                // loop, the routines run faster when two loops 
                                                                // are implemented with
                                                                // SPIData implemented as two "char"s.
  for(i=0;i<=len-1;i++)
  {
    SPIData=Dataptr[i];
    //sleep_ms(10);
  for (SPICount = 0; SPICount < 8; SPICount++)                  // Prepare to clock out the Address byte
  {
    if (SPIData & 0x80) 
    {                                        // Check for a 1
      gpio_put(LED_DRIVER_MOSI_SIGNAL,1); //SPI_MOSI = 1;  
    }                                           // and set the MOSI line appropriately
    else
    {
      gpio_put(LED_DRIVER_MOSI_SIGNAL,0); //SPI_MOSI = 0;
    }
    gpio_put(LED_DRIVER_SCLK_SIGNAL,1);//SPI_CLK = 1; 
    /*for(int i=0;i<=35;i++)
            {
                i=i;
            }*/
    /////////////////////////////////////////////////////////////////////////////////////////////
    //sleep_us(5);
    /////////////////////////////////////////////////////////////////////////////////////////////
    sleep_us(1);                                                // Toggle the clock line
    gpio_put(LED_DRIVER_SCLK_SIGNAL,0);//SPI_CLK = 1;
    SPIData <<= 1;
    /// @brief //////////////////////////////////////////////////////////////////////
    
    sleep_us(1);  
    //////////////////////////////////////////////////////////////////////////////////
    }                                            // Rotate to get the next bit
  }                                                             // and loop back to send the next bit
                                                        
                                                                // Repeat for the Data byte
  //SPIData = regData;                                            // Preload the data to be sent with Data
  //for (SPICount = 0; SPICount < 8; SPICount++)
  {
    //if (SPIData & 0x80)
      //gpio_put(LED_DRIVER_MOSI_SIGNAL,1);//SPI_MOSI = 1;
    //else
      //gpio_put(LED_DRIVER_MOSI_SIGNAL,0);//SPI_MOSI = 0;
    //gpio_put(LED_DRIVER_SCLK_SIGNAL,0);//SPI_CLK = 0;
    //sleep_us(3); 
    //gpio_put(LED_DRIVER_SCLK_SIGNAL,1);//SPI_CLK = 1;
    //SPIData <<= 1;
  }          
  //gpio_put(SPI_CS,1);//SPI_CS = 1;
  gpio_put(LED_DRIVER_MOSI_SIGNAL,0);//SPI_MOSI = 0;
  gpio_put(LED_DRIVER_SCLK_SIGNAL,0);//SPI_CLK = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
