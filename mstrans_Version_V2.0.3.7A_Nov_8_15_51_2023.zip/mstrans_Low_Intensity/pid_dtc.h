/*
   pid_dtc.h: This file has function headers and data structures needed to handle requests 
   for PID / DTC information from PIS controller
   */
#ifndef __PID_DTC__
#define __PID_DTC__

#ifdef ENABLE_PID_DTC

#define MAX_PID_DTC_RESP    256

#define MAX_RESET_BLOCK_SIZE    256
#define MAX_RESET_BLOCKS        128
#define START_RESET_BLOCK_ADDR  (ERASE_BLOCK_SIZE * 2)

#define PID_DTC_GRP_CMD 0x08
#define PID_DTC_GRP1    0x31
#define PID_DTC_GRP2    0x32
#define PID_DTC_GRP3    0x33
#define PID_DTC_GRP4    0x34
#define PID_DTC_GRP5    0x35
#define PID_DTC_SET_REQUEST 0x0A

#define RESP_SOH 0x01
#define RESP_EOT 0x04

/* Data structures */
typedef struct {
    uint8_t soh;
    uint8_t cmd;
    uint8_t addr;
    uint8_t grp;
} PID_DTC_RESP_HDR;

typedef struct {
    uint32_t resp_len;
    char pid_dtc_resp[MAX_PID_DTC_RESP];
} PID_DTC_RESP_PAYLOAD;

typedef struct {
    uint8_t eot;
    uint8_t csum[2];
} PID_DTC_RESP_TRAILER;

typedef struct {
    uint32_t in_use; // 0xffffffff implies Free
    uint32_t reset_count;
} RESET_BLOCK_INFO;

// Size includes Terminating character
#define MAX_CUST_NAME   32
#define MAX_ORDER_NO    10
#define MAX_BUS_TYPE    8
#define MAX_BUS_BUILD   8
#define MAX_LANGUAGE    5
#define MAX_FW_VER              16
#define MAX_BOOTLOADER_VER      16
#define MAX_HW_VER              16
#define MAX_FW_FLASH_DATE       16
#define MAX_FW_BUILD_DATE       16
#define MAX_SERIAL_NO           32
#define MAX_VOLTAGE_LIMIT       28 //28 Volts
#define MAX_TEMPERATURE_LIMIT   55 //55 degree Centigrades
#define MIN_VOLTAGE_LIMIT       18 //18 Volts
#define MAX_FW_UPDATE_STATUS    16
#define MAX_META_DATA_VER       16
#define MAX_ARTICLE_NO_SIGN_LEVEL   16
#define MAX_TEST_DATE           8
#define MAX_FONT_LIBRARY_VER    8

//#define DEFAULT_CUST_NAME "GCM Mobility"
#define DEFAULT_CUST_NAME "GCMMblty"
#define DEFAULT_ORDER_NO  "00001082"
#define DEFAULT_BUS_TYPE  "STD12"
#define DEFAULT_BUS_BUILD "LowFI"
#define DEFAULT_LANG      "Eng"
#define DEFAULT_FW_VER    "2.01"
#define DEFAULT_BOOTLOADER_VER  "1.1"
#define DEFAULT_HW_VER  "3.1"
#define DEFAULT_FW_FLASH_DATE "100423"
#define DEFAULT_FW_BUILD_DATE "110323"
#define DEFAULT_TEST_DATE   "110323"
#define DEFAULT_SERIAL_NO   "mtpl-764290"
/////////////////////////////////////////////
#define DEFAULT_FIRMWARE_UPDATE_STATUS "001"
#define DEFAULT_ARTICLE_NUMBER_SIGN_LEVEL "000"
#define DEFAULT_META_DATA_VERSION       "000"
#define DEFAULT_FONT_LIBRARY_VERSION    "00"
#define PRODUCT_INFO_ADDR_LOCATION       0x030000
#define CUSTOMER_INFO_ADDR_LOCATION      0x030010
#define WORK_HOURE_INFO_ADDR_LOCATION       0x030001

typedef struct {
    // Static information
    char cust_name[MAX_CUST_NAME];
    char order_no[MAX_ORDER_NO];
    char bus_type[MAX_BUS_TYPE];
    char bus_build[MAX_BUS_BUILD];
    char language[MAX_LANGUAGE];

    // Dynamic information
    uint32_t max_temp;
    uint32_t min_temp;
    uint32_t curr_temp;
    uint32_t max_batt;
    uint32_t min_batt;
    uint32_t curr_batt;
    uint32_t reset_count;
    uint32_t work_hour;
    bool    over_voltage_flag;
    bool    under_voltage_flag;
    bool    over_Temperature_flag;

    char fw_update_status[MAX_FW_UPDATE_STATUS];
    char art_no_sign_lev[MAX_ARTICLE_NO_SIGN_LEVEL];
    char meta_dat_ver[MAX_META_DATA_VER];
    char fw_ver[MAX_FW_VER];
    char bootloader_ver[MAX_BOOTLOADER_VER];
    char font_library_ver[MAX_FONT_LIBRARY_VER];
    char hw_ver[MAX_HW_VER];
    char fw_flash_date[MAX_FW_FLASH_DATE];
    char fw_build_date[MAX_FW_BUILD_DATE];
    char test_date[MAX_TEST_DATE];
    char serial_no[MAX_SERIAL_NO];
} PID_DTC_INFO;

/* Function prototypes */

/* Updates temperature and battery voltage into pid_dtc_info structure */
uint8_t update_sensor_info(void);

/* Returns 1 if the input value is a pid/dtc group command */
uint8_t is_pid_dtc_cmd(uint8_t val);

/* Identifies the pid_dtc command and prepares appropriate response using 
   information from the pid_dtc_info structure
   */
uint8_t process_pid_dtc_command(uint8_t cmd);

/* Identifies the pid_dtc command and sets the information according to the information received and 
    prepares appropriate response using 
   information from the pid_dtc_info structure
   */
uint8_t process_pid_dtc_set_command(uint8_t cmd);

/* Prepares Hanover header alongwith checksum and transmits response to PID controller
   Transmitting frame should follow the sequence below
   Enable XMIT line
   Transmit frame
   Disable XMIT line, go back to RECV mode
   */
uint8_t transmit_pid_dtc_response(void);

/* Initialize pid_dtc_info structure with default values */
uint8_t init_pid_dtc();

/* Called on startup to increment reset count using wear leveling
   Reads current count from the flash, updates the local and stored count 
   and writes it back to flash
   */
uint8_t update_reset_count(uint32_t reset_count);
uint32_t  get_last_reset_count(uint32_t *pResetCount);

/* Calculate Checksum for generated string*/

uint8_t calculate_checksum_pid_dtc(void);
uint32_t Read_Voltage_Sensor(void);
uint32_t Write_data_Into_Flash(uint8_t * Input_Buffer, uint32_t Flash_Address_Location, uint32_t Data_Length);
uint32_t Read_data_From_Flash(uint8_t * Destination_Buffer, uint32_t Flash_Address_Location, uint32_t Data_Length);
uint32_t Load_Product_Info_From_Flash(void);
uint32_t Load_Customer_Info_From_Flash(void);
uint8_t Transmit_pid_dtc_Error_Response(void);
uint8_t process_pid_dtc_error_command(uint8_t cmd);
#endif /* ENABLE_PID_DTC */
#endif /* __PID_DTC__ */

