#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifndef __HVRPROT__
#define __HVRPROT__

#define BINARY_PAYLOAD 0x01
#define TEXT_PAYLOAD   0x02

#define MAX_ROWS                16 // Number of rows in LED sign
#define BITS_PER_BYTE           8
#define MAX_VERTICAL_BYTE_BUFFER    8192 
#define MAX_HORIZONTAL_BYTE_BUFFER  (MAX_VERTICAL_BYTE_BUFFER / BITS_PER_BYTE)
#define LED_ROW_OFFSET          (MAX_ROWS / BITS_PER_BYTE)  // Bytes per Column in vertical byte representation 

//#define HANOVER_MSG_START_INDEX 3
#define HANOVER_MSG_OVERHEAD    (3 + 1 + 2)
#define MAX_MODES               4
#define MAX_MODE_PAYLOAD        2048 

#define MAX_TOKEN_VALUE_LEN     5   // Max number of characters after token name that make up the number // change ny shrikant

// Tokens for SuperX protocol
#define MODE_TOKEN "mode"
#define PICW_TOKEN "picw"
#define PICH_TOKEN "pich"
#define REP_TOKEN  "rep"
#define SHIFT_LEFT_TOKEN  "sl"
#define SHIFT_RIGHT_TOKEN "sr"
#define ROUTE_WIDTH_TOKEN "rw"
#define FIT_TOKEN "fit"
#define FLASH_TOKEN "fl"
#define MSS_TOKEN "mss"
#define TOP_PRIORITY_MESSAGE "tpm"

// Tokens for BasicX protocol
#define BASICX_STATIC_PHRASE 's'
#define BASICX_PAUSE_2SEC    'P'
#define BASICX_BLANK_2SEC    'B'
#define BASICX_SCROLL_LEFT   '<'
#define BASICX_SCROLL_RIGHT  '>'
#define BASICX_FLASH         'f'

#define DEFAULT_FLASH_ON_TIMEOUT    500
#define DEFAULT_FLASH_PERIOD        1 // One second

// Tracks state of the display during flash operation
#define DISPLAY_STATE_ON     1
#define DISPLAY_STATE_OFF    2


typedef struct {
    char *name; // mode name eg. mode
    uint8_t extensionPresent; // some tokens can have value after it, eg mode0, mode1, isp0, isp0 etc
} TOKEN_INFO;

typedef struct {
    uint16_t row, col;
    uint16_t width;
    uint16_t height;
    uint16_t payloadLen;
    uint8_t data[MAX_MODE_PAYLOAD];
    uint8_t payloadType;
    uint8_t repeatCount; // Number of times this scroll will repeat
    uint8_t shiftRight;
    uint8_t shiftLeft;
    uint8_t fitMode;
    uint8_t enableScrolling;
    uint8_t flashPeriod;
    uint16_t flashOnTime;
    uint16_t flashOffTime;
} MODE_INFO;

typedef struct {
    uint8_t mode; // Mode value can be 0, 1, 2 or 3
    // Set by UART processor when it receives a new message
    // Cleared by display processor when it has picked it up
    uint8_t messageChanged; 
    uint8_t flashStartTime;
    int modeIndex; // Current mode being populated
    int availableDisplayWidth; // Used for centering messages
    int Top_Priority_Message_Status;
    MODE_INFO modeData[MAX_MODES];    
} MESSAGE_INFO;

uint8_t transform_to_vert_buffer();
uint8_t transform_to_horiz_buffer();
uint8_t getFontValue(uint8_t ch, uint8_t fontRow, uint8_t fontTable8x8);

// Data structures
extern MESSAGE_INFO messageInfo;
// Function prototypes
uint8_t process_uart(void);

#endif