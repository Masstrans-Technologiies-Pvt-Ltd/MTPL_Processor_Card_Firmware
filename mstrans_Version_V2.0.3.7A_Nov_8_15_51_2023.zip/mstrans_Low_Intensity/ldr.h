

int getLdrValue();
