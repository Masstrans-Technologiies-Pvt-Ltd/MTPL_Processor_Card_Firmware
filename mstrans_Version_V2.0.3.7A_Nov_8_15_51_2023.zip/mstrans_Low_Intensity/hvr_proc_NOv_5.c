#include "proc-card.h"
#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "flashchip.h"
#include "flashchip.h"
#include "rcerr.h"
#include "lastmsg.h"

typedef struct {
    uint32_t in_use; // 0xffffffff implies Free
    uint32_t msg_len;
    uint8_t msg[MAX_MSG_SIZE];
} block_info_t;

#define MAX_BLOCKS  64

static uint32_t curr_block_offset = 0;
block_info_t block_info = {0};
block_info_t saved_block_info = {0};
extern uint8_t hvrprot_Test_Mode_Scroll_Completed_Flag;
extern uint8_t hvrprot_Test_Mode_Message_Flag;
extern uint8_t hvrprot_Test_Mode_Message_Triggered_Flag;
//hvrprot_Test_Mode_Message_Flag


/* 
 * read_block(): Issues multiple sector read 
 *  
*/
static uint8_t read_block(block_info_t *pBlock, uint32_t offset)
{
    uint8_t rc = RC_SUCCESS;

    if (!pBlock || offset > (MAX_BLOCKS * MAX_BLOCK_SIZE)) 
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    readFlash(offset, (uint8_t *)pBlock, sizeof(*pBlock));

    return rc;
}

/* 
 * write_block(): Issues multiple sector write 
 *  
*/
static uint8_t write_block(block_info_t *pBlock, uint32_t offset)
{
    uint8_t rc = RC_SUCCESS;

    if (!pBlock || offset > (MAX_BLOCKS * MAX_BLOCK_SIZE)) 
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    writeFlash(offset, (uint8_t *)pBlock, sizeof(*pBlock));

    return rc;
}


/* 
 * get_last_message(): Gets the last message saved in flash from the last reboot. If 
 *  present, should be used to initialize the display.
*/
uint8_t get_last_message(uint8_t *pMsg, uint16_t *pMsgLen)
{
    uint8_t rc = RC_NO_DATA;
    int i;

    if (!pMsg || !pMsgLen || !(*pMsgLen))
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    saved_block_info.in_use = BLOCK_FREE;
    saved_block_info.msg_len = 0;
    memset(&saved_block_info.msg[0], 0, sizeof(&saved_block_info.msg));

    for (i = 0; i < MAX_BLOCKS; i++, curr_block_offset += MAX_BLOCK_SIZE)
    {
        block_info.in_use = BLOCK_FREE;
        block_info.msg_len = 0;
        memset(&block_info.msg[0], 0, sizeof(&block_info.msg));
        /* Read current flash block */
        if (read_block(&block_info, curr_block_offset) == RC_SUCCESS)
        {
            if (block_info.in_use == VALID_BLOCK_SIGNATURE)
            {
                memcpy(&saved_block_info, &block_info, 
                        sizeof(saved_block_info));
            }
            else if (block_info.in_use == BLOCK_FREE)
                break;
        }
        else
        {
            printf("Error reading flash block\n");
            break;
        }
    }

    if (i >= MAX_BLOCKS)
    {
        // Erase flash
        printf("Erasing flash ...\n");
        uint32_t erase_address = 0;

        blockErase64k(erase_address);
        // Wait for operation to complete
        while (!chipready())
        {
            sleep_ms(1);
        }
        erase_address += ERASE_BLOCK_SIZE;
        blockErase64k(erase_address);
        // Wait for operation to complete
        while (!chipready())
        {
            sleep_ms(1);
        }
        printf("Erasing complete !\n");
        curr_block_offset = 0;
    }
    if ((saved_block_info.in_use == VALID_BLOCK_SIGNATURE) &&
            saved_block_info.msg_len)
    {
        if (*pMsgLen >= saved_block_info.msg_len)
        {
            memcpy(pMsg, saved_block_info.msg, saved_block_info.msg_len);
            *pMsgLen = saved_block_info.msg_len;
            rc = RC_SUCCESS;
        }
        else
        {
            printf("Insufficient buffer\n");
            rc = RC_FRAME_TOO_LARGE; 
        }
    }

    return rc;
}


/* 
 * update_flash(): Saves the message to the wear leveled flash block if it is not the 
 *      same as one present at the current write location.
 *  
*/
uint8_t update_flash(uint8_t *pMsg, int msgLen)
{
    uint8_t rc = RC_SUCCESS;
    int i;

    // printf("\n entered into update_flash function lastmsg.c 160");
    if (!pMsg || !msgLen || (msgLen > sizeof(block_info.msg)))
    {
        rc = RC_INVALID_PARAMETER;
        return rc;
    }

    if (RC_SUCCESS == rc)
    {
        // Check if message in current block is same as the one being updated
        if ((msgLen != saved_block_info.msg_len))
        {
            printf("Message length is different \n");
            // XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            /*printf("\n rc = %d",rc);
            printf("\n The saved message is :\n");
            i = 0;
            while(saved_block_info.msg[i])
            {
            printf("%c",saved_block_info.msg[i]);
            i++;
            if(i>=saved_block_info.msg_len)
            {
                printf("\n length of saved_block_info is %d",i);
                break;
            }
            }
            printf("\n The Received message is : \n%s",pMsg);
            printf("\n Length of Recieved message is %d",msgLen);*/
            // XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            if(hvrprot_Test_Mode_Message_Triggered_Flag)
            {
                hvrprot_Test_Mode_Message_Flag = 0;
                hvrprot_Test_Mode_Message_Triggered_Flag = 0;
                hvrprot_Test_Mode_Scroll_Completed_Flag = 0;
            }
        } // message length is same
        else if (!memcmp(saved_block_info.msg, pMsg, msgLen))
        {
            printf("Message length and content are same\n");
            // XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            /*printf("\n The saved message is :\n");
            i = 0;
            while(saved_block_info.msg[i])
            {
            printf("%c",saved_block_info.msg[i]);
            i++;
            if(i>=saved_block_info.msg_len)
            {
                printf("\n length of saved_block_info is %d",i);
                break;
            }          
            }
            printf("\n The Received message is :%s",pMsg);*/
            // XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            rc = RC_SKIP_UPDATE;
        } // message content is same

        if (RC_SUCCESS == rc)
        {
            //printf("\n in lastmsg.c line 187");
            if ((curr_block_offset >= (MAX_BLOCKS * MAX_BLOCK_SIZE)))
            {
                // Erase flash
                printf("Erasing flash block ...\n");

                // Erase flash
                uint32_t erase_address = 0;

                blockErase64k(erase_address);
                erase_address += ERASE_BLOCK_SIZE;
                blockErase64k(erase_address);

                // Wait for operation to complete
                while (!chipready())
                {
                    sleep_ms(1);
                }
                printf("Erasing complete !\n");
                curr_block_offset = 0;
            } // erase flash

            if ((rc = read_block(&block_info, curr_block_offset)) == RC_SUCCESS)
            {
                //printf("Reading block at offset %d !\n", curr_block_offset);
                // Sanity check
                if (block_info.in_use == BLOCK_FREE)
                {
                    block_info.in_use = VALID_BLOCK_SIGNATURE;
                    block_info.msg_len = msgLen;
                    memcpy(block_info.msg, pMsg, msgLen);

                    // Update 
                    if ((rc = write_block(&block_info, curr_block_offset)) == RC_SUCCESS)
                    {
                        saved_block_info.in_use = VALID_BLOCK_SIGNATURE;
                        saved_block_info.msg_len = msgLen;
                        memcpy(saved_block_info.msg, pMsg, msgLen);
                        curr_block_offset += MAX_BLOCK_SIZE;

                        /*printf("Update successful, curr_block_offset %d, msgLen = %d\n", curr_block_offset,
                            saved_block_info.msg_len);*/
                        rc = RC_SUCCESS;
                    }
                    else
                    {
                        printf("Block write failed\n");
                    }
                } // block is free
            } // read block successful
            else
                printf("Failed to read block at offset %d !\n", curr_block_offset);

        } // message length same as last block message
        else
        {
            // message length same as last block message 
            rc = RC_SKIP_UPDATE;
        }
    }
    else
    {
        rc = RC_INVALID_FLASH_OFFSET; 
        curr_block_offset = 0;
        printf("Invalid block offset %d, resetting ...\n");
    }

    // printf("\n Successfull exit out of update_flash function in lastmsg.c");

    return rc;
}